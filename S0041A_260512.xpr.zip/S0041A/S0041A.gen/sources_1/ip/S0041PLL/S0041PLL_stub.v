// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Sat Apr 18 14:29:31 2026
// Host        : HC1020301 running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/Design/back/S0041A/S0041A.gen/sources_1/ip/S0041PLL/S0041PLL_stub.v
// Design      : S0041PLL
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7s50csga324-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* CORE_GENERATION_INFO = "S0041PLL,clk_wiz_v6_0_17_0_0,{component_name=S0041PLL,use_phase_alignment=true,use_min_o_jitter=true,use_max_i_jitter=false,use_dyn_phase_shift=false,use_inclk_switchover=false,use_dyn_reconfig=false,enable_axi=0,feedback_source=FDBK_AUTO,PRIMITIVE=MMCM,num_out_clk=1,clkin1_period=41.667,clkin2_period=10.0,use_power_down=false,use_reset=true,use_locked=true,use_inclk_stopped=false,feedback_type=SINGLE,CLOCK_MGR_TYPE=NA,manual_override=false}" *) 
module S0041PLL(refer_clock, reset, refer_ready, exten_clock)
/* synthesis syn_black_box black_box_pad_pin="reset,refer_ready,exten_clock" */
/* synthesis syn_force_seq_prim="refer_clock" */;
  output refer_clock /* synthesis syn_isclock = 1 */;
  input reset;
  output refer_ready;
  input exten_clock;
endmodule
