module  memory_cache//mazes_multitask//memory_distribution//stay alone    momory_demux
#(
    parameter   mem_bit_ctl     =   3,
    parameter   mem_bit_bnk     =   3,
    parameter   mem_bit_row     =   20,
    parameter   mem_bit_col     =   20,
    parameter   mem_bit_dat     =   16,
//
    parameter   mem_cmd_nop     =   7,// COMMAND_NOP
    parameter   mem_cmd_mrs     =   0,// COMMAND_MRS
    parameter   mem_cmd_pre     =   2,// COMMAND_PRE
    parameter   mem_cmd_ref     =   1,// COMMAND_REF
    parameter   mem_cmd_zqc     =   6,// ZQC =   3'b
    parameter   mem_cmd_act     =   3,// COMMAND_ACT
    parameter   mem_cmd_wex     =   4,// COMMAND_WEx
    parameter   mem_cmd_rdx     =   5,// COMMAND_RDx
//
    parameter   chars_pixel     =   0,
    parameter   chars_initi     =   1,
    parameter   chars_latch     =   2,
    parameter   chars_pause     =   3,
//
    parameter   delay_cycle     =   1,

    parameter   expon_gamma     =   8,
    parameter   expon_ports     =   2   //expon_ports   expon_ports
)(
//
    output  reg [               7   : 0]catch_coefs,
    output  reg [               63  : 0]demux_catch[(1<<expon_ports)-1:0],//cache cage
//
    input       [               15  : 0]mazes_hight,        //  arsenal(maze_core.loop[1/2/3])
    input       [               15  : 0]mazes_width,        //  arsenal(maze_core.loop[1/2/3])
    input       [               17  : 0]mazes_chars,
    input       [               2   : 0]mazes_syncs,
    input       [               2   : 0]mazes_reset,

//
    input                               inside_port,
    input       [    (expon_ports-1): 0]place_ports,//  cascade_sel
//
    input       [   mem_bit_ctl-1   : 0]memory_ctrl,
    input       [   mem_bit_bnk-1   : 0]memory_bank,
    input       [   mem_bit_row-1   : 0]memory_page,
    input       [   mem_bit_col-1   : 0]memory_addr,
    input       [   mem_bit_dat-1   : 0]memory_data,
//
    input                               gamma_catch,        //  gamma_catch->color
    input       [   expon_gamma-1   : 0]gamma_curve,        //  gamma_curve->color
    input       [               32  : 0]gamma_slope,        //  gamma_slope->color
    input                               gamma_ready,        //  check exp10
  //input       [               63  : 0]config_chip,//
//
    input       [               7   : 0]bright_lv10,//->memory_distr    spi.fw
    input       [               23  : 0]bright_data,//->memory_distr    spi.fw
    input       [               1   : 0]pattern_ena,//pattern
    input       [               7   : 0]pattern_dat[2:0],//pattern
    input                               correct_ena,//->memory_distr    spi.fw
    input       [               23  : 0]driver_gain,
    input       [               7   : 0]frame_tasks,//2,1,0    
//
    input                               refer_ready,
    input                               refer_clock
);
            reg [               7   : 0]bright_code[3:0];
            reg [               1   : 0]pattern_sel;
always@(posedge refer_clock)bright_code[0]  <=((mazes_reset==1)&&(mazes_syncs[2]))?bright_data[23:16]  :bright_code[0];
always@(posedge refer_clock)bright_code[1]  <=((mazes_reset==1)&&(mazes_syncs[2]))?bright_data[15: 8]  :bright_code[1];
always@(posedge refer_clock)bright_code[2]  <=((mazes_reset==1)&&(mazes_syncs[2]))?bright_data[ 7: 0]  :bright_code[2];
always@(posedge refer_clock)bright_code[3]  <=((mazes_reset==1)&&(mazes_syncs[2]))?bright_lv10         :bright_code[3];
always@(posedge refer_clock)pattern_sel     <=((mazes_reset==1)&&(mazes_syncs[2]))?pattern_ena         :pattern_sel;


          //reg [               63  : 0]shift_catch;//
          //reg [               7   : 0]shift_syncs;//

            reg [               15  : 0]memory_sync;//
            reg [               15  : 0]memory_load;//

always@(posedge refer_clock)memory_sync     <= {memory_sync,mazes_syncs[0]};//memory_sync
always@(posedge refer_clock)memory_load     <= {memory_load,(memory_ctrl==mem_cmd_rdx)};//memory_load

//
            reg [               7   : 0]catch_pixel[4:0];//
/*
always@(posedge refer_clock)catch_pixel[0]  <= (memory_sync[delay_cycle+3]&&(memory_load[delay_cycle+0]))?memory_data[ 7: 0]:catch_pixel[0];//mazes.r
always@(posedge refer_clock)catch_pixel[1]  <= (memory_sync[delay_cycle+3]&&(memory_load[delay_cycle+0]))?memory_data[15: 8]:catch_pixel[1];//mazes.g
always@(posedge refer_clock)catch_pixel[2]  <= (memory_sync[delay_cycle+4]&&(memory_load[delay_cycle+1]))?memory_data[ 7: 0]:catch_pixel[2];//mazes.b
*/
always@(posedge refer_clock)catch_pixel[0]  <= (memory_sync[delay_cycle+3]&&(memory_load[delay_cycle+0]))?memory_data[ 7: 0]:catch_pixel[0];//mazes.r
always@(posedge refer_clock)catch_pixel[1]  <= (memory_sync[delay_cycle+3]&&(memory_load[delay_cycle+0]))?memory_data[15: 8]:catch_pixel[1];//mazes.g
always@(posedge refer_clock)catch_pixel[2]  <= (memory_sync[delay_cycle+4]&&(memory_load[delay_cycle+1]))?memory_data[ 7: 0]:catch_pixel[2];//mazes.b

always@(posedge refer_clock)catch_pixel[3]  <= (memory_sync[delay_cycle+5]&&(memory_load[delay_cycle+2]))?memory_data[ 7: 0]:catch_pixel[3];//pattern.rgb
always@(posedge refer_clock)catch_pixel[4]  <= (memory_sync[delay_cycle+5]&&(memory_load[delay_cycle+2]))?memory_data[15: 8]:catch_pixel[4];//pattern.rgb
always@(posedge refer_clock)catch_coefs     <= (memory_sync[delay_cycle+6]&&(memory_load[delay_cycle+3]))?memory_data[ 7: 0]:catch_coefs;
//
            reg                         bagua_check;
always@(posedge refer_clock)bagua_check     <= (catch_pixel[4]==catch_pixel[3]);//

//
            wire[               7   : 0]catch_color[3:0][3:0];//
            wire[               15  : 0]catch_initi[3:0];
assign  catch_color[0][0]   =   catch_pixel[0];
assign  catch_color[0][1]   =   catch_pixel[1];
assign  catch_color[0][2]   =   catch_pixel[2];
assign  catch_color[0][3]   =   0;
assign  catch_color[1][0]   =   pattern_dat[0];
assign  catch_color[1][1]   =   pattern_dat[1];
assign  catch_color[1][2]   =   pattern_dat[2];
assign  catch_color[1][3]   =   0;
assign  catch_color[2][0]   =   bagua_check?(catch_pixel[3][4]?{catch_pixel[3][3:0],catch_pixel[3][3:0]}:0):0;
assign  catch_color[2][1]   =   bagua_check?(catch_pixel[3][5]?{catch_pixel[3][3:0],catch_pixel[3][3:0]}:0):0;
assign  catch_color[2][2]   =   bagua_check?(catch_pixel[3][6]?{catch_pixel[3][3:0],catch_pixel[3][3:0]}:0):0;
assign  catch_color[2][3]   =   0;
assign  catch_color[3][0]   =   catch_pixel[0];
assign  catch_color[3][1]   =   catch_pixel[1];
assign  catch_color[3][2]   =   catch_pixel[2];
assign  catch_color[3][3]   =   0;

        wire[               63  : 0]driver_code;//driver    DAC
    chip_driver
    chip_driver(
        .   shifter_bit             (   mazes_width[3:0]<<6),
        .   double_gclk             (   double_gclk),//[  4] GCLK multiplier 
        .   expon_delta             (   expon_delta),//
        .   space_delta             (   space_delta),
        .   expon_sigma             (   expon_sigma),//
        .   space_sigma             (   space_sigma),
        .   line_number             (   16),//Number of scan lines 
        .   frame_tasks             (   frame_tasks),//error report
        .   GlobalGain1             (   0),//[A:9] Global current gain (Constant gain ) 
        .   GlobalGain2             (   0),//[8:6] Global current gain (Adjustable gain ) 
        .   driver_gain             (   driver_gain),//<-spi.fw
        .   driver_pick             (   5353),
        .   driver_code             (   driver_code)); //driver    DAC


assign  catch_initi[0]      =   driver_code[15: 0];
assign  catch_initi[1]      =   driver_code[31:16];
assign  catch_initi[2]      =   driver_code[47:32];
assign  catch_initi[3]      =   driver_code[63:48];

//
            wire[                  1: 0]mazes_scrip;
assign  mazes_scrip     =  {mazes_chars[17],mazes_chars[16]};

            reg [               1   : 0]process_rgb;//process_sel
            reg [               1   : 0]process_run;//process_run
            reg                         process_sel;
always@(posedge refer_clock)
    if( memory_sync[delay_cycle+7])
       {process_rgb,process_run}<=0;
    else
       {process_rgb,process_run}<= {process_rgb,process_run}+(process_rgb!=3);

always@(posedge refer_clock)
    if( memory_sync[delay_cycle+7])
        if( mazes_scrip==chars_pixel)
            process_sel <=  0;
        else
        if( mazes_scrip==chars_initi)
            process_sel <=  1;
        else
            process_sel <=  process_sel;
    else
            process_sel <=  process_sel;
//

            wire[               15  : 0]gamma_cache;//scale
            reg [               15  : 0]gamma_multi;//scale
    xram#(
        .   expon_chars             (   16),//= 36,
        .   expon_local             (   8)) //= 16)
    gamma_mem (
        .   write_clock             (   refer_clock), 
        .   write_local             (   gamma_curve), 
        .   write_syncs             (   gamma_catch), 
        .   write_chars             (   gamma_slope[31:16]), 
        .   carry_clock             (   refer_clock), 
        .   carry_local             (   catch_color[pattern_sel][process_rgb]), 
        .   carry_chars             (   gamma_cache));

always@(posedge refer_clock)gamma_multi     <= (bright_code[process_rgb]*bright_code[3])+bright_code[3];//012
/*

*/
            reg [               15  : 0]cache_value;//
            reg [               15  : 0]cache_dummy;//
            reg [                2  : 0]cache_syncs;//
            
always@(posedge refer_clock)   {cache_value,cache_dummy}<=  process_sel?{catch_initi[process_rgb],catch_initi[process_rgb]}:
                                                           (gamma_cache*gamma_multi)+gamma_cache;//

always@(posedge refer_clock)cache_syncs[0]  <=(&process_run)&&(process_rgb==0)&&inside_port;
always@(posedge refer_clock)cache_syncs[1]  <=(&process_run)&&(process_rgb==1)&&inside_port;  
always@(posedge refer_clock)cache_syncs[2]  <=(&process_run)&&(process_rgb==2)&&inside_port;
/*


*/

            reg [               63  : 0]memory_cage[(1<<expon_ports)-1:0];
always@(posedge refer_clock)memory_cage[place_ports][15: 0] <=  cache_syncs[0]?cache_value:memory_cage[place_ports][15: 0];
always@(posedge refer_clock)memory_cage[place_ports][31:16] <=  cache_syncs[1]?cache_value:memory_cage[place_ports][31:16];
always@(posedge refer_clock)memory_cage[place_ports][47:32] <=  cache_syncs[2]?cache_value:memory_cage[place_ports][47:32];

/*


*/

genvar i;
    generate
        for (i=0; i<(1<<expon_ports); i=i+1)
        begin
always@(posedge refer_clock)demux_catch[i]  <=  mazes_syncs[2]  ?   memory_cage[i]  :   demux_catch[i];//
        end // block: u
    endgenerate





endmodule
