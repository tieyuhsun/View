module behavior//behavior//Firmware
 #(
//
    parameter   version_int     =   1,      //byte[3]
    parameter   version_dec     =   0,      //byte[4]
    parameter   version_age     =   2025,   //byte[5]
    parameter   version_mth     =   5,      //byte[6]
    parameter   version_day     =   15,     //byte[7]

//
    parameter   mem_bit_ctl     =   3,
    parameter   mem_bit_bnk     =   3,
    parameter   mem_bit_row     =   20,
    parameter   mem_bit_col     =   20,
    parameter   mem_bit_dat     =   16,

    parameter   mem_cmd_nop     =   7,// COMMAND_NOP
    parameter   mem_cmd_mrs     =   0,// COMMAND_MRS
    parameter   mem_cmd_pre     =   2,// COMMAND_PRE
    parameter   mem_cmd_ref     =   1,// COMMAND_REF
    parameter   mem_cmd_zqc     =   6,// ZQC =   3'b
    parameter   mem_cmd_act     =   3,// COMMAND_ACT
    parameter   mem_cmd_wex     =   4,// COMMAND_WEx
    parameter   mem_cmd_rdx     =   5,// COMMAND_RDx
//
    parameter   chars_pixel     =   0,
    parameter   chars_initi     =   1,
    parameter   chars_latch     =   2,
    parameter   chars_pause     =   3,
//
    parameter   timer_ports     =   1,//ports = mzses_timer[timer_ports]
    parameter   loops_chain     =   3,//place_ports[loops_chain]
    parameter   expon_ports     =   2,
  //parameter   loops_lines     =   1,//
//
    parameter   expon_burst     =   6, //external sram    1920@148.5/((96*64/68)/2)
    parameter   expon_hight     =   9, //
    parameter   expon_width     =   9,//
//
    parameter   [   7   : 0]setup_speed[3:0]=  { 8'd01,8'd01,8'd06,8'd69},  //loacl.0 {(reserve),engine.in ,engine.in ,engine.in }
    parameter   [   7   : 0]setup_shift[3:0]=  { 8'h00,8'h00,8'h00,8'h05},  //loacl.1 {(reserve),engine.out,engine.out,engine.out}  limit_angle
    parameter   [   7   : 0]sizes_ascii[1:0]=  { 8'h10, 8'h08},             //loacl.4 pattern.ascii(reserve)
    parameter   [   15  : 0]sizes_panel[1:0]=  {16'd16,16'd144},            //loacl.5 pattern.outline
    parameter               limit_chain     =   4,  //8b chain_limit
    parameter               double_side     =   1,  //4b LR_SameSidecross staggered Odd_X_EvenSide     =   0,//4b      
    parameter               F_L_Forward     =   0,  //4b part_layout Reverse   ports_R0_L1 =   ,//part_layout
    parameter               F_R_Forward     =   1,  //4b part_layout
/*
    e.g.    limit_chain=4

                            [3][2][1][0]<-Back
                Forward->   [0][1][2][3]


    e.g.    limit_chain=3   limit_ports=2   double_side=0
    
                        [2][1][0]<-Back.port0
                        [2][1][0]<-Back.port1


    e.g.    limit_chain=2   limit_ports=4   double_side=1

                        [1][0]<-Back.port0  port1.Forward->   [0][1]
                        [1][0]<-Back.port2  port3.Forward->   [0][1]

*/

    parameter   [   4  : 0]gamma_table[15:0] = {5'd30,5'd29,5'd28,5'd27,5'd26,5'd25,5'd24,5'd23,5'd22,5'd21,5'd20,5'd19,5'd18,5'd17,5'd16,5'd10},
//arsenal

    parameter   files_mzaes     =   "./P02027_MAZE.mem",
    parameter   files_loop1     =   "./P02027_PINS.mem",//files_loop1
    parameter   files_loop2     =   "./P02027_LINE.mem",//files_loop2
    parameter   files_loop3     =   "./P02027_PART.mem",//files_loop3   {port,cascade}
    parameter   files_pulse     =   "./P02027_WAVE.mem",//
    parameter   files_setup     =   "./P02027_BOOT.mem",//
    parameter   files_exp01     =   "./ZPOLog32b10a.mem",//
    parameter   files_fonts     =   "./TXT128_H16x8b.mem",//

//arsenal
    parameter   cache_loop3     =   0,//
    parameter   cache_loop1     =   0,//
    parameter   cache_loop2     =   0,//
    parameter   cache_mazes     =   0,
    parameter   cache_gamma     =   1,
    parameter   cache_fonts     =   1,
    parameter   cache_setup     =   1,
//arsenal
    parameter   tasks_part3     =   0,//
    parameter   tasks_fonts     =   1,
    parameter   tasks_part1     =   2,//
    parameter   tasks_part2     =   3,//
    parameter   tasks_mazes     =   4,
    parameter   tasks_gamma     =   5,
    parameter   tasks_pulse     =   6,//
    parameter   tasks_setup     =   7,
//arsenal
    parameter   expon_cores     =   0,//maze.multitask      1<<expon_cores
    parameter   expon_mazes     =   6,//    maze_core       6b+0b   = 6b 
    parameter   expon_index     =   2,//maze_compass.loop
    parameter   [7:0]expon_loops[(1<<expon_index)-1:0]= {8'd0,8'd4,8'd4,8'd9},
    parameter   expon_setup     =   3,//pattern.font        1110,0000,0000,00--
    parameter   expon_pulse     =   4,  //
    parameter   expon_gamma     =   8,//gamma               6b+2b = 8b  
//demux
    parameter   [7:0]expon_field[1:0]=   { 8'h02, 8'h02},
    parameter   expon_steps     =   4,//demux,   expon_steps
//
    parameter   gray_syncer     =   0,
    parameter   frequencies     =   125000000,
    parameter   frame_rates     =   60
)(

/*
    SRAM/DRAM
*/
    output  wire[   mem_bit_ctl-1   : 0]memory_ctrl,
    output  wire[   mem_bit_bnk-1   : 0]memory_bank,
    output  wire[   mem_bit_row-1   : 0]memory_page,
    output  wire[   mem_bit_col-1   : 0]memory_addr,
    output  wire[   mem_bit_dat-1   : 0]memory_data,
/*
    xPU
*/
    output  wire                        gamma_catch,        //  ->color
    output  wire[   expon_gamma-1   : 0]gamma_curve,        //  ->color
    output  wire[               32  : 0]gamma_slope,        //  ->color
    output  wire                        gamma_ready,        //  check exp10
    //
    output  wire                        demux_bidir,//->
    output  wire                        demux_break,//->
    output  wire                        demux_latch,//
    output  wire[  (expon_steps+7)  : 0]demux_cycle,//->

    //
    output  wire[               15  : 0]column_code,//
    output  wire                        column_ctrl,//
    output  wire                        column_mark,//
    output  wire                        row_trigger,//
    output  wire[               1   : 0]row_control,//
  //output  wire[               15  : 0]mazes_hight,        //  arsenal(maze_core.loop[1/2/3])
  //output  wire[               15  : 0]mazes_width,        //  arsenal(maze_core.loop[1/2/3])
//
    output  wire                        inside_port,
    output  wire[    (expon_ports-1): 0]place_ports,//  cascade_sel
//
    output  wire[               15  : 0]mazes_hight,        //  arsenal(maze_core.loop[1/2/3])
    output  wire[               15  : 0]mazes_width,        //  arsenal(maze_core.loop[1/2/3])
    output  wire[               17  : 0]mazes_chars,        //  maze_core   ->   
    output  wire[               2   : 0]mazes_reset,        //  maze_engine ->  
    output  wire[               2   : 0]mazes_syncs,        //  maze_engine ->  
//
    output  wire[               7   : 0]bright_lv10,//->memory_distr    spi.fw
    output  wire[               23  : 0]bright_data,//->memory_distr    spi.fw
    output  wire[               1   : 0]pattern_ena,//pattern
    output  wire[               7   : 0]pattern_dat[2:0],//pattern
    output  wire                        correct_ena,//->memory_distr    spi.fw
    output  wire[               7   : 0]identifiers,//->SERDES
    output  wire[               23  : 0]driver_gain,
//
    output  reg [               7   : 0]connect_wen,
//
    output  reg [               7   : 0]frame_tasks,//2,1,0     
    output  reg [               15  : 0]frame_count,        // 
/*
    IO
*/
    input       [               3   : 0]panel_count[1:0],   //  <-  expon_ports,expon_loop3
/*
    <-  Video/SERDES
*/
    input                               image_clock,
    input                               image_vsync,
    input                               image_hsync,
    input                               image_esync,
    input       [               23  : 0]image_pixel,
    input       [               15  : 0]image_hight,
    input       [               15  : 0]image_width,
    input                               image_frame,
/*
    <-  SERDES
*/
    input       [               1   : 0]link_status,        //  <-  SERDES.Data Stream status
    input                               link_select,        //  <-  SERDES.Data Stream Redundancy 
    input       [               7   : 0]network_col,        //  <-  SERDES.ID: scan board
    input       [               5   : 0]network_row,        //  <-  SERDES.ID: fiber/coaxial 

    input                               BuatRatex32,// 
    input                               broadcaster,
/*
    frame_transform
*/
    input                               frame_x_16b,
//
    input       [               7   : 0]SPI_GET_MEM,
/*
    SPI
*/
    input                               SPI_ROM_PAD,//CPU->Boot/FPGA    MCU_SPI\SEL\0_FPGABOOT
    input                               SPI_INT_PAD,//CPU->Boot/FPGA    MCU_SPI\SEL\0_FPGA1
    input                               SPI_CPU_PAD,//CPU->Boot/FPGA    MCU_SPI\SEL\0_FPGA0
    input                               SPI_SCK_PAD,//CPU->Boot/FPGA    
    input                               SPI_CD0_PAD,//CPU->Boot/FPGA    rom.SI.IO0    cpu.out
    output  wire                        SPI_D1C_PAD,//CPU->Boot/FPGA    rom.SO.IO1    cpu.in
//
    input                               refer_ready,
    input                               refer_clock
);


/*
    SPI_LPC

*/

            reg [               7   : 0]coeffis_dat;//
//
            wire[               1   : 0]coeffis_det;//type_memory , type_linear
            wire                        coeffis_set;//cpu.w
            wire                        coeffis_get;//cpu.r
            wire                        coeffis_stb;
            wire[               15  : 0]coeffis_row;//
            wire[               15  : 0]coeffis_col;//
            wire[               7   : 0]coeffis_xyz;//
            wire[               7   : 0]coeffis_bit;//b[6],g[5],r[4],gray[3:0]
//
            wire                        random_work;//  byte[0] 0x03/0x02
            wire[               7   : 0]random_task;//  byte[1] command
            wire[               15  : 0]random_seat;//  byte[2] offset
            wire[               7   : 0]random_byte;
            wire                        random_ctrl;

            reg [               7   : 0]SPI_LPC_MDI;

/*

    protocol_inf

*/
            wire                        reflash_ctl;//bright_lv10.change
    
            wire                        pattern_rst;//->pattern frame reset
            wire[               7   : 0]pattern_mod;//->pattern
            wire[               7   : 0]pattern_sel;//->pattern
            wire[               7   : 0]gamma_index;//->XPU
/*  protocol_inf    Panel-EE*/
            wire                        ram2rom_ctl;//->
            wire[               7   : 0]ram2rom_sel;//->
/*  protocol_inf    Strip*/
            wire                        pixel_close;//->strip
            wire                        white_close;//->strip
            wire[               7   : 0]comm_enable;//->strip
            wire[               7   : 0]comm_select;//->strip
            wire                        uart_pauses;//
/*

    xPU

*/
            wire[               13  : 0]w08h16_addr;//  <-pattern(  texts_ascii[6:5],texts_hight[3:0],   texts_ascii[4:0],~texts_width[2:0])
            wire                        w08h16_font;//  ->pattern(bit)
         //wire                        inside_port;
         //wire[    (expon_ports-1): 0]place_ports;//  cascade_sel
            wire[               15  : 0]place_loops[3:0];//  N/A
          //wire                        demux_break;//->
          //wire[    (expon_steps+7): 0]demux_cycle;//->
          //wire[    (expon_field-1): 0]demux_bidir;//->
          //wire[               7   : 0]column_zone;//
          //wire[               7   : 0]column_code;//
          //wire                        column_ctrl;//
          //wire                        column_mark;//
          //wire                        row_trigger;//
          //wire[               1   : 0]row_control;//
          //wire[               15  : 0]mazes_hight;        //  arsenal(maze_core.loop[1/2/3])
          //wire[               15  : 0]mazes_width;        //  arsenal(maze_core.loop[1/2/3])
          //wire[               17  : 0]mazes_chars;        //  maze_core   ->   
            wire                        mazes_blank;        //  maze_core   ->  
            wire[               7   : 0]mazes_timer[2:0];   //  maze_engine ->  
            wire                        mazes_close;        //  maze_engine ->  
            wire[               1   : 0]mazes_frame;        //  maze_engine ->  
          //wire[               2   : 0]mazes_reset;        //  maze_engine ->  
          //wire[               2   : 0]mazes_syncs;        //  maze_engine ->  
            wire                        blank_carry;        //  -> 
            wire                        self_enable;        //  maze_engine <-  
            reg                         refer_frame;        //  maze_engine <-  
/*

    initial

*/
            wire                        access_envm;
            wire                        setup_ready;
            wire                        setup_write;
            wire[               31  : 0]setup_qbyte;
            wire[               7   : 0]ascii_sizes[1:0];
            wire[               15  : 0]panel_sizes[1:0];
            wire[               15  : 0]block_sizes[1:0];//  ->
/*

    pattern

*/
            wire                        pattern_run;//->
            wire[               3   : 0]pattern_adr;//->
/*


*/


assign  self_enable = 
                      ((pattern_mod==4)||// Bagua
                       (pattern_mod==3)||// Line buffer test pattern
                       (pattern_mod==2)||// Fixed pattern
                       (pattern_mod==1));// Circle pattern  [Display all]

always@(posedge refer_clock)refer_frame <=  image_frame;//


            wire[               7   : 0]script_cont = 1;//->
            reg                         script_edge;
    
always@(posedge refer_clock)script_edge <=  reflash_ctl?1:(blank_carry?0: script_edge);
always@(posedge refer_clock)frame_tasks <=  blank_carry ? (script_edge?script_cont:(frame_tasks-(|frame_tasks))):frame_tasks;

/*

*/
    
          //reg [               15  : 0]frame_count;        // 
          //reg [               15  : 0]multi_frame;        // 
always@(posedge refer_clock)frame_count <=  pattern_rst ? 0 : frame_count+blank_carry;//
//always@(posedge refer_clock)multi_frame <=  blank_carry ? 0 : multi_frame+frame_x_16b;//

//always@(posedge refer_clock)



    SPI_LPC#(
        .   address_bit             (   12)) //8'h10,//8'h10
    SPI_LPC (
        .   coeffis_det             (   coeffis_det),//->memory memory_control
        .   coeffis_set             (   coeffis_set),//->memory memory_control
        .   coeffis_get             (   coeffis_get),//->memory memory_control
        .   coeffis_stb             (   coeffis_stb),//->memory memory_control
        .   coeffis_row             (   coeffis_row),//->memory memory_control
        .   coeffis_col             (   coeffis_col),//->memory memory_control
        .   coeffis_xyz             (   coeffis_xyz),//->memory memory_control
        .   coeffis_bit             (   coeffis_bit),//->memory memory_control

        .   random_work             (   random_work), //->protocol
        .   random_seat             (   random_seat), //->protocol
        .   random_task             (   random_task), //->protocol
        .   random_byte             (   random_byte), //->protocol
        .   random_ctrl             (   random_ctrl), //->protocol

        .   SPI_LPC_MDI             (   SPI_LPC_MDI), 
        .   SPI_SEL_PAD             (   SPI_CPU_PAD),//SPI_SEL_PAD), //SPI
        .   SPI_SCK_PAD             (   SPI_SCK_PAD),//SPI_SCK_PAD), //SPI
        .   SPI_MDO_PAD             (   SPI_CD0_PAD),//SPI_MDO_PAD), //SPI
        .   SPI_SDO_PAD             (   SPI_D1C_PAD),//SPI_SDO_PAD), //SPI
        .   refer_clock             (   refer_clock));



    protocol_inf#(
        .   pattern_def             (   16'h0c00),
        .   gamma_reset             (   0), // 9,//
        .   dac_r_reset             (   (3<<4)), //(3<<4),//
        .   dac_g_reset             (   (2<<4)), //(2<<4),//
        .   dac_b_reset             (   (1<<4)), //(1<<4),//
        .   val_r_reset             (   8'h80), //8'h40,//8'h40
        .   val_g_reset             (   8'h80), //8'h40,//8'h40
        .   val_b_reset             (   8'h80), //8'h40,//8'h40
        .   val_a_reset             (   8'h80)) //8'h10,//8'h10
    protocol_inf (
        .   BuatRatex32             (   BuatRatex32), //<-SERDES
        .   broadcaster             (   broadcaster), //<-SERDES

        .   random_work             (   random_work), //<-SPI_LPC
        .   random_seat             (   random_seat), //<-SPI_LPC
        .   random_task             (   random_task), //<-SPI_LPC
        .   random_byte             (   random_byte), //<-SPI_LPC
        .   random_ctrl             (   random_ctrl), //<-SPI_LPC
        .   identifiers             (   identifiers), //->SERDES
        .   pattern_rst             (   pattern_rst), //
        .   pattern_mod             (   pattern_mod), //
        .   pattern_sel             (   pattern_sel), //
        .   bright_lv10             (   bright_lv10), //
        .   bright_data             (   bright_data), //
        .   reflash_ctl             (   reflash_ctl), //
        .   gamma_index             (   gamma_index), //
        .   ram2rom_ctl             (   ram2rom_ctl), //
        .   ram2rom_sel             (   ram2rom_sel), //
        .   correct_ena             (   correct_ena), //
        .   driver_gain             (   driver_gain), //
        .   refer_ready             (   refer_ready), 
        .   refer_clock             (   refer_clock));


    XPU#(
        .   setup_speed             (   setup_speed),  //{(reserve),engine.in ,engine.in ,engine.in }
        .   setup_shift             (   setup_shift),  //{(reserve),engine.out,engine.out,engine.out}  limit_angle
        .   timer_ports             (   timer_ports),
        .   loops_chain             (   loops_chain),
        .   expon_ports             (   expon_ports),
//
        .   chars_pixel             (   chars_pixel),//=   0,
        .   chars_initi             (   chars_initi),//=   1,
        .   chars_latch             (   chars_latch),//=   2,
        .   chars_pause             (   chars_pause),//=   3,
        .   files_mzaes             (   files_mzaes),//=   "./P160522_MAZE.mem",
        .   files_loop1             (   files_loop1),//=   "./P160522_CHIP.mem",//files_loop1
        .   files_loop3             (   files_loop3),//=   "./P160522_PART.mem",//files_loop3   {port,cascade}
        .   files_loop2             (   files_loop2),//=   "./P160522_LINE.mem",//files_loop2
        .   files_pulse             (   files_pulse),//=   "./P160522_WAVE.mem",//
        .   files_setup             (   files_setup),//=   "./P160522_CONFIG.mem",//
        .   files_fonts             (   files_fonts),//=   "./TXT128_H16x8b.mem",//
        .   files_exp01             (   files_exp01),//=   "./square32b10a.mem",//"./square32b10a.mem",//
//
        .   cache_loop3             (   cache_loop3),//=   0,//
        .   cache_loop1             (   cache_loop1),//=   0,//
        .   cache_loop2             (   cache_loop2),//=   0,//
        .   cache_mazes             (   cache_mazes),//=   0,
        .   cache_gamma             (   cache_gamma),//=   1,
        .   cache_fonts             (   cache_fonts),//=   1,
        .   cache_setup             (   cache_setup),//=   1,
//
        .   tasks_part3             (   tasks_part3),//
        .   tasks_fonts             (   tasks_fonts),
        .   tasks_part1             (   tasks_part1),//
        .   tasks_part2             (   tasks_part2),//
        .   tasks_mazes             (   tasks_mazes),
        .   tasks_gamma             (   tasks_gamma),
        .   tasks_pulse             (   tasks_pulse),//
        .   tasks_setup             (   tasks_setup),
//
        .   expon_cores             (   expon_cores),//
        .   expon_mazes             (   expon_mazes),//
        .   expon_index             (   expon_index),//
        .   expon_loops             (   expon_loops),//
        .   expon_setup             (   expon_setup),//
        .   expon_pulse             (   expon_pulse),//
        .   expon_gamma             (   expon_gamma),//
        .   expon_field             (   expon_field),//
        .   expon_steps             (   expon_steps),//
        .   gray_syncer             (   gray_syncer),
        .   frequencies             (   frequencies),//
        .   frame_rates             (   frame_rates))//
    XPU (
        .   frame_tasks             (   frame_tasks),   //<-
        .   access_envm             (   access_envm),   //initial
        .   setup_ready             (   setup_ready),   //initial
        .   setup_write             (   setup_write),   //initial
        .   setup_qbyte             (   setup_qbyte),   //initial
        .   gamma_index             (   gamma_index),   //<-
        .   gamma_catch             (   gamma_catch),   //->gamma
        .   gamma_curve             (   gamma_curve),   //->gamma
        .   gamma_slope             (   gamma_slope),   //->gamma
        .   gamma_ready             (   gamma_ready),   //->gamma
        .   w08h16_addr             (   w08h16_addr),   //font.pattern<-
        .   w08h16_font             (   w08h16_font),   //font.pattern->

        .   inside_port             (   inside_port),
        .   place_loops             (   place_loops),
        .   place_ports             (   place_ports),   //addr.ports

        .   demux_bidir             (   demux_bidir),   //demux
        .   demux_break             (   demux_break),   //demux
        .   demux_latch             (   demux_latch),   //demux
        .   demux_cycle             (   demux_cycle),   //demux

        .   column_code             (   column_code),   //gray
        .   column_ctrl             (   column_ctrl),   //gray
        .   column_mark             (   column_mark),   //gray
        .   row_trigger             (   row_trigger),   //gray
        .   row_control             (   row_control),   //gray
        .   mazes_hight             (   mazes_hight),   //mzes
        .   mazes_width             (   mazes_width),   //mzes
        .   mazes_chars             (   mazes_chars),   //mzes
        .   mazes_blank             (   mazes_blank),   //mzes
        .   mazes_timer             (   mazes_timer),   //mzes[2:0],   //  maze_engine ->  
        .   mazes_close             (   mazes_close),   //mzes
        .   mazes_frame             (   mazes_frame),   //mzes
        .   mazes_reset             (   mazes_reset),   //mzes
        .   mazes_syncs             (   mazes_syncs),   //mzes
        .   blank_carry             (   blank_carry),   //
        .   self_enable             (   self_enable),   //<-
        .   refer_frame             (   refer_frame),   //<-
        .   refer_ready             (   refer_ready),
        .   refer_clock             (   refer_clock));

    initial_config#(
        .   sizes_ascii             (   sizes_ascii),
        .   sizes_panel             (   sizes_panel),
        .   limit_chain             (   limit_chain),
        .   limit_ports             (1<<expon_ports),
        .   double_side             (   double_side),
        .   F_L_Forward             (   F_L_Forward),
        .   F_R_Forward             (   F_R_Forward),

        .   expon_setup             (   expon_setup))//
    initial_config (
        .   ascii_sizes             (   ascii_sizes),
        .   panel_bound             (   panel_sizes),   //->
        .   block_bound             (   block_sizes),   //->maximum
        .   access_envm             (   access_envm),   //<-arsenal
        .   setup_write             (   setup_write),   //<-arsenal
        .   setup_qbyte             (   setup_qbyte),   //<-arsenal
        .   setup_ready             (   setup_ready),   //<-arsenal
        .   refer_clock             (   refer_clock));

    memory_control#(
        .   mem_bit_ctl             (   mem_bit_ctl),
        .   mem_bit_bnk             (   mem_bit_bnk),
        .   mem_bit_row             (   mem_bit_row),
        .   mem_bit_col             (   mem_bit_col),
        .   mem_bit_dat             (   mem_bit_dat),
        .   expon_ports             (   expon_ports),
        .   expon_burst             (   expon_burst),
        .   expon_hight             (   expon_hight), //
        .   expon_width             (   expon_width))
    memory_control(
        .   memory_ctrl             (   memory_ctrl),
        .   memory_bank             (   memory_bank),
        .   memory_page             (   memory_page),
        .   memory_addr             (   memory_addr),
        .   memory_data             (   memory_data),
        .   image_clock             (   image_clock),
        .   image_vsync             (   image_vsync),
        .   image_hsync             (   image_hsync),
        .   image_esync             (   image_esync),
        .   image_pixel             (   image_pixel),
        .   image_hight             (   image_hight),
        .   image_width             (   image_width),
        .   image_frame             (   image_frame),
        .   coeffis_det             (   coeffis_det),//type_memory , type_linear
        .   coeffis_set             (   coeffis_set),//cpu.w
        .   coeffis_get             (   coeffis_get),//cpu.r
        .   coeffis_stb             (   coeffis_stb),
        .   coeffis_row             (   coeffis_row),//
        .   coeffis_col             (   coeffis_col),//
        .   coeffis_xyz             (   coeffis_xyz),//
        .   coeffis_bit             (   coeffis_bit),//b[6],g[5],r[4],gray[3:0]

        .   panel_sizes             (   panel_sizes),

        .   inside_port             (   inside_port),

        .   mazes_hight             (   mazes_hight),       //  arsenal(maze_core.loop[1/2/3])
        .   mazes_width             (   mazes_width),       //  arsenal(maze_core.loop[1/2/3])
        .   mazes_blank             (   mazes_blank),       //  maze_core   ->  
        .   mazes_timer             (   mazes_timer),       //  maze_engine ->  
        .   mazes_close             (   mazes_close),       //  maze_engine ->  
        .   mazes_frame             (   mazes_frame[0]),    //  maze_engine ->  
        .   mazes_reset             (   mazes_reset),       //  maze_engine ->  
        .   mazes_syncs             (   mazes_syncs),       //  maze_engine ->  
        .   refer_ready             (   refer_ready),//refer_ready
        .   refer_clock             (   refer_clock));

/*
    multi_frame

        65536*60 = 3932160  = 500000/12.715 =  1250000/31.79
        3932160/50000000    = 0.0786432     =   5153/65536          d762.939453125
        3932160/125000000   = 0.03145728    =   
*/
/*
    8W16H   32H     64H     128H
*/
    pattern #(
        .   expon_hight             (   expon_hight),//9, //512
        .   expon_width             (   expon_width))//9, //512
    pattern (
        .   pattern_ena             (   pattern_ena),       //  ->
        .   pattern_run             (   pattern_run),       //  ->
        .   pattern_adr             (   pattern_adr),       //  ->
        .   pattern_dat             (   pattern_dat[2:0]),  //  ->
//
        .   panel_count             (   panel_count[1:0]),  //  <-  {i2c,miso} expon_ports,expon_loop3 
        .   link_status             (   link_status),       //  <-  SERDES.Data Stream status
        .   link_select             (   link_select),       //  <-  SERDES.Data Stream Redundancy 
        .   network_col             (   network_col),       //  <-  SERDES.ID: scan board
        .   network_row             (   network_row),       //  <-  SERDES.ID: fiber/coaxial 
        .   pattern_mod             (   pattern_mod),       //  <-  protocol_inf
        .   pattern_sel             (   pattern_sel),       //  <-  protocol_inf
        .   frame_count             (   frame_count),       //  <-
      //.   multi_frame             (   multi_frame),       //  <-
        .   w08h16_addr             (   w08h16_addr),       //  ->  XPU.rom( texts_ascii[6:5],texts_hight[3:0],   texts_ascii[4:0],~texts_width[2:0])
        .   w08h16_font             (   w08h16_font),       //  <-  XPU.rom( bit)
        .   mazes_hight             (   mazes_hight),       //  <-  XPU
        .   mazes_width             (   mazes_width),       //  <-  XPU
        .   mazes_close             (   mazes_close),       //  <-  XPU.maze.engine
        .   mazes_chars             (   mazes_chars),       //  <-  XPU.maze.core
        .   place_chain             (   place_loops[loops_chain]),       //  <-  mazes_loops[]->pattern
        .   place_ports             (   place_ports),       //  <-  mazes_timer[]->pattern
//
        .   ascii_sizes             (   ascii_sizes),   //  initial
        .   panel_sizes             (   panel_sizes),   //  initial
        .   block_sizes             (   block_sizes),   //  initial
//
        .   refer_clock             (   refer_clock));////




            reg                         demux_infor;
            reg                         demux_width;
            reg                         demux_chain;//cascade_num
            reg                         demux_ports;//connect_num
            reg                         demux_error;
            reg                         demux_shows;
            reg                         demux_board;//id.board
            reg                         demux_optic;//id.fiber
always@(posedge refer_clock)demux_infor <= (random_task== 0)&&(random_seat[7:4]==0);//
always@(posedge refer_clock)demux_width <= (random_task== 0)&&(random_seat[7:0]==8'b01011110);// 94);
always@(posedge refer_clock)demux_chain <= (random_task== 0)&&(random_seat[7:0]==8'b01011111);// 95);
always@(posedge refer_clock)demux_ports <= (random_task== 0)&&(random_seat[7:5]==3'b011);//
always@(posedge refer_clock)demux_error <= (random_task== 0)&&(random_seat[7  ]==1'b1);//64..127
always@(posedge refer_clock)demux_shows <= (random_task== 7);
always@(posedge refer_clock)demux_board <= (random_task== 5);
always@(posedge refer_clock)demux_optic <=((random_task==13)||(random_task==14));//&&(random_seat[7:4]==0);

            wire[                 7:  0]information[15:0];
            wire[                 7:  0]pattern_get[ 1:0];
assign  information[ 0] =   version_int;
assign  information[ 1] =   version_dec;
assign  information[ 2] =   version_age-1990;
assign  information[ 3] =   version_mth;
assign  information[ 4] =   version_day;
assign  information[ 5] =   8'h55;
assign  information[ 6] =   8'haa;
assign  information[ 7] =   8'h5a;
assign  information[ 8] =   panel_sizes[0];//panel_width;//
assign  information[ 9] =   panel_sizes[1];//panel_hight;//
assign  information[10] =   block_sizes[0];//black_width;//
assign  information[11] =   11;//
assign  information[12] =   link_status;//
assign  information[13] =   link_select;//
assign  information[14] =   network_col;//
assign  information[15] =   network_row;//
assign  pattern_get[ 0] =  (pattern_mod==1)?(pattern_run?3:1):pattern_mod;
assign  pattern_get[ 1] =   pattern_adr;




always@(posedge refer_clock)SPI_LPC_MDI <=  //information[random_seat[3:0]];//error_check[random_seat[5:4]];
                        demux_infor?information[random_seat[3:0]]://
                      //demux_error?panel_error://[random_seat[2:0]][random_seat[5:4]]://[port],[chain]
                      //demux_ports?port_chains[random_seat[2:0]]://port[panel]
                      //demux_width?(black_width/panel_width)://
                    //  demux_chain?panel_chain:
                      //demux_board?network_col://id.board
                      //demux_optic?network_row://id.fiber
                        demux_shows?pattern_get[random_seat[  0]]:SPI_GET_MEM;
                      //coeffis_get?coeffis_dat:SPI_LPC_MDI;//




            wire[                  7: 0]ram2rom_sub;
            wire[                  7: 0]ram2rom_wex;
assign  ram2rom_sub =  (ram2rom_sel-1);
assign  ram2rom_wex = ((ram2rom_sub[7:3]==0)<<ram2rom_sub[2:0])|{8{(ram2rom_sel==0)}};
always@(posedge refer_clock)connect_wen <=(~ram2rom_wex);////assign  connect_wen = (~ram2rom_wex);
/**/



endmodule
