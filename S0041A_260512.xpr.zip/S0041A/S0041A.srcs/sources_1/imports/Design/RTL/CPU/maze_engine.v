  //`define step_integration

module  maze_engine//mazes_guide
#(
    parameter   scaler_loop     =   3,
//4*8
    parameter   frequencies     =   125000000,
    parameter   frame_rates     =   60,
    parameter   frame_lifes     =   3 
    
/**/
)(
//
    `ifdef  step_integration
    output  reg [                 23: 0]steps_range,
    output  reg [                 23: 0]frame_steps,
    `else
    input       [                 23: 0]steps_range,
    input       [                 23: 0]frame_steps,
    `endif
//
    output  reg [                 15: 0]mazes_steps,
    output  reg [                  7: 0]mazes_timer[2:0],//connect   
//
    output  reg                         mazes_close,//   PatternCtrl,mazes_black
    output  reg                         mazes_frame,//
    output  reg [                  2: 0]mazes_reset,//->maze core
//
    output  reg [                  2: 0]mazes_syncs,//

//
    input       [                  7: 0]timer_mazes[2:0],
//
    input                               self_enable,
//
  //input                               refer_syncs,
//
    input                               refer_frame,
//
    input                               refer_clock
);
/*

    frame   timing

*/
            wire[                 23: 0]frame_range;//125000000/60  =   2083333     1FCA05
assign  frame_range =   frequencies/frame_rates;

/*
            wire[                 11: 0]steps_range;//25*port8*ddr8     125M,375M
assign  steps_range =  (timer_mazes[0]*timer_mazes[1]*timer_mazes[2]);

            wire[                 15: 0]frame_steps;//2083333/1600  =   1302
assign  frame_steps = ((frame_range/steps_range)-1);//
*/
/*
            reg [                 23: 0]steps_range;
            reg [                  1: 0]multi_count;
            reg [                 23: 0]multi_adder;
always@(posedge refer_clock)multi_count <=  multi_count+1;
always@(posedge refer_clock)multi_adder <=(&multi_count)?1:(multi_adder*timer_mazes[multi_count]);//
always@(posedge refer_clock)steps_range <= (multi_count==3)?multi_adder:steps_range;
*/

/*
            reg [                  1: 0]multi_count;
            wire[                36 : 0]HARD_MULT_P;
            reg [                 23: 0]multi_adder;
          //reg [                 23: 0]steps_range;
    HARD_MULT_ADDSUB_C0//A0:18b B0:18B  C:36b   P:37b
    HARD_MULT_STEP (
        .   A0              (   multi_adder), 
        .   B0              (   timer_mazes[multi_count]), 
        .   C               (   0), 
        .   P               (   HARD_MULT_P));//{gamma_calcs,gamma_bit04}), 
always@(posedge refer_clock)multi_count <=  multi_count+1;
always@(posedge refer_clock)multi_adder <=(&multi_count)?1:HARD_MULT_P;//
always@(posedge refer_clock)steps_range <= (multi_count==3)?multi_adder:steps_range;
*/

    `ifdef  step_integration
            reg [                  1: 0]multi_count;
            reg [                 23: 0]multi_adder;

always@(posedge refer_clock)multi_count <=  multi_count+1;
always@(posedge refer_clock)
    if( multi_count==0)
    begin
        multi_adder <=  timer_mazes[0];
        steps_range <=  steps_range;//
    end
    else
    begin
        multi_adder <=  timer_mazes[multi_count]*multi_adder;//
        steps_range <= (multi_count==3)?multi_adder:steps_range;//
    end

            reg [                 24: 0]steps_frame;
            reg [                 16: 0]steps_count;
          //reg [                 15: 0]frame_steps;//5425~"2711"~255   13b~7bit
            reg                         inside_step;
            reg                         timer_ready;
always@(posedge refer_clock)inside_step <=((steps_range[23:14]==0)&&(|steps_range[13: 0]))||((steps_range[23:7]==0)&&(|steps_range[6: 0]));//
always@(posedge refer_clock)
    if( steps_frame[24]||(!inside_step))
    begin
        steps_frame <=  frame_range;
        steps_count <=  0;
        frame_steps <=  timer_ready?(steps_count-2):2711;
        timer_ready <=  steps_frame[24];//
    end
    else
    begin
        steps_frame <=  steps_frame-steps_range;//
        steps_count <=  steps_count+(!steps_count[16]);
        frame_steps <=  frame_steps;//
        timer_ready <=  timer_ready;//
    end
    `endif
            reg                         frame_carry;//
always@(posedge refer_clock)frame_carry <= (mazes_steps== frame_steps);//

            reg                         image_carry;//
always@(posedge refer_clock)image_carry <= (mazes_steps==(frame_steps>>1));//

/*

    pixel   timing

*/
            reg [                  2: 0]timer_carry;
            reg [                  7: 0]timer_ratio[2:0];//initial timer_limit= 3'b111;//
            wire[                  7: 0]timer_limit[2:0];
assign  timer_limit[0]  =  (timer_mazes[0]-2);//
assign  timer_limit[1]  =  (timer_mazes[1]-1);//
assign  timer_limit[2]  =  (timer_mazes[2]-1);//
always@(posedge refer_clock)timer_carry[0]  <= (timer_limit[0]==timer_ratio[0]);//
always@(posedge refer_clock)timer_carry[1]  <= (timer_limit[1]==timer_ratio[1]);//
always@(posedge refer_clock)timer_carry[2]  <= (timer_limit[2]==timer_ratio[2]);//

initial timer_carry[0] =   1;//
initial timer_carry[1] =   1;//
initial timer_carry[2] =   1;//
initial timer_ratio[0] =   2;//
initial timer_ratio[1] =   1;//
initial timer_ratio[2] =   1;//

always@(posedge refer_clock)
    if( timer_carry[0])
        timer_ratio[0]  <=  0;//
    else
        timer_ratio[0]  <=  timer_ratio[0]+1;//

always@(posedge refer_clock)
    if(&timer_carry[1:0])
        timer_ratio[1]  <=  0;//
    else
        timer_ratio[1]  <=  timer_ratio[1]+  timer_carry[0];//

always@(posedge refer_clock)
    if(&timer_carry[2:0])
        timer_ratio[2]  <=  0;//
    else
        timer_ratio[2]  <=  timer_ratio[2]+(&timer_carry[1:0]);//


            reg [                  3: 0]test_filter;initial test_filter =   1;//test_filter
            reg                         test_enable;initial test_enable =   1;//test_enable
always@(posedge refer_clock)test_filter <=  timer_carry[0]?{test_filter,self_enable}:test_filter;
always@(posedge refer_clock)test_enable <=  timer_carry[0]?(test_enable?(|test_filter):(&test_filter)):test_enable;


            reg                         frame_phase;initial frame_phase =   0;//test_enable
always@(posedge refer_clock)frame_phase     <=  test_enable ?   frame_phase :   refer_frame;//

/*

    

*/
always@(posedge refer_clock)mazes_syncs[0]  <=  timer_carry[  0];
always@(posedge refer_clock)mazes_syncs[1]  <=(&timer_carry[1:0]);
always@(posedge refer_clock)mazes_syncs[2]  <=(&timer_carry[2:0]);

always@(posedge refer_clock)mazes_timer[0]  <=  timer_ratio[0];
always@(posedge refer_clock)mazes_timer[1]  <=  timer_ratio[1];
always@(posedge refer_clock)mazes_timer[2]  <=  timer_ratio[2];

always@(posedge refer_clock)mazes_frame     <=(&timer_carry[2:0])?frame_phase:mazes_frame;//
/*

    

*/
            reg [                  4: 0]frame_check;initial frame_check = 1;//0;//threshold
            reg                         frame_black;initial frame_black = 1;//0;//threshold
always@(posedge refer_clock)//
    if(&timer_carry[2:0])
        if( mazes_frame^frame_phase)
            frame_check <= {frame_check,2'b11};
          //frame_check <= {frame_check,3'b111};
        else
            if( image_carry)
                frame_check <= (frame_check>>1);//
              //frame_check <= (frame_check>>2);//
            else
                frame_check <=  frame_check;//
    else
        frame_check <=  frame_check;//

always@(posedge refer_clock)//
    if(&timer_carry[2:0])
        if( image_carry)
            if(&frame_check)
                frame_black <=  0;//
            else
            if( frame_check==0)
                frame_black <=  1;//
            else
                frame_black <=  frame_black;
        else
                frame_black <=  frame_black;
    else
                frame_black <=  frame_black;
/*

    

*/

                                                    initial mazes_close = 0;//1;//
                                                    initial mazes_steps = 0;//1;//

always@(posedge refer_clock)
    if(&timer_carry[2:0])
        if( frame_black)
            if( frame_carry)//  {test_dark,auto_dark}
            begin
                mazes_close <=  1;
                mazes_reset <=  1;//
                mazes_steps <=  0;//mazes_steps
            end
            else
            begin
                mazes_close <=  1;
                mazes_reset <= {mazes_reset,1'b0};
                mazes_steps <= (mazes_steps+1);//
            end
        else
            if( mazes_frame^frame_phase)
            begin   //normal,auto_close
                mazes_close <=  0;
                mazes_reset <=  1;//
                mazes_steps <=  0;//
            end
            else
            begin
                mazes_close <=  0;
                mazes_reset <= {mazes_reset,1'b0};
                mazes_steps <= (mazes_steps+1);//
            end
    else
            begin
                mazes_close <=  frame_black;//
                mazes_reset <=  mazes_reset;//
                mazes_steps <=  mazes_steps;//
            end




endmodule