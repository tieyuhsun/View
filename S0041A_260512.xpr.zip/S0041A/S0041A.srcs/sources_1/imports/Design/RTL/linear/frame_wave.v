//`define ext_acc
module frame_wave#(
/*
  //96000000/(1<<16)    =   1464.84375
    frame = 16ms
*/
    parameter   expon_range = 16,
    parameter   expon_frame = 5,
    parameter [ expon_range-1:0]table_slope[(1<<expon_frame)-1:0] = 
               {
                    60727   ,
                    56132   ,
                    51745   ,
                    47566   ,
                    43590   ,
                    39815   ,
                    36238   ,
                    32856   ,
                    29666   ,
                    26664   ,
                    23847   ,
                    21212   ,
                    18755   ,
                    16473   ,
                    14361   ,
                    12416   ,
                    10635   ,
                    9012    ,
                    7543    ,
                    6225    ,
                    5051    ,
                    4019    ,
                    3121    ,
                    2352    ,
                    1707    ,
                    1179    ,
                    761     ,
                    445     ,
                    223     ,
                    84      ,
                    16      ,
                    0
                }
)
(
    output  wire[   expon_range-1   : 0]frame_delta,
    input       [   expon_frame-0   : 0]frame_count
);


assign  frame_delta =   frame_count[expon_frame]?table_slope[~frame_count[expon_frame-1:0]]:table_slope[frame_count[expon_frame-1:0]];//




endmodule