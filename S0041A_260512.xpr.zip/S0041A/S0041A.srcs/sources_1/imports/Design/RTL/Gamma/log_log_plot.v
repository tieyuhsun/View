module log_log_plot#(
//logarithmic 
//0.1 log.x     ZeroPointOneLog_32b10a  ZPOLog32b10a

//slope  = table[index]*(0.1 log curve)

    parameter   [                4  : 0]gamma_table[15:0] = {5'd30,5'd29,5'd28,5'd27,5'd26,5'd25,5'd24,5'd23,5'd22,5'd21,5'd20,5'd19,5'd18,5'd17,5'd16,5'd10},
    parameter   files_exp01     =   "./ZPOLog32b10a.mem",
    parameter   expon_exp10     =  10,//
    parameter       expon_gamma =   8 //
)
( 
    output  reg                         gamma_catch,//gamma_catch
    output  reg [   expon_gamma-1   : 0]gamma_curve,//gamma_curve
    output  reg [               32  : 0]gamma_slope,//gamma_slope
    output  reg                         gamma_ready,//gamma_ready
    input       [               3   : 0]gamma_index,
//
    input                               ahb_bus_ena,
    input                               ahb_bus_stb,
    input       [               31  : 0]ahb_bus_adr,
    input       [               31  : 0]ahb_bus_dat,
//
    input                               cache_tasks,
//
    input                               refer_clock
);

            reg [               5   : 0]power_expon;initial power_expon = 0;
            reg [   expon_exp10-1   : 0]power_curve;initial power_curve = 0;
always@(posedge refer_clock)
    if(&power_expon[4:0])
    begin
        power_expon <=  0;
        power_curve <= (power_curve+(1<<(expon_exp10-expon_gamma)));//|((1<<(expon_exp10-expon_gamma))-1);
    end
    else
    begin
        power_expon <=  power_expon+1;
        power_curve <=  power_curve;
    end



            reg [               5   : 0]exp01_expon;
            reg [   expon_exp10-1   : 0]exp01_curve;
            reg                         exp01_begin;
            reg [               31  : 0]exp01_exrom;//external memory
            wire[               31  : 0]exp01_cache;//cache memory
            wire[               31  : 0]exp01_coefs;
always@(posedge refer_clock)exp01_expon <=  cache_tasks ?   power_expon     : ((ahb_bus_ena&&ahb_bus_stb)?0:exp01_expon+(!exp01_expon[5]));
always@(posedge refer_clock)exp01_curve <=  cache_tasks ?   power_curve     :  (ahb_bus_adr>>2);
always@(posedge refer_clock)exp01_begin <=  cache_tasks ?  (power_expon==0) :  (ahb_bus_ena&&ahb_bus_stb);
always@(posedge refer_clock)exp01_exrom <= (ahb_bus_ena&&ahb_bus_stb)   ?ahb_bus_dat:exp01_exrom;
    xram #(
        .   memory_file             (   files_exp01),//"./square32b10a.mem"
        .   expon_chars             (   32),//32),//18),//9, //512
        .   expon_local             (   expon_exp10))
    buffer_exp01 (
        .   write_clock             (   refer_clock), 
        .   write_local             (  (ahb_bus_adr>>2)),//
        .   write_syncs             (  (ahb_bus_stb&&ahb_bus_ena)),//
        .   write_chars             (   ahb_bus_dat),
        
        .   carry_clock             (   refer_clock),
        .   carry_local             (   power_curve),//(locate_maze>>1)),
        .   carry_chars             (   exp01_cache));
assign  exp01_coefs = cache_tasks?exp01_cache:exp01_exrom;
/*

    34b = 17b*17b
    
        exp01_begin :   dsp[0]      =  (exp01.17/32b*0)+(exp01.32/32b<<2)
                        dsp[n+1]    =  (exp01.17/32b*dsp[n+0].17/32b)+dsp[n+0].18/32b


*/

            reg [               31  : 0]maccs_slope;
            reg [               1   : 0]maccs_bit02;
            wire[               17  : 0]maccs_17bit;//signed 18bit = unsigned 17bit
            wire[               34  : 0]maccs_34bit;//signed 35bit = unsigned 14bit
assign  maccs_17bit =   exp01_begin?0                       :maccs_slope[31:15];    //17bit
assign  maccs_34bit =   exp01_begin?{exp01_coefs,2'b00}|0   :exp01_coefs[31:15]|0;  //
always@(posedge refer_clock)   {maccs_slope,maccs_bit02}<=  (exp01_coefs[31:15]*maccs_17bit)+maccs_34bit;//

            reg [               4   : 0]maccs_expon;
            reg [   expon_gamma-1   : 0]maccs_curve;
            reg                         maccs_begin;
            reg [               31  : 0]maccs_coefs;
always@(posedge refer_clock)maccs_expon <=  exp01_expon;//exp01_expon
always@(posedge refer_clock)maccs_curve <=  exp01_curve>>(expon_exp10-expon_gamma);
always@(posedge refer_clock)maccs_begin <=  exp01_begin;
always@(posedge refer_clock)maccs_coefs <=  exp01_coefs;//
/*

*/
always@(posedge refer_clock)gamma_slope <=  maccs_begin?(1<<32) :maccs_slope ;//+ (maccs_coefs>>16);//
always@(posedge refer_clock)gamma_catch <= (gamma_table[gamma_index[3:0]]==(maccs_expon+1))&&gamma_ready;//
always@(posedge refer_clock)gamma_curve <=  maccs_curve;//

            reg                         gamma_begin;
            reg                         gamma_exp24;
            reg                         gamma_exp10;
always@(posedge refer_clock)gamma_begin <= (maccs_curve== 0);
always@(posedge refer_clock)gamma_exp24 <= (maccs_expon==23);
always@(posedge refer_clock)gamma_exp10 <= (maccs_expon== 9);//

            reg [   expon_gamma-1   : 0]exp10_slope;
            reg                         exp10_match;
            reg                         exp10_check;
/*
always@(posedge refer_clock)exp10_slope <=  gamma_exp10 ?((gamma_slope+(maccs_coefs>>14))>>(32-expon_gamma)):exp10_slope;//
*/
always@(posedge refer_clock)exp10_slope <=  gamma_exp10 ?((gamma_slope+(exp01_coefs>>14))>>(32-expon_gamma)):exp10_slope;//
always@(posedge refer_clock)exp10_match <= (exp10_slope==gamma_curve);//
always@(posedge refer_clock)
    if( gamma_exp24)
        if( gamma_begin)
        begin
            exp10_check <=  exp10_match;//
            gamma_ready <=  exp10_check;
        end
        else
        begin
            exp10_check <= (exp10_check&&exp10_match);//
            gamma_ready <= (gamma_ready&&exp10_match);//
        end
    else
        begin
            exp10_check <=  exp10_check;
            gamma_ready <=  gamma_ready;
        end

endmodule
