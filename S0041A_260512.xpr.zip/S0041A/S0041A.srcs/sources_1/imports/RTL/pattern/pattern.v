module  pattern
#(
/*
    initial_config
*/
    parameter   expon_setup     =   3,

/*
    Display:ASCII
*/
    parameter   [   15  :   0]pattern_row[1:0]= {4'H0,4'H0},////
    parameter   [   15  :   0]pattern_col[1:0]= {4'H0,4'H0},//// 
    parameter   [   3   :   0]zooms_hight[1:0]= {4'H0,4'H0},////
    parameter   [   3   :   0]zooms_width[1:0]= {4'H0,4'H0},//// 
/*
*/
    parameter   [   7   :   0]main_dimmer[2:0]= { 8'hff, 8'hff, 8'hff},//dimmeds_osd
    parameter   [   7   :   0]edge_dimmer[2:0]= { 8'h10, 8'h10, 8'h10},//dimmeds_osd
/*
*/
    parameter   expon_hight     =   9, //
    parameter   expon_width     =   9,//
    parameter   off_dot_run     =   0, //512
    parameter   off_dot_def     =   12,//12: Black
    parameter   scroll_rate     =   8// 0 =(2^16)/60 = 1K*sec, 1:546*sec, 2:273*sec ,3:136*sec ,4:68*sec, 5:34*sec ,6:17*sec,7:8*sec
)(
/*
    IO
*/
    input       [               3   : 0]panel_count[1:0],   //  <-  expon_ports,expon_chain
/*
    SERDES
*/
    input       [               1   : 0]link_status,        //  <-  SERDES.Data Stream status
    input                               link_select,        //  <-  SERDES.Data Stream Redundancy 
    input       [               7   : 0]network_col,        //  <-  SERDES.ID: scan board
    input       [               5   : 0]network_row,        //  <-  SERDES.ID: fiber/coaxial 
/*
    Protocol
*/
  //input                               pattern_rst,        //  <-  protocol_inf    reset frame_count
    input       [               7   : 0]pattern_mod,        //  <-  protocol_inf
    input       [               7   : 0]pattern_sel,        //  <-  protocol_inf
/*
        Scroll
*/
    input       [               15  : 0]frame_count,        // 
  //input       [               15  : 0]multi_frame,        // multi_frame
/**/
    output  reg [               1   : 0]pattern_ena,        //
    output  reg                         pattern_run,        //
    output  reg [               3   : 0]pattern_adr,        //
/**/
    output  wire[               7   : 0]pattern_dat[2:0],        //



/*
    8W16H   32H     64H     128H
*/
    output  wire[               13  : 0]w08h16_addr,        //  ->  XPU.rom( texts_ascii[6:5],texts_hight[3:0],   texts_ascii[4:0],~texts_width[2:0])
    input                               w08h16_font,        //  <-  XPU.rom( bit)

/*

*/

  //output  wire[ (   expon_block)-1: 0]shift_hight,        //  ->
  //output  wire[ (   expon_block)-1: 0]shift_width,        //  ->

/*
*/
    input       [               15  : 0]mazes_hight,        //  <-  XPU
    input       [               15  : 0]mazes_width,        //  <-  XPU
    input                               mazes_close,        //  <-  XPU.maze.engine
    input       [               17  : 0]mazes_chars,        //  <-  XPU.maze.core

    input       [               7   : 0]place_chain,        // mazes_loops[]->pattern
    input       [               7   : 0]place_ports,        // mazes_timer[]->pattern
/*

*/
    input       [               7   : 0]ascii_sizes[1:0],
    input       [               15  : 0]panel_sizes[1:0],
    input       [               15  : 0]block_sizes[1:0],//  ->
/*
*/

    input                               refer_clock         //  <-  XPU
);

            wire                        lines_black;        //  ->  pattern
            wire                        lines_panel;        //  ->  pattern
    outline#(
        .   expon_hight             (   expon_hight),//
        .   expon_width             (   expon_width))//
    outline (
        .   lines_black             (   lines_black),   //->
        .   lines_panel             (   lines_panel),   //->
        .   mazes_hight             (   mazes_hight),   //<-xPU
        .   mazes_width             (   mazes_width),   //<-xPU
        .   panel_sizes             (   panel_sizes),   //<-initial_config
        .   panel_count             (   panel_count));  //->

            wire                        scroll_ctrl;//direction
            wire[               7   : 0]scroll_wave;
    scroll#(
        .   expon_hight             (   expon_hight),//
        .   expon_width             (   expon_width))
    scroll (
        .   block_sizes             (   block_sizes), 
        .   mazes_hight             (   mazes_hight), 
        .   mazes_width             (   mazes_width), 
        .   frame_count             (   frame_count>>1), 
        .   scroll_ctrl             (   scroll_ctrl),//direction
        .   scroll_wave             (   scroll_wave),//); 
        .   refer_clock             (   refer_clock));

            wire[               3   : 0]network_num[2:0];//
    HEX2BCD#(
        .   Combination             (   3))//
    BCD_ID (
        .   HEX_SET_DAT             (   network_col),
        .   BCD_GET_DAT             (   network_num));//
/*
    display mode
        [15:8]
            0 : Normal
            1 : Circle pattern
            2 : Fixed pattern, decided by pattern no.
            3 : Line buffer test pattern
        [ 7:0]
            0 : RED
            1 : GRN
            2 : BLU
            3 : PAT1
            4 : PAT2
            5 : PAT3
            6 : PAT4
            7 : COL1
            8 : COL2
            9 : ROW1
            10: ROW2
            11: ID ADDRESS
            12: Black
            13: White
            14: panel ID
 Display mode
0: Normal
1: Circle pattern
2: Fixed pattern, decided by pattern no.
3: Line buffer test pattern

*/
/*
      x pattern{0..15,0..15}    x   ~1sec
      v pattern{0..15}          x   ~2sec
      v scroll {0..3}           x   ~8.5sec wave    //  H[w],H[b],H[g],H[r]
      x pattern{0..15,0..15}    x   ~1sec
      v pattern{0..15}          x   ~2sec
      v scroll {7..4}           x   ~8.5sec wave    //  V[w],V[b],V[g],V[r]

*/
always@(posedge refer_clock)
    if( pattern_mod == 1)// Circle pattern  [Display all]
    begin
        pattern_ena <=  1;
        pattern_run <=  frame_count[11];//34.133 sec
        pattern_adr <=  frame_count[11]?   {frame_count[13:12],frame_count[10: 9]}://
                                           {frame_count[10: 9],frame_count[ 8: 7]};
                                         //{frame_count[ 9: 8],frame_count[ 7: 6]};
/*
        pattern_run <=  show_timing[ 3];
        pattern_adr <=  show_timing[ 3]?   {show_timing[5:4],show_timing[2:1]}:
                                           {show_timing[1:0],scale_timer[15:14]};
*/
    end
    else
    if( pattern_mod == 2)// Fixed pattern
    begin
        pattern_ena <=  1;
        pattern_run <=  0;
        pattern_adr <=  pattern_sel[ 3: 0];//
    end
    else
    if( pattern_mod == 3)// Line buffer test pattern
    begin
        pattern_ena <=  1;
        pattern_run <=  1;
        pattern_adr <=  frame_count[11: 9];//   8 x 8.5sec
        //  V[w],V[b],V[g],V[r]
        //  H[w],H[b],H[g],H[r]
    end
    else
    begin   // Bagua or Normal or loss Signal
        pattern_ena <=( pattern_mod==4)?2:(mazes_close?1:0);
        pattern_run <=  mazes_close? off_dot_run:0;//off_dot_run
        pattern_adr <=  mazes_close?(off_dot_run?frame_count[11: 9]:off_dot_def):12;
    end
assign  scroll_ctrl =   pattern_adr[2];     //  V[w],V[b],V[g],V[r],H[w],H[b],H[g],H[r]



/*
    Display all
        frame_count[   11]  show_timing[ 3]=0               show_timing[ 3]=1
                            2xframe_count[ 9: 6]            frame_count[10: 9]  H:R,G,B,W
                            2xframe_count[ 9: 6]            frame_count[10: 9]  H:R,G,B,W
                            2xframe_count[ 9: 6]            frame_count[10: 9]  V:R,G,B,W
                            2xframe_count[ 9: 6]            frame_count[10: 9]  V:R,G,B,W
    Line buffer test pattern
        R,G,B,W horizontal

*/


/*

    ascii

*/

            wire[               7   : 0]ascii_bytes[1:0][3:0];
            wire[               15  : 0]ascii_local[1:0][1:0];
            wire[               1   : 0]ascii_blank;
            wire                        ascii_guide;//
assign  ascii_bytes[1][0]   =  (8'h41+place_ports);//8
assign  ascii_bytes[1][1]   =  (8'h30+place_chain);//
assign  ascii_bytes[1][2]   =   " ";
assign  ascii_bytes[1][3]   =   " ";
assign  ascii_bytes[0][0]   =  (link_status==0)?((frame_count[1:0]==0)?" ":"."):(network_row[0]?"'":" ");
assign  ascii_bytes[0][1]   =  (link_status==0)?((frame_count[1:0]==1)?" ":"."):(8'h41+network_row[3:2]);//(link_status[1]&&(link_select==1))?"`":
assign  ascii_bytes[0][2]   =  (link_status==0)?((frame_count[1:0]==2)?" ":"."):(network_num[1]==0)?" ":(8'h30+network_num[1]);
assign  ascii_bytes[0][3]   =  (link_status==0)?((frame_count[1:0]==3)?" ":"."):(8'h30+network_num[0]);

assign  ascii_local[1][1]   =  (mazes_hight         +pattern_row[1])<<zooms_hight[1];//
assign  ascii_local[1][0]   =  (mazes_width         +pattern_col[1])<<zooms_width[1];//
assign  ascii_local[0][1]   =  (mazes_chars[15: 8]  +pattern_row[0])<<zooms_hight[0];//
assign  ascii_local[0][0]   =  (mazes_chars[ 7: 0]  +pattern_col[0])<<zooms_width[0];//

assign  ascii_blank[1]      =  (ascii_local[1][1]>=block_sizes[1])||(ascii_local[1][0]>=block_sizes[0])||(|(ascii_local[1][0]>>4));//
assign  ascii_blank[0]      =  (ascii_local[0][1]>=panel_sizes[1])||(ascii_local[0][0]>=panel_sizes[0])||(|(ascii_local[0][0]>>4));//

assign  ascii_guide         =   pattern_adr[0];//

/*


    14: panel ID        1110
    11: ID ADDRESS      1011

        font,16H,8W*4 = 16H,64W
    
*/

assign  w08h16_addr[13:12]  =   ascii_bytes[ascii_guide][ascii_local[ascii_guide][0][ 4: 3]][ 6: 5];//
assign  w08h16_addr[11: 8]  =   ascii_local[ascii_guide][1][ 3: 0];//16H
assign  w08h16_addr[ 7: 3]  =   ascii_bytes[ascii_guide][ascii_local[ascii_guide][0][ 4: 3]][ 4: 0];//
assign  w08h16_addr[ 2: 0]  =   ascii_local[ascii_guide][0][ 2: 0];//8W
assign  w08h16_mask         =   ascii_blank[ascii_guide];//

/*

    dot
        0:ON/OFF
        1: bound.outline

*/
            wire[                  2: 0]decoder_dot[1:0][15:0];//
assign  decoder_dot[0][ 0]  =   3'b001;
assign  decoder_dot[0][ 1]  =   3'b010;
assign  decoder_dot[0][ 2]  =   3'b100;
assign  decoder_dot[0][ 3]  = (!mazes_hight[0])?3'b111:0;//mazes_hight
assign  decoder_dot[0][ 4]  = (!mazes_width[0])?3'b111:0;//mazes_width
assign  decoder_dot[0][ 5]  = (!mazes_hight[0])&&(!mazes_width[0])?3'b111:0;
assign  decoder_dot[0][ 6]  = ( mazes_hight[0])&&( mazes_width[0])?3'b111:0;
assign  decoder_dot[0][ 7]  = ( mazes_width[1])?3'b111:0;
assign  decoder_dot[0][ 8]  = (!mazes_width[1])?3'b111:0;
assign  decoder_dot[0][ 9]  = (!mazes_hight[1])?3'b111:0;
assign  decoder_dot[0][10]  = ( mazes_hight[1])?3'b111:0;
assign  decoder_dot[0][11]  =   w08h16_mask?0:{3{w08h16_font}};
assign  decoder_dot[0][12]  =   0;//B
assign  decoder_dot[0][13]  =   7;//W
assign  decoder_dot[0][14]  =   w08h16_mask?0:{3{w08h16_font}};
assign  decoder_dot[0][15]  ={3{(mazes_hight[ 2: 0]==mazes_width[ 2: 0])}};//undef

assign  decoder_dot[1][ 0]  =   0;                  //0 : RED
assign  decoder_dot[1][ 1]  =   0;                  //1 : GRN
assign  decoder_dot[1][ 2]  =   0;                  //2 : BLU
assign  decoder_dot[1][ 3]  =   0;                  //3 : PAT1
assign  decoder_dot[1][ 4]  =   0;                  //4 : PAT2
assign  decoder_dot[1][ 5]  =   0;                  //5 : PAT3
assign  decoder_dot[1][ 6]  =   0;                  //6 : PAT4
assign  decoder_dot[1][ 7]  =   0;                  //7 : COL1
assign  decoder_dot[1][ 8]  =   0;                  //8 : COL2
assign  decoder_dot[1][ 9]  =   0;                  //9 : ROW1
assign  decoder_dot[1][10]  =   0;                  //10: ROW2
assign  decoder_dot[1][11]  =   {3{lines_black}};   //11: ID ADDRESS
assign  decoder_dot[1][12]  =   0;                  //12: Black
assign  decoder_dot[1][13]  =   0;                  //13: White
assign  decoder_dot[1][14]  =   {3{lines_panel}};   //14: panel ID
assign  decoder_dot[1][15]  =   0;                  //undef

/*
*/
            wire[               7   : 0]pattern_wav[2:0];
            wire[               7   : 0]pattern_txt[2:0];
assign  pattern_wav[0]      = ((pattern_adr[1:0]==0)||(pattern_adr[1:0]==3))?scroll_wave:0;
assign  pattern_wav[1]      = ((pattern_adr[1:0]==1)||(pattern_adr[1:0]==3))?scroll_wave:0;
assign  pattern_wav[2]      = ((pattern_adr[1:0]==2)||(pattern_adr[1:0]==3))?scroll_wave:0;

assign  pattern_txt[0]      =  (decoder_dot[pattern_adr[3:0]][0][0]?main_dimmer[0]:0)|(decoder_dot[pattern_adr[3:0]][1][0]?edge_dimmer[0]:0);
assign  pattern_txt[1]      =  (decoder_dot[pattern_adr[3:0]][0][1]?main_dimmer[1]:0)|(decoder_dot[pattern_adr[3:0]][1][1]?edge_dimmer[1]:0);
assign  pattern_txt[2]      =  (decoder_dot[pattern_adr[3:0]][0][2]?main_dimmer[2]:0)|(decoder_dot[pattern_adr[3:0]][1][2]?edge_dimmer[2]:0);//<<3
/*
*/
assign  pattern_dat[0]      =   pattern_run?pattern_wav[0]:pattern_txt[0];
assign  pattern_dat[1]      =   pattern_run?pattern_wav[1]:pattern_txt[1];
assign  pattern_dat[2]      =   pattern_run?pattern_wav[2]:pattern_txt[2];



/*
network_row[5:4]    xor
network_row[3:2]    2'b00,2'b01,2'b10,2'b11     fiber[A/B/C/D]
network_row[1:0]    2'b10,2'b11                 coaxial

    serdes [31] TXD
    serdes [30] RXD
    serdes [29: 24] 識別碼 -> 使用協議 5 可讀取
    serdes [23: 0] RGB/CRC
*/





endmodule

