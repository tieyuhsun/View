/*
    
            11: ID ADDRESS  4'b1011
            14: panel ID    4'b1110
            
            <-  port_enable,port_chains     IO
            <-  panel_sizes[1],panel_sizes[0]     eNVM/ROM/parameter
            <-  mazes_chars                 eNVM/ROM
//
    Number  ->  vertical___,horizontal_
    Shift   ->  shift_hight,shift_width
    Line    ->  lines_black,lines_panel
*/

module  outline
#(
  //parameter   expon_ports     =   3,
  //parameter   expon_chain     =   3,
    parameter   [   7   :   0]panel_limit[1:0]= {8'H10,8'h10},//1<<expon_ports
  //parameter   panel_h_cnt     =   8;//1<<expon_chain
    
    parameter   expon_hight     =   9, //
    parameter   expon_width     =   9 //
    
)(
    input       [               15  : 0]mazes_hight,        //  arsenal(maze_core.loop[1/2/3])
    input       [               15  : 0]mazes_width,        //  arsenal(maze_core.loop[1/2/3])

    input       [               15  : 0]panel_sizes[1:0],   //  <-  initial_config
    input       [               3   : 0]panel_count[1:0],   //  <-  expon_ports,expon_chain

    output  wire                        lines_black,        //  ->  pattern
    output  wire                        lines_panel         //  ->  pattern
);


            reg [               15  : 0]panel_v_dat[panel_limit[1]-1:0];
            reg [   panel_limit[1]-1: 0]panel_v_dot;
            reg [               15  : 0]panel_h_dat[panel_limit[0]-1:0];
            reg [   panel_limit[0]-1: 0]panel_h_dot;
integer v;
always@(*)
begin
    for (v=0;v<panel_limit[1];v=v+1)
    begin
        panel_v_dat[0]      =   panel_sizes[1][0 +: expon_hight];//
        panel_v_dat[v+1]    =   panel_v_dat[v+1]+panel_sizes[1][0 +: expon_hight];
        panel_v_dot         =  (panel_v_dat[v]==mazes_hight)&&(panel_v_dat[v][15:expon_hight]==0);//
    end
end

integer h;
always@(*)
begin
    for (h=0;h<panel_limit[0];h=h+1)
    begin
        panel_h_dat[0]      =   panel_sizes[0][0 +: expon_width];//
        panel_h_dat[h+1]    =   panel_h_dat[h+1]+panel_sizes[0][0 +: expon_width];
        panel_h_dot         =  (panel_h_dat[h]==mazes_width)&&(panel_h_dat[h][15:expon_width]==0);//
    end
end


assign  lines_black =  (mazes_hight[expon_hight-1:0]==0)||(mazes_width[expon_width-1:0]==0)||(panel_v_dot[panel_count[1]])||(panel_h_dot[panel_count[0]]);//
assign  lines_panel =  (mazes_hight[expon_hight-1:0]==0)||(mazes_width[expon_width-1:0]==0)||(|panel_v_dot)||(|panel_h_dot);//



endmodule

