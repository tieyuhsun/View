/*
    Display all
        frame_count[   11]  show_timing[ 3]=0               show_timing[ 3]=1
                            2xframe_count[ 9: 6]            frame_count[10: 9]  H:R,G,B,W
                            2xframe_count[ 9: 6]            frame_count[10: 9]  H:R,G,B,W
                            2xframe_count[ 9: 6]            frame_count[10: 9]  V:R,G,B,W
                            2xframe_count[ 9: 6]            frame_count[10: 9]  V:R,G,B,W
    Line buffer test pattern
        R,G,B,W horizontal

*/
module  scroll
#(

  //parameter   expon_slope     =   16,

    parameter   expon_hight     =   9, //
    parameter   expon_width     =   9,//


    parameter   scroll_rate     =   8// 0 =(2^16)/60 = 1K*sec, 1:546*sec, 2:273*sec ,3:136*sec ,4:68*sec, 5:34*sec ,6:17*sec,7:8*sec

    
)(

/*

*/
    input       [               7   : 0]frame_count,
/*

*/
    output  wire[               15  : 0]block_sizes[1:0],
/*

*/
    input       [               15  : 0]mazes_hight,
    input       [               15  : 0]mazes_width,
/*

*/
    input                               scroll_ctrl,// V/H
    output  wire[               7   : 0]scroll_wave,
/*

*/
    input                               refer_clock
);
/*
    65535/192   =   341
        341*191 =   65131+170

*/

            wire[               15  : 0]slide_sizes[1:0];
            wire[               15  : 0]slide_slope[1:0];
            wire[               15  : 0]slide_local[1:0];
          //wire[               15  : 0]slide_timer;
assign  slide_local[1]  =   mazes_hight[expon_hight-1:0];
assign  slide_local[0]  =   mazes_width[expon_width-1:0];
//assign  slide_timer     =   frame_count>>scroll_rate;//
genvar i;
    generate
        for (i=0; i<(2); i=i+1)
        begin   //
assign  slide_sizes[i]  = ((block_sizes[i]>>4)==0)?{16{1'b1}}:(block_sizes[i]-1);
    DIVIDER#(
        .   Combination             (   0),
        .   exp_divider             (   16))//
    calc_slope (
        .   dividend___             ( {16{1'b1}}),
        .   divisor____             (  (slide_sizes[i])),
        .   quotient___             (   slide_slope[i]),
        .   refer_clock             (   refer_clock));
        end     // block: u
    endgenerate

            wire[               15  : 0]slide_value;            //DSP->
assign  slide_value =  (slide_slope[scroll_ctrl]*slide_local[scroll_ctrl])+(slide_slope[scroll_ctrl]>>1);//
/*
    V:0..255 + silde.time  (bit8=0  0..255    , bit8=1  255..0)
    H:0..255 + silde.time  (bit8=0  0..255    , bit8=1  255..0)

*/
            wire[               8   : 0]slide_waves[1:0];
assign  slide_waves[0]  =   slide_value[15: 8]+frame_count[7:0];//0..255
assign  slide_waves[1]  =   slide_value[15: 7]+frame_count[7:0];//0..511
//ckit
//

assign  scroll_wave =   slide_waves[0][8]?(~slide_waves[0][7:0]):( slide_waves[0][7:0]);//?



endmodule

