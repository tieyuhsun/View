//`define addr_mod
/*



gamma[1.0] = x^1 (x = [0~1])
gamma[2.0] = x^2 (x = [0~1])
gamma[3.0] = x^3 (x = [0~1])

-----------------
(n*2^16)^gamma_int

((n*2^16)^gamma_int)^(n*2^16)^gamma_dec

        .   gamma_value             (   color_value[color_texts]),//color_value[color_texts]),//(color_texts?  color_bitss:   color_image)), 
        .   gamma_curve             (   gamma_curve),//gamma_chars), 
        .   refer_clock             (   refer_clock));

10bit = 1024*30 = 30,720*clock = 30,7200ns = 
 8bit =  256*30 =  7,680*clock = 7,6800ns =
*/
module gamma_generate#(
    parameter   utilization = 0,
    parameter   grays_expon = 24
    
)
( 

    output  reg [               4   : 0]gamma_expon,//
    output  reg [               7   : 0]gamma_curve,
    output  reg [   grays_expon-1   : 0]gamma_value,
//
    input                               refer_reset,
    input                               refer_clock
);

            reg [               4   : 0]square_calc;initial square_calc = 0;  //0.1~3.1
            reg [               7   : 0]square_addr;initial square_addr = 0;  //8 bit gary
(* ram_style = "auto" *)reg [   35  : 0]square_char[255 :0];//the square root of 0.1
    initial begin  $readmemh("./square_01.hex", square_char);end
always@(posedge refer_clock)square_calc <= refer_reset ? 0: square_calc + 1;
always@(posedge refer_clock)square_addr <= refer_reset ? 0: square_addr + (&square_calc);//((&square_calc)&&(!square_addr[aw])) ;
/**/
            reg [               4   : 0]synced_calc;initial synced_calc = 0;  //0.1~3.1
            reg [               7   : 0]synced_addr;initial synced_addr = 0;  //8 bit gary
            reg                     synced_clar;    initial synced_clar = 0;  //8 bit gary
            reg [               35  : 0]synced_char;initial synced_char = 0;
always@(posedge refer_clock)synced_calc <=  square_calc;
always@(posedge refer_clock)synced_addr <=  square_addr;
always@(posedge refer_clock)synced_clar <= (square_calc==0);
always@(posedge refer_clock)synced_char <= {synced_char,square_char[square_addr]};

            reg [               4   : 0]calcs_expon;initial calcs_expon = 0;  //0.1~3.1
            reg [               7   : 0]calcs_curve;initial calcs_curve = 0;  //8 bit gary
            reg [               71  : 0]calcs_value;initial calcs_value = 0;
          //reg [(grays_expon+36)-1 : 0]calcs_value;initial calcs_value = 0;
always@(posedge refer_clock)calcs_expon <=  synced_calc;
always@(posedge refer_clock)calcs_curve <=  synced_addr;
always@(posedge refer_clock)calcs_value <=  synced_clar?(synced_char<<36):(calcs_value[71:36]*synced_char);//+calcs_value[35: 0];

//always@(posedge refer_clock)calcs_value <=  synced_clar?(synced_char<<grays_expon):(calcs_value[(grays_expon+36)-1:grays_expon]*synced_char);//+calcs_value[35: 0];

/*
24b:(24*2) =48b
48b-36b =12b , synced_char<<12

20b:(20*2) =40b
40b-36b = 4b , synced_char<<4

16b:(16*2) =32b
32b-36b = 4b , synced_char<<4
*/
            reg [(grays_expon<<1)-1 : 0]cheap_value;initial cheap_value = 0;
always@(posedge refer_clock)cheap_value <=  synced_clar?(synced_char<<((grays_expon<<1)-36)):(cheap_value[(grays_expon<<1)-1:grays_expon]*synced_char[35:(36-grays_expon)]);//+calcs_value[35: 0];


always@(posedge refer_clock)gamma_expon     <=  calcs_expon;
always@(posedge refer_clock)gamma_curve     <=  calcs_curve;
always@(posedge refer_clock)gamma_value     <= (utilization==1)?(calcs_value>>(72-grays_expon)):(cheap_value>>grays_expon);

/*
            reg [              4: 0]calcs_expon;  initial calcs_expon = 0;  //0.1~3.1
            reg [              7: 0]calcs_curve;  initial calcs_curve = 0;  //8 bit gary
            reg [             71: 0]calcs_value;  initial calcs_value = 0;
always@(posedge refer_clock)calcs_expon <=  synced_calc;
always@(posedge refer_clock)calcs_curve <=  synced_addr;
always@(posedge refer_clock)calcs_value <=  synced_clar?{synced_char,36'h0}:(calcs_value[71:36]*synced_char);//+calcs_value[35: 0];

always@(posedge refer_clock)gamma_expon <=  calcs_expon;
always@(posedge refer_clock)gamma_curve <=  calcs_curve;
always@(posedge refer_clock)gamma_value <=  calcs_value>>(72-36);
*/


endmodule


/*



*/