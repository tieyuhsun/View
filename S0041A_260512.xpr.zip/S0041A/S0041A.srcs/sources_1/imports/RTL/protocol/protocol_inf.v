module protocol_inf#
(

    parameter   pattern_def         =   16'h0000,
    parameter   gamma_reset         =   9,//
    parameter   dac_r_reset         =  (3<<4),//
    parameter   dac_g_reset         =  (2<<4),//
    parameter   dac_b_reset         =  (1<<4),//

    parameter   val_r_reset         =  8'h40,//8'h40
    parameter   val_g_reset         =  8'h40,//8'h40
    parameter   val_b_reset         =  8'h40,//8'h40
    parameter   val_a_reset         =  8'h10,//8'h10


    parameter   timeout_bit         =   7,//  //0x05/0x04
    
    parameter   type_linear         =   7'h02,  //0x05/0x04
        //  byte[2]: panel[row]      
        //  byte[3]: panel[col]      
        //  byte[4]: pixel[row] pixel[1D]
        //  byte[5]: pixel[col] pixel[1D]
        //  byte[6]: coefficient
        //           0=Rx[ 7: 0]    1=Rx[15: 8]     2=Ry[ 7: 0]     3=Ry[15: 8]     4=Rz[ 7: 0]     5=Rz[15: 8]
        //           6=Gx[ 7: 0]    7=Gx[15: 8]     8=Gy[ 7: 0]     9=Gy[15: 8]    10=Gz[ 7: 0]    11=Gz[15: 8]
        //          12=Bx[ 7: 0]   13=Bx[15: 8]    14=By[ 7: 0]    15=By[15: 8]    16=Bz[ 7: 0]    17=Bz[15: 8]     check_sum[?]
    parameter   type_random         =   7'h01,  //0x03/0x02
        //  byte[2]: command      
        //  byte[3]: command.address

    parameter   internal_ad =   0
    
)
(
//UART
    input                               BuatRatex32,
    input                               broadcaster,
//BUS.SPI
    input                               random_work,
    input       [                 7:  0]random_seat,
    input       [                 7:  0]random_task,//
    input       [                 7:  0]random_byte,
    input                               random_ctrl,
//
    output  reg [                  7: 0]identifiers,
    output  reg                         pattern_rst,
    output  reg [                  7: 0]pattern_mod,
    output  reg [                  7: 0]pattern_sel,
    output  reg [                  7: 0]bright_lv10,
    output  reg [                 23: 0]bright_data,
    output  reg [                  7: 0]gamma_index,//
    output  reg                         ram2rom_ctl,//ram2rom_ctl
    output  reg [                  7: 0]ram2rom_sel,//ram2rom_sel
    output  reg                         correct_ena,
    output  reg [                 47: 0]driver_gain,//
    
    output  reg                         pixel_close,
    output  reg                         white_close,
//
    output  reg                         reflash_ctl,
//
    output  reg [                  7: 0]comm_enable,
    output  reg [                  7: 0]comm_select,
//
    output  reg                         uart_pauses,
  //output  reg                         comm_dectct,
//
    input                               refer_ready,
    input                               refer_clock
/**/
);



            reg [                  1: 0]bright_link;
always@(posedge refer_clock)bright_link <=  BuatRatex32?{bright_link,refer_ready}:bright_link;


            reg                         bits_signal;
            reg [                 15: 0]bits_buffer;
            reg [                  4: 0]bits_period;initial bits_period = 0;//32
            reg [                  3: 0]bits_select;initial bits_select = 15;
            reg                         bits_ending;initial bits_ending = 1;//bits_finish
            reg [                  2: 0]bits_status;initial bits_status = 0;//bits_status
always@(posedge refer_clock)bits_signal <=  broadcaster;
always@(posedge refer_clock)
    if( BuatRatex32)
    if( bits_ending)//||(!refer_ready))//||(!(repeat_ctrl||return_ctrl)))
    begin
        bits_period             <=  bits_signal?(bits_period+1):0;//0
        bits_select             <=  15;// �� 
        bits_buffer             <=  bits_buffer;
        bits_status             <=  0;//step.0
        bits_ending             <=  bits_signal;
    end
    else
    begin//0~11,12off
        bits_period             <=  bits_period + 1;
        bits_select             <=((bits_period==31)&&(bits_select!=12)) ?(bits_select + 1): bits_select;//-1..12
        bits_buffer[bits_select]<=((bits_period==15)) ? bits_signal: bits_buffer[bits_select];
        if( bits_select[3]&&(bits_select!=15))
        begin
            bits_ending         <=  bits_signal;
            bits_status         <=  bits_signal?7:bits_status;
        end
        else
        begin   //step.1
            bits_ending         <=  0;
            bits_status         <= (bits_status==0)?1:2;
        end
    end
    else
    begin//
        bits_period             <=  bits_period;
        bits_select             <=  bits_select;
        bits_buffer             <=  bits_buffer;
        bits_status             <=  bits_status;
        bits_ending             <=  bits_ending;
    end

/**/
            reg                         uarts_label;
            reg                         uarts_clock;//rising falling
always@(posedge refer_clock)uarts_label <= (bits_period[3:0]==7);
always@(posedge refer_clock)uarts_clock <=  uarts_clock^(bits_period[3:0]==7);//



            reg                         uart_strobe;//rising falling     pack_strobe 
            reg [        timeout_bit: 0]uart_period;//115200 ~8.7us * 128 ~ 1ms     8b+5b =13b
            reg                         uart_noises;//
          //reg                         uart_pauses;//

  
            reg [                  3: 0]uart_enable;//
            reg [                 15: 0]uart_serial;//
            reg [                 23: 0]uart_queues;//



always@(posedge refer_clock)
    if( bits_ending)    //~byte
        if(!broadcaster)//byte.falling
            uart_period <=  0;
        else
            uart_period <= (uart_period[timeout_bit]?(uart_period|1):(uart_period+(BuatRatex32&&(bits_period==0))));//stop/restart
    else
            uart_period <=  uart_period+(bits_signal^broadcaster);//noise

always@(posedge refer_clock)uart_strobe <=  BuatRatex32&&(bits_status==7);//bits_ending.rising  uart_strobe
always@(posedge refer_clock)uart_noises <=(!bits_ending&&(uart_period[5]))||(bits_buffer[15]);//16
always@(posedge refer_clock)uart_pauses <=  bits_ending&&uart_period[timeout_bit];

always@(posedge refer_clock)uart_enable <=  uart_noises?0:
                                            uart_pauses?1:
                                            uart_strobe?{uart_enable,uart_enable[0]}:uart_enable;

/**/

          wire[                  7: 0]uart_buffer;//
assign  uart_buffer =   bits_buffer[7:0];//
always@(posedge refer_clock)uart_serial <= (uart_enable[1])?(uart_serial+uart_strobe):0;//
always@(posedge refer_clock)uart_queues <=  uart_strobe?{uart_queues,bits_buffer[7:0]}:uart_queues;


/**/
            reg [                 15: 0]pack_adders;//bits_status       
            reg                         pack_compar;//rising falling    
            reg [                  7: 0]pack_indify;//pack_groups       
            reg [                  7: 0]pack_groups;//pack_strobe       
            reg                         pack_inside;//rising falling
            reg                         pack_strobe;//rising falling
always@(posedge refer_clock)pack_adders <=  uart_enable[2]?(uart_strobe?(pack_adders+uart_queues[15: 8]):pack_adders):0;
always@(posedge refer_clock)pack_compar <= (pack_adders==uart_queues[15:0]);//

always@(posedge refer_clock)pack_indify <=((uart_enable== 1)&&uart_strobe)?bits_buffer[7:0]:pack_indify;
always@(posedge refer_clock)pack_groups <=((uart_serial== 3)&&uart_strobe)?bits_buffer[7:0]:pack_groups;


always@(posedge refer_clock)pack_inside <=  uart_enable[3]&&pack_compar&&(pack_indify== 0)&&(pack_groups==35);
always@(posedge refer_clock)pack_strobe <=  pack_inside&&(uart_enable==1);//

/*

    SPI ->  decode[1]
    UART->  decode[0]


*/



            reg [                  7: 0]random_addr;//
          //reg                         random_link;//
          //reg                         source_type;//
            reg [                  7: 0]source_task[1:0];//
            reg [                  7: 0]source_data[1:0][5:0];//



always@(posedge refer_clock)random_addr         <=  random_ctrl?random_addr:random_byte;

always@(posedge refer_clock)source_task[1]      <= (random_ctrl&&( random_addr== 1))?random_byte:source_task[1]   ;
always@(posedge refer_clock)source_data[1][0]   <= (random_ctrl&&( random_addr== 3))?random_byte:source_data[1][0];
always@(posedge refer_clock)source_data[1][1]   <= (random_ctrl&&( random_addr== 4))?random_byte:source_data[1][1];
always@(posedge refer_clock)source_data[1][2]   <= (random_ctrl&&( random_addr== 5))?random_byte:source_data[1][2];
always@(posedge refer_clock)source_data[1][3]   <= (random_ctrl&&( random_addr== 6))?random_byte:source_data[1][3];
always@(posedge refer_clock)source_data[1][4]   <= (random_ctrl&&( random_addr== 7))?random_byte:source_data[1][4];
always@(posedge refer_clock)source_data[1][5]   <= (random_ctrl&&( random_addr== 8))?random_byte:source_data[1][5];


always@(posedge refer_clock)source_task[0]      <= (uart_strobe&&( uart_serial== 4))?uart_buffer:source_task[0]   ;
always@(posedge refer_clock)source_data[0][0]   <= (uart_strobe&&( uart_serial== 6))?uart_buffer:source_data[0][0];
always@(posedge refer_clock)source_data[0][1]   <= (uart_strobe&&( uart_serial== 7))?uart_buffer:source_data[0][1];
always@(posedge refer_clock)source_data[0][2]   <= (uart_strobe&&( uart_serial== 8))?uart_buffer:source_data[0][2];
always@(posedge refer_clock)source_data[0][3]   <= (uart_strobe&&( uart_serial== 9))?uart_buffer:source_data[0][3];
always@(posedge refer_clock)source_data[0][4]   <= (uart_strobe&&( uart_serial==10))?uart_buffer:source_data[0][4];
always@(posedge refer_clock)source_data[0][5]   <= (uart_strobe&&( uart_serial==11))?uart_buffer:source_data[0][5];

//
            reg [                  1: 0]source_busy;
            reg [                  1: 0]source_ctrl;
always@(posedge refer_clock)source_busy[1]      <=  random_work;//?1:(BuatRatex32?0:source_idle[1]);
always@(posedge refer_clock)source_busy[0]      <=  pack_strobe&&(source_task[0][7:6]==0);//?1:(BuatRatex32?0:source_idle[0]);

always@(posedge refer_clock)source_ctrl[1]      <=  source_busy[1]&&(! random_work);//?1:(BuatRatex32?0:source_idle[1]);
always@(posedge refer_clock)source_ctrl[0]      <=  source_busy[0]&&(!(pack_strobe&&(source_task[0][7:6]==0)));//?1:(BuatRatex32?0:source_idle[0]);



/**/



//
            reg                         decode_ctrl;//
            reg [                  1: 0]decode_type;//
            reg [                  7: 0]decode_task;//
            reg [                  7: 0]decode_data[5:0];//
//
always@(posedge refer_clock)decode_ctrl     <=(|source_ctrl[1:0]);
always@(posedge refer_clock)decode_type     <=  source_ctrl[1]?1:(source_ctrl[0]?0:decode_type);
always@(posedge refer_clock)decode_task     <=  source_ctrl[1]?source_task[1]   :(source_ctrl[0]?source_task[0]   :decode_task   );//;(decode_sync&&decode_base[0])?   decode_byte:decode_task;
always@(posedge refer_clock)decode_data[0]  <=  source_ctrl[1]?source_data[1][0]:(source_ctrl[0]?source_data[0][0]:decode_data[0]);//;(decode_sync&&decode_base[1])?   decode_byte:decode_data[0];
always@(posedge refer_clock)decode_data[1]  <=  source_ctrl[1]?source_data[1][1]:(source_ctrl[0]?source_data[0][1]:decode_data[1]);//;(decode_sync&&decode_base[2])?   decode_byte:decode_data[1];
always@(posedge refer_clock)decode_data[2]  <=  source_ctrl[1]?source_data[1][2]:(source_ctrl[0]?source_data[0][2]:decode_data[2]);//;(decode_sync&&decode_base[3])?   decode_byte:decode_data[2];

always@(posedge refer_clock)decode_data[3]  <=  source_ctrl[1]?source_data[1][3]:(source_ctrl[0]?source_data[0][3]:decode_data[3]);//;(decode_sync&&decode_base[1])?   decode_byte:decode_data[0];
always@(posedge refer_clock)decode_data[4]  <=  source_ctrl[1]?source_data[1][4]:(source_ctrl[0]?source_data[0][4]:decode_data[4]);//;(decode_sync&&decode_base[2])?   decode_byte:decode_data[1];
always@(posedge refer_clock)decode_data[5]  <=  source_ctrl[1]?source_data[1][5]:(source_ctrl[0]?source_data[0][5]:decode_data[5]);//;(decode_sync&&decode_base[3])?   decode_byte:decode_data[2];

//
            wire                        scan_id_ctl;
            wire                        pattern_ctl;
            wire[                  1: 0]bright_ctrl;
            wire                        gamma_setup;
            wire                        correct_ctl;
            wire                        connect_ctl;
            wire                        driver_ctrl;
            wire                        strips_ctrl;
assign  scan_id_ctl     =  (decode_task==  5)&&decode_ctrl&&(decode_type==1);
assign  pattern_ctl     =  (decode_task==  7)&&decode_ctrl;
assign  bright_ctrl[0]  =  (decode_task== 11)&&decode_ctrl;
assign  bright_ctrl[1]  =  (decode_task== 31)&&decode_ctrl;
assign  gamma_setup     =  (decode_task== 58)&&decode_ctrl;
assign  correct_ctl     =  (decode_task== 45)&&decode_ctrl;
assign  connect_ctl     =  (decode_task== 55)&&decode_ctrl;
assign  driver_ctrl     =  (decode_task== 29)&&decode_ctrl;

assign  strips_ctrl     =  (decode_task==104)&&decode_ctrl;


//Length    network_mux[6]  bright_link
always@(posedge refer_clock)identifiers         <=  refer_ready?(scan_id_ctl    ?   decode_data[0]:identifiers):0;
always@(posedge refer_clock)pattern_rst         <=(!refer_ready||pattern_ctl);//?0:((network_cmd== 7)&&network_set&&refer_ready);
always@(posedge refer_clock)pattern_mod         <=  refer_ready?(pattern_ctl    ?   decode_data[0]:pattern_mod):(pattern_def>>0);//pattern_def
always@(posedge refer_clock)pattern_sel         <=  refer_ready?(pattern_ctl    ?   decode_data[1]:pattern_sel):(pattern_def>>8);//pattern_def
always@(posedge refer_clock)bright_data[ 7: 0]  <=  refer_ready?(bright_ctrl[1] ?   decode_data[0]:bright_data[ 7: 0])  :val_r_reset;//&&network_gap&&(!network_err);
always@(posedge refer_clock)bright_data[15: 8]  <=  refer_ready?(bright_ctrl[1] ?   decode_data[1]:bright_data[15: 8])  :val_g_reset;//&&network_gap&&(!network_err);
always@(posedge refer_clock)bright_data[23:16]  <=  refer_ready?(bright_ctrl[1] ?   decode_data[2]:bright_data[23:16])  :val_b_reset;//&&network_gap&&(!network_err);

always@(posedge refer_clock)bright_lv10         <=  bright_link[1]  ?  (bright_ctrl[0]  ?   decode_data[0]:bright_lv10) :
                                                    bright_link[0]  ?   val_a_reset:8'h00;//8'h10;


            reg [                  7: 0]buffer_lv10;
always@(posedge refer_clock)buffer_lv10         <=  bright_lv10;//

always@(posedge refer_clock)reflash_ctl         <= (buffer_lv10!=bright_lv10);



always@(posedge refer_clock)ram2rom_ctl         <=  refer_ready&&connect_ctl;
always@(posedge refer_clock)ram2rom_sel         <=  refer_ready?(connect_ctl    ?   decode_data[0]:ram2rom_sel):0;//8'hff;
always@(posedge refer_clock)gamma_index         <=  refer_ready?(gamma_setup    ?   decode_data[0]:gamma_index):gamma_reset;
always@(posedge refer_clock)correct_ena         <=  refer_ready?(correct_ctl    ?  (decode_data[0][0]):correct_ena):0;

//~limit 75%
always@(posedge refer_clock)driver_gain[ 7: 0]  <=  refer_ready?(driver_ctrl    ?   decode_data[0]:driver_gain[ 7: 0]):dac_r_reset;//&&network_gap&&(!network_err);
always@(posedge refer_clock)driver_gain[15: 8]  <=  refer_ready?(driver_ctrl    ?   decode_data[1]:driver_gain[15: 8]):dac_g_reset;//&&network_gap&&(!network_err);
always@(posedge refer_clock)driver_gain[23:16]  <=  refer_ready?(driver_ctrl    ?   decode_data[2]:driver_gain[23:16]):dac_b_reset;//&&network_gap&&(!network_err);

always@(posedge refer_clock)driver_gain[31:24]  <=  refer_ready?(driver_ctrl    ?   decode_data[3]:driver_gain[31:24]):dac_r_reset;//&&network_gap&&(!network_err);
always@(posedge refer_clock)driver_gain[39:32]  <=  refer_ready?(driver_ctrl    ?   decode_data[4]:driver_gain[39:32]):dac_g_reset;//&&network_gap&&(!network_err);
always@(posedge refer_clock)driver_gain[47:40]  <=  refer_ready?(driver_ctrl    ?   decode_data[5]:driver_gain[47:40]):dac_b_reset;//&&network_gap&&(!network_err);


//~strip uart port
always@(posedge refer_clock)comm_enable         <=  refer_ready?(strips_ctrl    ?   decode_data[0]:comm_enable):0;//
always@(posedge refer_clock)comm_select         <=  refer_ready?(strips_ctrl    ?   decode_data[1]:comm_select):0;//


always@(posedge refer_clock)pixel_close         <=  refer_ready?(correct_ctl    ?  (decode_data[0][6]):pixel_close):0;
always@(posedge refer_clock)white_close         <=  refer_ready?(correct_ctl    ?  (decode_data[0][7]):white_close):0;

endmodule