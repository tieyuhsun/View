module SPI_LPC #
(
/*
protocol
                byte[0]         byte[1]         byte[2]         byte[3]         byte[4]         byte[5]
    0x08/0x09   type_manage     group id        command         addr            addr++          
    0x07/0x06   type_memory     row[15: 8]      col[15: 8]      row[ 7: 0]      col[ 7: 0]      xyz         col++
    0x05/0x04   type_linear     panel.row       panel.col       row[ 7: 0]      col[ 7: 0]      xyz         xyz++
    0x03/0x02   type_module     command         addr            addr++
*/
/*

    STM:18Mbps

    23A1024/23LC1024
        READ    0000 0011 0x03 Read data from memory array beginning at selected address
        WRITE   0000 0010 0x02 Write data to memory array beginning at selected address
*/
    parameter   type_manage         =   7'h04,  //0x07/0x06
    parameter   type_memory         =   7'h03,  //0x07/0x06
//
    parameter   type_linear         =   7'h02,  //0x05/0x04
        //  byte[1]: panel[row]      
        //  byte[2]: panel[col]      
        //  byte[3]: pixel[row] pixel[1D]
        //  byte[4]: pixel[col] pixel[1D]
        //  byte[5]: coefficient

        //           0=Rx[15: 8]    1=Rx[ 7: 0]     2=Ry[15: 8]     3=Ry[ 7: 0]     4=Rz[15: 8]     5=Rz[ 7: 0]
        //           6=Gx[15: 8]    7=Gx[ 7: 0]     8=Gy[15: 8]     9=Gy[ 7: 0]    10=Gz[15: 8]    11=Gz[ 7: 0]
        //          12=Bx[15: 8]   13=Bx[ 7: 0]    14=By[15: 8]    15=By[ 7: 0]    16=Bz[15: 8]    17=Bz[ 7: 0]     check_sum[?]
    parameter   type_module         =   7'h01,  //0x03/0x02
        //  byte[1]: command      
        //  byte[2]: command.address

    parameter   address_bit         =   8,
//
    parameter   logic_close         =   1,//def ssb=0,load.mdo
    parameter   ext_spi_net         =   4,//  ((~SPI_SEL_PAD) & spi_rom_net)
    parameter   select_pins         =   3

)
(

    output  reg [                 1:  0]coeffis_det,//
    output  reg                         coeffis_set,//cpu.w
    output  reg                         coeffis_get,//cpu.r
    output  wire                        coeffis_stb,
    output  reg [                15:  0]coeffis_row,//
    output  reg [                15:  0]coeffis_col,//
    output  reg [                 7:  0]coeffis_xyz,//
    output  reg [                 7:  0]coeffis_bit,//b[6],g[5],r[4],gray[3:0]
/**/
    output  reg [                 7:  0]manager_grp,//  group id
    output  reg [                 7:  0]manager_cmd,//  byte[1] command
    output  reg [                 7:  0]manager_adr,//  byte[2] offset
    output  wire[                 7:  0]manager_bit,
    output  wire                        manager_set,
    output  wire                        manager_get,
    output  wire                        manager_stb,
//random
    output  wire                        random_work,//  byte[0] 0x03/0x02
    output  wire[                 7:  0]random_task,//  byte[1] command
    output  wire[                 7:  0]random_seat,//  byte[2] offset
    output  wire[                 7:  0]random_byte,
    output  wire                        random_ctrl,


//
    input       [                 7:  0]SPI_LPC_MDI,  
//
    input                               SPI_SEL_PAD,
    input                               SPI_SCK_PAD,
    input                               SPI_MDO_PAD,
    output  wire                        SPI_SDO_PAD,
  //output  reg                         SPI_SDO_PAD,
/**/
    input                               refer_clock
);


            reg [                  7: 0]sck_pos_buf;
            reg [      address_bit+3: 0]sck_neg_cnt;//   (0..7)@neg
always@(posedge SPI_SCK_PAD)sck_pos_buf <= {sck_pos_buf,SPI_MDO_PAD};//@pos
always@(negedge SPI_SCK_PAD or posedge SPI_SEL_PAD)
if( SPI_SEL_PAD)
    sck_neg_cnt <=  0;
else
    sck_neg_cnt <=  sck_neg_cnt+1;
//
            wire[                  2: 0]sck_neg_inv;//   (7..0)@neg
assign  sck_neg_inv = (~sck_neg_cnt[2:0]);
assign  SPI_SDO_PAD =  (SPI_SEL_PAD==logic_close)?1'bz:SPI_LPC_MDI[sck_neg_inv];//
/*
            reg [                  2: 0]spi_neg_cnt;//   (7..0)@neg
always@(posedge refer_clock)spi_neg_cnt <=  sck_neg_inv;//
*/
            wire[                  7: 0]spi_neg_mux;//1<<(7..0)@neg
assign  spi_neg_mux =  (1<<sck_neg_inv);//

/*
            reg                         spi_sck_bit;
always@(posedge refer_clock)spi_sck_bit <=  SPI_SCK_PAD;
*/

            reg [                  2: 0]filter_last;//filter_last   detect_last
            reg [                  2: 0]filter_frst;
            reg [                  2: 0]filter_stop;
            reg                         detect_last;//filter_miso   detect_miso
            reg                         detect_frst;
            reg                         detect_stop;//detect_stop
always@(posedge refer_clock)filter_last <= {filter_last,(spi_neg_mux[0])};//    [0]/([7]->[0])
always@(posedge refer_clock)filter_frst <= {filter_frst,(spi_neg_mux[7])};//    [7]/([7]->[0])
always@(posedge refer_clock)filter_stop <= {filter_stop,(SPI_SEL_PAD==logic_close)};
always@(posedge refer_clock)detect_last <=  detect_last?(|filter_last):(&filter_last);
always@(posedge refer_clock)detect_frst <=  detect_frst?(|filter_frst):(&filter_frst);
always@(posedge refer_clock)detect_stop <=  detect_stop?(|filter_stop):(&filter_stop);
/*
neg                 0       1       2       3       4       5       6       7       0|8             1       2       3
neg.inv             7       6       5       4       3       2       1       0       7               6       5       4
            ____________----____----____----____----____----____----____----____----____________----____----____----____----

byte_stable(fast)   [      ]
byte_encase(last)                                                           [      ]
byte_strobe                                                                        |


*/
            reg                         byte_enable;
            reg                         byte_resync;
            reg [      address_bit+0: 0]byte_counts;//
            reg [                  7: 0]byte_buffer;
            reg                         byte_stable;
            reg                         byte_encase;
            reg                         byte_strobe;
always@(posedge refer_clock)byte_enable <=(!detect_stop);
always@(posedge refer_clock)byte_resync <=(!byte_enable)&&(!detect_stop);//
always@(posedge refer_clock)byte_buffer <=  sck_pos_buf;//detect_last?sck_pos_buf:byte_buffer;
always@(posedge refer_clock)byte_stable <=  detect_last;
always@(posedge refer_clock)byte_encase <=  detect_frst;//
always@(posedge refer_clock)byte_strobe <=  detect_last&&(filter_last==0);//cpu.w
always@(posedge refer_clock)byte_counts <= (detect_last||byte_stable||(|filter_last))?byte_counts:(sck_neg_cnt[address_bit+3: 3]);


            reg [                  7: 0]header_flag;
            reg                         header_work;
            reg [                  7: 0]header_byte[7:0];
always@(posedge refer_clock)header_flag <=  byte_strobe?{header_flag,1'b0}:(header_flag|byte_resync);//):(detect_stop?0:1);
always@(posedge refer_clock)header_work <= (byte_strobe&&header_flag[7])?0:(header_work|byte_resync);
always@(posedge refer_clock)header_byte[byte_counts[2:0]]   <= (byte_strobe&&header_work)?byte_buffer:header_byte[byte_counts[2:0]];


    
/*
                byte[0]         byte[1]         byte[2]         byte[3]         byte[4]         byte[5]
    0x08/0x09   type_manage     group id        command         adr             dat,adr++
    0x07/0x06   type_memory     row[15: 8]      col[15: 8]      row[ 7: 0]      col[ 7: 0]      xyz         dat,col++
    0x05/0x04   type_linear     panel.row       panel.col       row[ 7: 0]      col[ 7: 0]      xyz         dat,xyz++
    0x03/0x02   type_module     command         adr             dat,adr++
*/
            reg                         manager_ena;
assign  manager_bit =   byte_buffer;//
assign  manager_stb =   byte_strobe;//
assign  manager_set =  (byte_enable&&(!header_byte[0][0])&&(manager_ena)&&byte_stable);//
assign  manager_get =  (byte_enable&&( header_byte[0][0])&&(manager_ena)&&byte_encase);//
always@(posedge refer_clock)
    if( byte_strobe)
        if( header_flag[3]&&(header_byte[0][7:1]==type_manage))
        begin
            manager_ena <=  1;
            manager_grp <=  header_byte[1];
            manager_cmd <=  header_byte[2];
            manager_adr <=  byte_buffer;
        end
        else
        if( header_flag[2]&&(header_byte[0][7:1]==type_module))
        begin
            manager_ena <=  1;
            manager_grp <=  35;
            manager_cmd <=  header_byte[1];
            manager_adr <=  byte_buffer;
        end
        else
        begin
           {manager_ena,manager_adr} <= {manager_ena,manager_adr}+manager_ena;
            manager_grp <=  manager_grp;
            manager_cmd <=  manager_cmd;//
        end
    else
        begin
            manager_ena <=  manager_ena&&byte_enable;//(header_byte[0][7:1]==type_manage)&&byte_enable;
            manager_grp <= (manager_ena&&byte_enable)?manager_grp:253;
            manager_cmd <=  manager_cmd;//
            manager_adr <=  manager_adr;
        end


/*

*/
            reg                         module_work;//  byte[0] 0x03/0x02
            wire[                 7:  0]module_task;//  byte[1] command
            reg [                 7:  0]module_seat;//  byte[2] offset
            reg [                 7:  0]module_byte;
            reg                         module_ctrl;
assign  module_task =   header_byte[1];
always@(posedge refer_clock)module_byte <= (byte_strobe&&module_work&&(!header_byte[0][0]))?byte_buffer:byte_counts;//
always@(posedge refer_clock)module_ctrl <= (byte_strobe&&module_work&&(!header_byte[0][0]));//
always@(posedge refer_clock)
    if( byte_strobe)
        if( header_flag[2])
        begin
            module_work <=  module_work;
            module_seat <=  byte_buffer;
        end
        else
           {module_work,module_seat} <= {module_work,module_seat}+module_work;
    else
        begin
            module_work <= (header_byte[0][7:1]==type_module)&&byte_enable;
            module_seat <=  module_seat;
        end

assign  random_work =   module_work;
assign  random_task =   module_task;
assign  random_seat =   module_seat;
assign  random_byte =   module_byte;
assign  random_ctrl =   module_ctrl;

        
//always@(posedge refer_clock)random_work <=  byte_enable&&(header_byte[0][7:1]==type_module);
//always@(posedge refer_clock)random_seat <= (header_flag[2]&&byte_strobe)?byte_buffer:(random_seat+byte_strobe);



//assign  random_byte =   byte_strobe?byte_buffer:byte_counts;//
//assign  random_ctrl =   byte_strobe;//
//

/*
                byte[0]         byte[1]         byte[2]         byte[3]         byte[4]         byte[5]
    0x08/0x09   type_manage     group id        command         addr            addr++
    0x07/0x06   type_memory     row[15: 8]      col[15: 8]      row[ 7: 0]      col[ 7: 0]      xyz         col++
    0x05/0x04   type_linear     panel.row       panel.col       row[ 7: 0]      col[ 7: 0]      xyz         xyz++
    0x03/0x02   type_module     command         addr            addr++
*/

            reg                         coeffis_cmd;

always@(posedge refer_clock)coeffis_det <=  byte_enable?{(header_byte[0][7:1]==type_memory),(header_byte[0][7:1]==type_linear)}:0;

always@(posedge refer_clock)coeffis_cmd <=  byte_enable&&(|header_flag[5:0]);

//byte_strobe?  (((coeffis_det[1]&&header_flag[4])||(coeffis_det[0]&&header_flag[5]))?0:coeffis_cmd):(header_flag[0]||coeffis_cmd);
//always@(posedge refer_clock)coeffis_get <=  byte_strobe?   (coeffis_set||((coeffis_det[1]&&header_flag[4])||(coeffis_det[0]&&header_flag[5]))):((!header_flag[0])&&coeffis_set);

always@(posedge refer_clock)coeffis_row <=
                                           (header_flag[1]&&byte_strobe)?{byte_buffer       ,8'h00      }:
                                           (header_flag[3]&&byte_strobe)?{coeffis_row[15: 8],byte_buffer}:coeffis_row;

always@(posedge refer_clock)coeffis_col <= 
                                           (header_flag[2]&&byte_strobe)?{byte_buffer       ,8'h00      }:
                                           (header_flag[4]&&byte_strobe)?{coeffis_col[15: 8],byte_buffer}:
                                           (coeffis_col+(coeffis_det[1]&&(!coeffis_cmd)&&byte_strobe));

always@(posedge refer_clock)coeffis_xyz <=
                                           (header_flag[5]&&byte_strobe)?byte_buffer:
                                           (coeffis_xyz+(coeffis_det[0]&&(!coeffis_cmd)&&byte_strobe));

always@(posedge refer_clock)coeffis_set <= (byte_enable&&(!header_byte[0][0])&&(|coeffis_det)&&byte_stable);//detect_last
always@(posedge refer_clock)coeffis_get <= (byte_enable&&( header_byte[0][0])&&(|coeffis_det)&&byte_encase);//detect_frst
//always@(posedge refer_clock)coeffis_stb <=  byte_strobe;//
always@(posedge refer_clock)coeffis_bit <=  byte_buffer;//
assign  coeffis_stb =   byte_strobe;
//assign  coeffis_bit =   byte_buffer;
//
endmodule