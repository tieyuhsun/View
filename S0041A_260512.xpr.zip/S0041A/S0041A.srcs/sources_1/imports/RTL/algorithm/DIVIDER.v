/*
    16bit   fix dividend___ {16{1'b1}}
        baest = 0
            Lut     Dff
        0:  56      49
        1:  312     n/a
        2:  503     n/a

    8bit    fix dividend___ {8{1'b1}}
        baest = 0
            Lut     Dff
        0:  38      25
        1:  110     n/a
        2:  120     n/a


    16bit
        baest = 0
            Lut     Dff
        0:  51      49
        1:  342     n/a
        2:  530     n/a
*/
module  DIVIDER
#(

/*
Combinational Logic
Sequential Logic
Combination
Sequentials
*/

    parameter   Combination     =   2,
    parameter       exp_divider =   16
)(
    input       [   exp_divider-1   : 0]dividend___,
    input       [   exp_divider-1   : 0]divisor____,
    output  wire[   exp_divider-1   : 0]quotient___,
    output  wire[   exp_divider-1   : 0]remainder__,
    output  wire                        quotient_ok,
    input                               refer_clock
);

            wire[   exp_divider-1   : 0]quotient__d[2:0];
            wire[   exp_divider-1   : 0]remainder_d[2:0];
            reg [  (exp_divider<<1)-1:0]divider_run[2:0][3:0];

assign  quotient___ =   quotient__d[Combination];//
assign  remainder__ =   remainder_d[Combination];//

assign  quotient_ok =   divider_run[0][0][(exp_divider)];//only Sequential
/*

    0   Sequential Logic

*/
initial divider_run[0][0]   =   0;//
initial divider_run[0][1]   =   0;//
initial divider_run[0][2]   =   0;//
initial divider_run[0][3]   =   0;//
always@(posedge refer_clock)
    if( divider_run[0][0][(exp_divider)])
    begin
        divider_run[0][0]   <=  dividend___|0;
        divider_run[0][1]   <=  0;
        divider_run[0][2]   <= (divider_run[0][1]-1);
        divider_run[0][3]   <=  divider_run[0][0];//
    end
    else
    begin
        divider_run[0][0]   <=  divider_run[0][0]   -divisor____;//
        divider_run[0][1]   <=  divider_run[0][1]   +1;
        divider_run[0][2]   <=  divider_run[0][2];//
        divider_run[0][3]   <=  divider_run[0][3];//
    end

assign  quotient__d[0]  = (|divisor____)?divider_run[0][2]:0;
assign  remainder_d[0]  = (|divisor____)?divider_run[0][3]:0;

/*

    1   Combinational Logic

*/

assign  quotient__d[1]  =   dividend___/divisor____;
assign  remainder_d[1]  =   dividend___%divisor____;
/*

    2   Combinational Logic

*/
integer i;  
always @(*)  
    begin
        divider_run[2][0] = {{exp_divider{1'b0}},dividend___};  
        divider_run[2][1] = {divisor____,{exp_divider{1'b0}}};  
    for(i = 0;i < exp_divider;i = i + 1)  
        begin  
            divider_run[2][0] = divider_run[2][0]<<1;
            if(divider_run[2][0]>= divider_run[2][1])  
                divider_run[2][0] = divider_run[2][0] - divider_run[2][1] + 1'b1;  
            else  
                divider_run[2][0] = divider_run[2][0];  
        end  
  end
  
assign {quotient__d[2],remainder_d[2]}  =   divider_run[2][0];//

endmodule