/*

    baest = 3   
    
        but i don't how

*/
module  HEX2BCD
#(

/*
Combinational Logic
Sequential Logic
Combination
Sequentials
*/
    parameter   Combination     =   3
)(
                         
    input       [                  7: 0]HEX_SET_DAT,
    output  wire[                  3: 0]BCD_GET_DAT[2:0],//gamma 2.0
          
    input                               refer_clock
);

            wire[                  3: 0]BCD_RUN_DAT[7:0][2:0];//
assign  BCD_GET_DAT[0]  =   BCD_RUN_DAT[Combination][0];//
assign  BCD_GET_DAT[1]  =   BCD_RUN_DAT[Combination][1];//
assign  BCD_GET_DAT[2]  =   BCD_RUN_DAT[Combination][2];//

/*

    0   Sequential Logic

*/

            reg [                   7:0]hex_d10_buf;
            wire[                   8:0]hex_d10_run =(hex_d10_buf-10);//8bit --> 

            reg [                   4:0]dec_d10_cnt;
            reg [                   3:0]dec_one_dat;
            reg [                   4:0]hex_ten_dat;
          //reg [                   3:0]dec_hun_dat;

always@(posedge refer_clock)
    if( hex_d10_run[8])
    begin
        hex_d10_buf <=  HEX_SET_DAT;
        dec_one_dat <=  hex_d10_buf;//

        dec_d10_cnt <=  0;
        hex_ten_dat <=  dec_d10_cnt;
    end
    else
    begin
        hex_d10_buf <=  hex_d10_run;
        dec_one_dat <=  dec_one_dat;

        dec_d10_cnt <=  dec_d10_cnt+1;
        hex_ten_dat <=  hex_ten_dat;
    end
assign  BCD_RUN_DAT[0][0]   =   dec_one_dat;
assign  BCD_RUN_DAT[0][1]   =   hex_ten_dat;
assign  BCD_RUN_DAT[0][2]   =   0;
/*

    1   Combinational Logic

*/


assign  BCD_RUN_DAT[1][0]   =   HEX_SET_DAT%10;
assign  BCD_RUN_DAT[1][1]   =  (HEX_SET_DAT%100)/10;
assign  BCD_RUN_DAT[1][2]   =   HEX_SET_DAT/100;


/*

    2   Combinational Logic
    
    //https://blog.csdn.net/wuzhikaidetb/article/details/136039824


    step0 [0][0][0]   << FF
    step1 [0][0][1]   << FE
    step2 [0][0][3]   << FC
    step3 [0][0][7]   << F8     [0][0][A]   = ([0][0][7]+12'h003)
    step4 [0][1][5]   << F0     [0][1][8]   = ([0][1][5]+12'h003)
    step5 [0][3][1]   << E0
    step6 [0][6][3]   << C0     [0][9][3]   = ([0][6][3]+12'h030)
    step7 [1][2][7]   << 80     [1][2][A]   = ([1][2][7]+12'h003)
    step8 [2][5][5]   << 00
    
*/
    function [3:0] HEX_5_9_AD3;
    input       [ 3: 0] HEX_SET_BIT;
          //wire[ 3: 0] HEX_RUN_AD3;
    begin
        HEX_5_9_AD3 =  
                       (HEX_SET_BIT<10)?0:
                       (HEX_SET_BIT> 4)?(HEX_SET_BIT+3):HEX_SET_BIT;//
    end
    endfunction

            wire[ 3: 0] HEX_RUN_AD3[7:0];
assign  HEX_RUN_AD3[0]  =   0;
assign  HEX_RUN_AD3[1]  =   HEX_5_9_AD3( HEX_SET_DAT[7:5]);
assign  HEX_RUN_AD3[2]  =   HEX_5_9_AD3({HEX_RUN_AD3[1][2:0],HEX_SET_DAT[4]});
assign  HEX_RUN_AD3[3]  =   HEX_5_9_AD3({HEX_RUN_AD3[2][2:0],HEX_SET_DAT[3]});
assign  HEX_RUN_AD3[4]  =   HEX_5_9_AD3({HEX_RUN_AD3[1][3],HEX_RUN_AD3[2][3],HEX_RUN_AD3[3][3]});
assign  HEX_RUN_AD3[5]  =   HEX_5_9_AD3({HEX_RUN_AD3[3][2:0],HEX_SET_DAT[2]});
assign  HEX_RUN_AD3[6]  =   HEX_5_9_AD3({HEX_RUN_AD3[4][2:0],HEX_RUN_AD3[5][3]});
assign  HEX_RUN_AD3[7]  =   HEX_5_9_AD3({HEX_RUN_AD3[5][2:0],HEX_SET_DAT[1]});


assign {BCD_RUN_DAT[2][2],
        BCD_RUN_DAT[2][1],
        BCD_RUN_DAT[2][0]}  =   {HEX_RUN_AD3[4][3],HEX_RUN_AD3[6],HEX_RUN_AD3[7],HEX_SET_DAT[0]};


/*

    3   Combinational Logic
    
    //https://blog.csdn.net/wuzhikaidetb/article/details/136039824

    step0 [0][0][0]   << FF
    step1 [0][0][1]   << FE
    step2 [0][0][3]   << FC
    step3 [0][0][7]   << F8     [0][0][A]   = ([0][0][7]+12'h003)
    step4 [0][1][5]   << F0     [0][1][8]   = ([0][1][5]+12'h003)
    step5 [0][3][1]   << E0
    step6 [0][6][3]   << C0     [0][9][3]   = ([0][6][3]+12'h030)
    step7 [1][2][7]   << 80     [1][2][A]   = ([1][2][7]+12'h003)
    step8 [2][5][5]   << 00

*/
    parameter   HEX_RUN_BIT =   8;//
            wire[   HEX_RUN_BIT-1   : 0]HEX_RUN_SET;
            reg [   HEX_RUN_BIT+
                  ((HEX_RUN_BIT-4)/3):0]BCD_RUN_GET;            
 
    integer i,j;
always@(*)
    begin
      //for(i = 0,i <= ((HEX_RUN_BIT-4)/3)  :  i=i+1)BCD_RUN_GET[i] = 0;
        BCD_RUN_GET = HEX_SET_DAT|0;//
           
        for(i = 0;  i  <=  (HEX_RUN_BIT-4)  ;  i=i+1)//0..3
            for(j = 0;  j  <=  (i/3)            ;  j=j+1)//0
                if(BCD_RUN_GET[(HEX_RUN_BIT-i)+(4*j)-:4]>4)
                    BCD_RUN_GET[(HEX_RUN_BIT-i)+(4*j)-:4] = BCD_RUN_GET[(HEX_RUN_BIT-i)+(4*j)-:4] +3;//
                else;//

    end
assign {BCD_RUN_DAT[3][2],
        BCD_RUN_DAT[3][1],
        BCD_RUN_DAT[3][0]}  =   BCD_RUN_GET;
/*
    0:8-0+0
    1:8-1+0
    2:8-2+0
    3:8-3+0 ,3:8-3+4

*/
/*
    X = 32'h76543210
    
    Y = X[11-:4] = X[11: 8]
    
    Y = X[12+:4] = X[15:12]
    


*/

            reg [  (HEX_RUN_BIT*2)+3: 0]HEX_BCD_RUN;
    integer k;
always@(*)
    begin
        HEX_BCD_RUN =   HEX_SET_DAT|0;//
        for(k = 0;  k  <=  8  ;  k=k+1)//0..3
            if(HEX_BCD_RUN[11: 8]>4)
                HEX_BCD_RUN = ((HEX_BCD_RUN+12'h300)<<1);//
            else
                HEX_BCD_RUN =  (HEX_BCD_RUN<<1);//
                
    end
assign {BCD_RUN_DAT[4][2],
        BCD_RUN_DAT[4][1],
        BCD_RUN_DAT[4][0]}  =  (HEX_BCD_RUN>>8);
/*

    4   Combinational Logic
    
    step0 [0][0][0]   << FF
    step1 [0][0][1]   << FE
    step2 [0][0][3]   << FC
    step3 [0][0][7]   << F8     [0][0][A]   = ([0][0][7]+12'h003)
    step4 [0][1][5]   << F0     [0][1][8]   = ([0][1][5]+12'h003)
    step5 [0][3][1]   << E0
    step6 [0][6][3]   << C0     [0][9][3]   = ([0][6][3]+12'h030)
    step7 [1][2][7]   << 80     [1][2][A]   = ([1][2][7]+12'h003)
    step8 [2][5][5]   << 00
    
    step0 [ ][ ][ ]FF
    step1 [ ][ ][F]F0  ,   [ ][F]+3 = [1][]

*/


endmodule
//
///*
//BCD2hex
//0010 0100 0011  ->  00000000 ��l��
//0001 0010 0001  ->  10000000 �V�k����
//0000 1001 0000  ->  11000000 �V�k����
//0000 0110 0000  ->  11000000 ��?4���?9�A�ҥH�n-3
//0000 0011 0000  ->  01100000 �V�k����
//0000 0001 1000  ->  00110000 �V�k����
//0000 0001 0101  ->  00110000 �̥k4���?8�A�ҥH�n-3
//0000 0000 1010  ->  10011000 �V�k����
//0000 0000 0111  ->  10011000 �̥k4���?10�A�ҥH�n-3
//0000 0000 0011  ->  11001100 �V�k����
//0000 0000 0001  ->  11100110 �V�k����
//0000 0000 0000  ->  11110011 �V�k����
///*