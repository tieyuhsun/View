module VIDEO_TTL#
(
    parameter   pixel_edges =   {24{1'b0}},
    parameter   vsync_edges =   0,
    parameter   hsync_edges =   0,
    parameter   esync_edges =   0

  //parameter   [27:0]clock_phase = {28{1'b1}}
)
(
    input                           video_ready,//SCDT
//
    input                           video_vsync,
    input                           video_hsync,
    input                           video_esync,
    input       [           23  : 0]video_pixel,
    input                           video_clock,
//
    output  reg                     image_vsync,
    output  reg                     image_hsync,
    output  reg                     image_esync,
    output  reg [           23  : 0]image_pixel,
    output  reg [           15  : 0]image_width,
    output  reg [           15  : 0]image_hight,
    output  reg [           15  : 0]image_frame,

    output  reg                     image_ready
);


/*
    dual_domain_memory#(
        .   chars_width     (   31),
        .   address_bit     (   7))
    domain_buffer (
        .   write_local     (   queued_addr[i]), 
        .   write_syncs     (   queued_sync[i][0]), 
        .   write_chars     (   queued_data[i]), 
        .   write_clock     (   RXCK_BUF[i]),

        .   catch_local     (   domain_addr[i]),//pixle_value[latch_ports][latch_sides]), 
        .   catch_chars     (   domain_sram[i]), 
        .   catch_clock     (   refer_clock));
*/

            wire[             26: 0]image_iobuf[3:0];
            wire[             26: 0]iobuf_edges;
assign  iobuf_edges =   pixel_edges|(esync_edges<<24)|(hsync_edges<<25)|(vsync_edges<<26);



genvar i;
    generate
        for (i=0; i<27; i=i+1)
        begin: rx
    IDDR#(
        .   DDR_CLK_EDGE    (   "SAME_EDGE_PIPELINED"), //"OPPOSITE_EDGE",  "SAME_EDGE, "SAME_EDGE_PIPELINED"
        .   INIT_Q1         (   1'b0),
        .   INIT_Q2         (   1'b0),
        .   SRTYPE          (   "ASYNC"))
    iddr_video(
        .   Q1              (   image_iobuf[0][i]),
        .   Q2              (   image_iobuf[1][i]),
        .   C               (   video_clock),
        .   CE              (   1'b1),
        .   D               (   image_iobuf[2][i]),
        .   R               (   1'b0),
        .   S               (   1'b0));
assign  image_iobuf[3][i]   =   image_iobuf[iobuf_edges[i]][i];
       end // block: u
    endgenerate
assign  image_iobuf[2]      =  {video_vsync,video_hsync,video_esync,video_pixel};
            wire                    iobuf_vsync;
            wire                    iobuf_hsync;
            wire                    iobuf_esync;
            wire[             23: 0]iobuf_pixel;
assign {iobuf_vsync,
        iobuf_hsync,
        iobuf_esync,
        iobuf_pixel}        =   image_iobuf[3];
//
//            reg                     iobuf_esync;
//always@(posedge video_clock)iobuf_esync     <=  iobuf_esync;
always@(posedge video_clock)image_vsync     <=  iobuf_vsync;
always@(posedge video_clock)image_hsync     <=  iobuf_hsync;
always@(posedge video_clock)image_esync     <=  iobuf_esync;
always@(posedge video_clock)image_pixel     <=  iobuf_pixel;

//
            reg                     latch_vsync;//
            reg                     latch_hsync;//
            reg[               3: 0]phase_hsync;
            reg                     carry_hsync;
            reg[               3: 0]phase_vsync;
            reg                     carry_vsync;
            reg[               3: 0]phase_break;
            reg                     carry_break;
//
always@(posedge video_clock)latch_vsync <=  iobuf_esync?iobuf_vsync:latch_vsync;
always@(posedge video_clock)latch_hsync <=  iobuf_esync?iobuf_hsync:latch_hsync;
//
always@(posedge video_clock)phase_vsync <= (latch_vsync==image_vsync)   ?0:{phase_vsync,1'b1};
always@(posedge video_clock)carry_vsync <= (phase_vsync==3);//
//
always@(posedge video_clock)phase_hsync <= (latch_hsync==image_hsync)   ?0:{phase_hsync,1'b1};
always@(posedge video_clock)carry_hsync <= (phase_hsync==3);//
//
always@(posedge video_clock)phase_break <=  carry_hsync?0:{phase_break,image_esync};
always@(posedge video_clock)carry_break <= (phase_break==4'b1100)?1:(carry_hsync?0:carry_break);//
//
always@(posedge video_clock)image_width <=  carry_hsync?0:(image_width+(image_esync&&(!image_width[15])));//
//
always@(posedge video_clock)image_hight <=  carry_vsync?0:(image_hight+(carry_hsync&&(!image_hight[15]&&carry_break)));
//
always@(posedge video_clock)image_frame <=  image_ready?(image_frame+carry_vsync):0;

always@(posedge video_clock or negedge video_ready)
if(!video_ready)
    image_ready <=  0;
else
    image_ready <= (latch_vsync==image_vsync)?image_ready:1;//

endmodule
