module DSP#
(

    parameter       multi_expon = 16//,   //18
  //parameter       addition_dw = 32    //48
)
(

    input       [((multi_expon<<0)-0):0]multipliers,
    input       [((multi_expon<<0)-0):0]multip_data,
    input       [((multi_expon<<1)-1):0]increasedes,
    output  reg [((multi_expon<<1)-1):0]convolution,/* synthesis syn_multstyle = "dsp" */

    input                               refer_clock
);


          //reg [   addition_dw-1:0]refer_codec;
always@(posedge refer_clock)convolution <= (multipliers * multip_data)+increasedes;
//always@(posedge REFER_CLOCK)        convolution <=  refer_codec + additionald;

/*
    0x1234  *   0x4567  =   4EF 56EC
    
       234  *   0x4567  =    98 E6EC
      1000  *   0x4567  =   456 7000

        34  *   0x4567  =    E18EC
        12  *   0x4567  =  4E13E

        34  *   0x45  =    E04        
        34  *   0x67  =     14EC


*/
endmodule

