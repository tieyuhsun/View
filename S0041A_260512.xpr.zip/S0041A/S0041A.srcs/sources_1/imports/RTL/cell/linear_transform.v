module  linear_transform#(
    parameter       range = 4
)( 
/*
    evenly   =   2 *{linear domain}
*/
    input       [(  range)-1:0] linear_code,    
    output  reg [(  range)-1:0] evenly_code
    );
/*

range = 4
    1   =   1/16
    2   =   2/16
    ...
    8   =   8/16
    


*/
            reg  [range-0:0]   linear_calc;    initial linear_calc = 0 ;
            wire [range-1:0]   linear_mask = linear_calc[range-1:0]^linear_calc[range-0:1];
            reg  [range-1:0]   linear_turn;    initial linear_turn = 0 ;
integer i;
always@(linear_code or linear_mask or linear_calc)
begin
    for (i=0;i<range;i=i+1)
    begin
        linear_calc[  0]    =   0;
        linear_calc[i+1]    =  (linear_calc[i]|linear_code[i]);
        linear_turn[i]      =   linear_mask[(range-1)-i];
        evenly_code[i]      =   linear_mask[(range-1)-i];
      //CYC_DDA[range-1-m ]=(linear_mask[m]&DAT_I[range-1-m]) && ENA_I;
    end
end



endmodule
