module  PAD_LATCH
 #
(
//.DDR_CLK_EDGE   ("SAME_EDGE_PIPELINED"), //"OPPOSITE_EDGE", "SAME_EDGE, "SAME_EDGE_PIPELINED

     parameter  latch_phase = "SAME_EDGE_PIPELINED",   //C0 = refer_clock
     parameter  iopad_width = 4

)
(
    input                           refer_clock,
//
    output  wire[   iopad_width-1:0]do_positive,
    output  wire[   iopad_width-1:0]do_negative,
//
    input       [   iopad_width-1:0]DDR_BUS_MDI

);


genvar i;
    generate
    for (i=0; i<iopad_width; i=i+1)
        begin: U


    IDDR #(
       .    DDR_CLK_EDGE    (   latch_phase), // Sets output alignment to "NONE", "C0" or "C1"
       .    INIT_Q1         (   1'b0), // Sets initial state of the Q0 output to 1U+00A1U+00A6b0 or 1U+00A1U+00A6b1
       .    INIT_Q2         (   1'b0), // Sets initial state of the Q1 output to 1U+00A1U+00A6b0 or 1U+00A1U+00A6b1
       .    SRTYPE          (   "ASYNC"))// Specifies "SYNC" or "ASYNC" set/reset
    IDDR2_DAT_I (
       .    Q1              (   do_positive[i]), // 1-bit output captured with C0 clock
       .    Q2              (   do_negative[i]), // 1-bit output captured with C1 clock
       .    C               (   refer_clock), // 1-bit clock input
/*
       .    Q0              (   do_positive[i]), // 1-bit output captured with C0 clock
       .    Q1              (   do_negative[i]), // 1-bit output captured with C1 clock
       .    C0              (   refer_clock), // 1-bit clock input
       .    C1              (   ck_negative), // 1-bit clock input
*/
       .    CE              (   1'b1), // 1-bit clock enable input
       .    D               (   DDR_BUS_MDI[i]), // 1-bit DDR data input
       .    R               (   1'b0), // 1-bit reset input
       .    S               (   1'b0)); // 1-bit set input

        end // block: u
    endgenerate

endmodule //