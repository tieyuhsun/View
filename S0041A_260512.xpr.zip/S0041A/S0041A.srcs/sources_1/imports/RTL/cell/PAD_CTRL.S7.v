module  PAD_CTRL
 #
(
     
     
   //parameter  latch_phase = "C0",   //C0 = refer_clock
     parameter  iopad_phase = "SAME_EDGE",   //C0 = refer_clock    #(.DDR_CLK_EDGE   ("SAME_EDGE"), //"OPPOSITE_EDGE"  "SAME_EDGE
     parameter  iopad_width = 4

)
(
    input                           refer_clock,
//
    input       [   iopad_width-1:0]rd_positive,
    input       [   iopad_width-1:0]rd_negative,
//
    input       [   iopad_width-1:0]di_positive,
    input       [   iopad_width-1:0]di_negative,
//
  //output  wire[   iopad_width-1:0]do_positive,
  //output  wire[   iopad_width-1:0]do_positive,
    output  wire[   iopad_width-1:0]DDR_PAD_OUT,
//
    inout   wire[   iopad_width-1:0]DDR_BUS_PAD

);
            wire[   iopad_width-1:0]DDR_BUS_MDO;
          //wire[   iopad_width-1:0]DDR_BUS_MDI;
            wire[   iopad_width-1:0]DDR_BUS_TRI;

genvar i;
    generate
    for (i=0; i<iopad_width; i=i+1)
        begin: U
/*
    IDDR2 #(
       .    DDR_ALIGNMENT   (   latch_phase), // Sets output alignment to "NONE", "C0" or "C1"
       .    INIT_Q0         (   1'b0), // Sets initial state of the Q0 output to 1U+00A1U+00A6b0 or 1U+00A1U+00A6b1
       .    INIT_Q1         (   1'b0), // Sets initial state of the Q1 output to 1U+00A1U+00A6b0 or 1U+00A1U+00A6b1
       .    SRTYPE          (   "ASYNC"))// Specifies "SYNC" or "ASYNC" set/reset
    IDDR2_DAT_I (
       .    Q0              (   do_positive[i]), // 1-bit output captured with C0 clock
       .    Q1              (   do_negative[i]), // 1-bit output captured with C1 clock
       .    C0              (   refer_clock), // 1-bit clock input
       .    C1              (   ck_negative), // 1-bit clock input
       .    CE              (   1'b1), // 1-bit clock enable input
       .    D               (   DDR_BUS_MDI[i]), // 1-bit DDR data input
       .    R               (   1'b0), // 1-bit reset input
       .    S               (   1'b0)); // 1-bit set input
*/
   // DDR register instantation

    ODDR #(
        .   DDR_CLK_EDGE    (   iopad_phase), // Sets output alignment to "NONE", "C0" or "C1"
        .   INIT            (   1'b0), // Sets initial state of the Q output to 1U+00A1U+00A6b0 or 1U+00A1U+00A6b1
        .   SRTYPE          (   "ASYNC")) // Specifies "SYNC" or "ASYNC" set/reset
    ODDR2_DAT_O (
        .   Q               (   DDR_BUS_MDO[i]), // 1-bit DDR output data
        .   CE              (   1'b1), // 1-bit clock enable input
        .   C               (   refer_clock), // 1-bit clock input
        .   D1              (   di_positive[i]),
        .   D2              (   di_negative[i]),
/*
        .   C0              (   refer_clock), // 1-bit clock input
        .   C1              (   ck_negative), // 1-bit clock input
        .   D0              (   di_positive[i]), // 1-bit data input (associated with C0)
        .   D1              (   di_negative[i]), // 1-bit data input (associated with C1)

*/
        .   R               (   1'b0), // 1-bit reset input
        .   S               (   1'b0)); // 1-bit set input

    ODDR #(
        .   DDR_CLK_EDGE    (   iopad_phase), // Sets output alignment to "NONE", "C0" or "C1"
        .   INIT            (   1'b0), // Sets initial state of the Q output to 1U+00A1U+00A6b0 or 1U+00A1U+00A6b1
        .   SRTYPE          (   "ASYNC"))// Specifies "SYNC" or "ASYNC" set/reset
    ODDR2_TRI_O (
        .   Q               (   DDR_BUS_TRI[i]), // 1-bit DDR output data
        .   CE              (   1'b1), // 1-bit clock enable input
        .   C               (   refer_clock), // 1-bit clock input
        .   D1              (   rd_positive[i]),
        .   D2              (   rd_negative[i]),
/*
        .   C0              (   refer_clock), // 1-bit clock input
        .   C1              (   ck_negative), // 1-bit clock input
        .   D0              (   rd_positive[i]), // 1-bit data input (associated with C0)
        .   D1              (   rd_negative[i]), // 1-bit data input (associated with C1)
*/
        .   R               (   1'b0), // 1-bit reset input
        .   S               (   1'b0)); // 1-bit set input

    IOBUF
    IOBUF_PAD (
        .   O               (   DDR_PAD_OUT[i]), // Buffer output
        .   IO              (   DDR_BUS_PAD[i]), // Buffer inout port (connect directly to top-level port)
        .   I               (   DDR_BUS_MDO[i]), // Buffer input
        .   T               (   DDR_BUS_TRI[i])); // 3-state enable input, high=input, low=output

        end // block: u
    endgenerate

endmodule //