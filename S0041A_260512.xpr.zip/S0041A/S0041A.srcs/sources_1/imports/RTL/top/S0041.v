module  S0041
#(
//
    parameter   version_int     =   1,      //byte[3]
    parameter   version_dec     =   0,      //byte[4]
    parameter   version_age     =   2026,   //byte[5]
    parameter   version_mth     =   5,      //byte[6]
    parameter   version_day     =   15,     //byte[7]
//
    parameter   [   7   : 0]setup_speed[3:0]=  { 8'd01,8'd01,8'd06,8'd69},  //loacl.0 {(reserve),engine.in ,engine.in ,engine.in }
    parameter   [   7   : 0]setup_shift[3:0]=  { 8'h00,8'h00,8'h00,8'h05},  //loacl.1 {(reserve),engine.out,engine.out,engine.out}  limit_angle
//
    parameter   timer_ports     =   1,//ports = mzses_timer[timer_ports]
    parameter   loops_chain     =   3,//place_ports[loops_chain]
    parameter   expon_ports     =   2,//
  //parameter   loops_lines     =   1,//
//
    parameter   expon_burst     =   6, //external sram    1920@148.5/((96*64/68)/2)
    parameter   expon_hight     =   9,  //
    parameter   expon_width     =   8,  //8b,9b,3b
//
    parameter   mem_bit_ctl     =   3,
    parameter   mem_bit_bnk     =   3,
    parameter   mem_bit_row     =   20,
    parameter   mem_bit_col     =   20,
    parameter   mem_bit_dat     =   16,

    parameter   mem_cmd_nop     =   7,// COMMAND_NOP
    parameter   mem_cmd_mrs     =   0,// COMMAND_MRS
    parameter   mem_cmd_pre     =   2,// COMMAND_PRE
    parameter   mem_cmd_ref     =   1,// COMMAND_REF
    parameter   mem_cmd_zqc     =   6,// ZQC =   3'b
    parameter   mem_cmd_act     =   3,// COMMAND_ACT
    parameter   mem_cmd_wex     =   4,// COMMAND_WEx
    parameter   mem_cmd_rdx     =   5,// COMMAND_RDx
//
    parameter   chars_pixel     =   0,
    parameter   chars_initi     =   1,
    parameter   chars_latch     =   2,
    parameter   chars_pause     =   3,
    parameter   [   7   : 0]sizes_ascii[1:0]=  { 8'h10, 8'h08},             //loacl.4 pattern.ascii(reserve)
    parameter   [   15  : 0]sizes_panel[1:0]=  {16'd16,16'd144},            //loacl.5 pattern.outline
//arsenal
    parameter   files_mzaes     =   "./P02027_MAZE.mem",
    parameter   files_loop1     =   "./P02027_PINS.mem",//files_loop1
    parameter   files_loop2     =   "./P02027_LINE.mem",//files_loop2
    parameter   files_loop3     =   "./P02027_PART.mem",//files_loop3   {port,cascade}
    parameter   files_pulse     =   "./P02027_WAVE.mem",//
    parameter   files_setup     =   "./P02027_BOOT.mem",//
    parameter   files_fonts     =   "./TXT128_H16x8b.mem",//
    parameter   files_exp01     =   "./square32b10a.mem",//"./square32b10a.mem",//
//arsenal
    parameter   cache_parts     =   0,//
    parameter   cache_chips     =   0,//
    parameter   cache_lines     =   0,//
    parameter   cache_mazes     =   0,
    parameter   cache_gamma     =   1,
    parameter   cache_fonts     =   1,
    parameter   cache_setup     =   1,
//
    parameter   expon_cores     =   0,//maze.multitask      1<<expon_cores
    parameter   expon_mazes     =   6,//    maze_core       6b+0b   = 6b 
    parameter   expon_index     =   2,//maze_compass.loop
    parameter   [7:0]expon_loops[(1<<expon_index)-1:0]= {8'd0,8'd4,8'd4,8'd9},
    parameter   expon_setup     =   3,//pattern.font        1110,0000,0000,00--
    parameter   expon_pulse     =   4,  //
    parameter   expon_gamma     =   8,//gamma               6b+2b = 8b  
    parameter   [7:0]expon_field[1:0]=   { 8'h02, 8'h02},
    parameter   expon_steps     =   2,//demux,   expon_steps
//
    parameter   gray_syncer     =   1,
    parameter   frequencies     =   96000000,
    parameter   frame_rates     =   80

/**/
)(
/*
    HUB75
        1   R[1]            2   G[1]
        3   B[1]            4   GND
        5   R[2]            6   G[2]
        7   B[2]            8   GND
        9   A               10  B
        11  C               12  D
        13  CK              14  Latch
        15  OE              16  GND

*/

    output  wire        PIN_LED_A02,//  LED.G
    output  wire        PIN_LED_A03,//  LED.R

    output  wire        PIN_DIR_B01,//  1 = SET ,0 = GET
//
    inout   wire        PIN_MUL_L04,//  PIN[A/C][  17]                          //  
    inout   wire        PIN_MDO_D02,//  PIN[A/C][  18]                          // 
    inout   wire        PIN_LAT_C01,//  PIN[A/C][  19]                          //
    inout   wire        PIN_ADO_H04,//  PIN[A/C][  20]                          //
    inout   wire        PIN_NET_C18,//  PIN[A/C][  21]  CR381B_BITS[1]; //G1    // 
    inout   wire        PIN_NET_C17,//  PIN[A/C][  22]  CR381B_BITS[2]; //B1    // 
    inout   wire        PIN_NET_B18,//  PIN[A/C][  23]  CR381A_BITS[2]; //B0    // GND 
    inout   wire        PIN_NET_B17,//  PIN[A/C][  24]  CR381B_BITS[0]; //R1    // DATA_4_IN
    inout   wire        PIN_NET_A17,//  PIN[A/C][  25]  CR381A_BITS[0]; //R0    // DATA_2_IN
    inout   wire        PIN_NET_B16,//  PIN[A/C][  26]  CR381A_BITS[1]; //G0    // DATA_3_IN
    inout   wire        PIN_NET_A16,//  PIN[A/C][  27]  DCK                     // GCLK_IN
    inout   wire        PIN_NET_J06,//  PIN[A/C][  29]  GCK                     // S3
    inout   wire        PIN_NET_B15,//  PIN[A/C][  30]  0                       // DATA_1_IN
    inout   wire        PIN_NET_M16,//  PIN[A/C][  31]  line[2]                 // LATCH_IN
    inout   wire        PIN_NET_A15,//  PIN[A/C][  32]  line[3]                 // CLK_IN
    inout   wire        PIN_NET_B14,//  PIN[A/C][  33]  line[0]                 // S1
    inout   wire        PIN_NET_G13,//  PIN[A/C][  34]  line[1]                 // S0
    inout   wire        PIN_NET_C14,//  PIN[A/C][  35]  latch                   // S2
//
    inout   wire        PIN_NET_R04,//  PIN[B/D][  21]  CR381D_BITS[1]; //G1
//
    inout   wire        PIN_NET_R03,//  PIN[B/D][  22]  CR381D_BITS[2]; //B1
    inout   wire        PIN_NET_P05,//  PIN[B/D][  23]  CR381C_BITS[2]; //B0
    inout   wire        PIN_NET_N04,//  PIN[B/D][  24]  CR381D_BITS[0]; //R1
    inout   wire        PIN_NET_N03,//  PIN[B/D][  25]  CR381C_BITS[0]; //R0
    inout   wire        PIN_NET_M04,//  PIN[B/D][  26]  CR381C_BITS[1]; //G0
    inout   wire        PIN_NET_V12,//  PIN[B/D][  27]  DCK
    inout   wire        PIN_NET_D10,//  PIN[B/D][  29]  GCK
    inout   wire        PIN_NET_U11,//  PIN[B/D][  30]  0
    inout   wire        PIN_NET_H13,//  PIN[B/D][  31]  line[2]
    inout   wire        PIN_NET_V07,//  PIN[B/D][  32]  line[3]
    inout   wire        PIN_NET_U07,//  PIN[B/D][  33]  line[0]
    inout   wire        PIN_NET_H16,//  PIN[B/D][  34]  line[1]
    inout   wire        PIN_NET_E14,//  PIN[B/D][  35]  latch
//

//Video
    input                               video_vsync,
    input                               video_hsync,
    input                               video_esync,
    input       [                 23: 0]video_pixel,
    input                               video_clock,
//
    inout   wire                        plug_detect,//<-
    inout   wire                        display_scl,//monitor
    inout   wire                        display_sda,
//
    input                               STM32_TYPEC,//<-
    input                               TYPEC_STM32,//<-
//
//
//SRAM
    output  wire[                 19: 0]ram_adr_pad,//51216 , 25616
    inout   wire[                 15: 0]ram_dat_pad,
    output  wire                        ram_wen_pad,
    output  wire                        ram_oen_pad,
//CPU->Boot/FPGA
    inout   wire                        SPI_ROM_PAD,//MCU_SPI\SEL\0_FPGABOOT
  //inout   wire                        SPI_INT_PAD,//MCU_SPI\SEL\0_FPGA1   PIN_IO3_M15
  //input                               SPI_CPU_PAD,//MCU_SPI\SEL\0_FPGA0   PIN_IO2_L14
    input                               PIN_IO3_M15,//MCU_SPI\SEL\0_FPGA1
    input                               PIN_IO2_L14,//MCU_SPI\SEL\0_FPGA0   
    input                               SPI_SCK_PAD,//
    input                               SPI_CD0_PAD,//rom.SI.IO0    cpu.out
    output  wire                        SPI_D1C_PAD,//rom.SO.IO1    cpu.in
//
    input                               exten_clock
);

//
            wire                        refer_clock;
          //wire                        asram_clock;
            wire                        refer_ready;
    S0041PLL
    S0041PLL(
        .   refer_clock             (   refer_clock),
      //.   asram_clock             (   asram_clock),
        .   refer_ready             (   refer_ready),
        .   exten_clock             (   exten_clock));
//
            reg [               5   : 0]divide_26ck;//96Mhz/26 = 115200*32 = 3,692,307
            reg                         BuatRatex32;
            reg [               3   : 0]filter_uart;
            reg                         broadcaster;
always@(posedge refer_clock)divide_26ck <= (divide_26ck==25)?0:(divide_26ck+1);
always@(posedge refer_clock)BuatRatex32 <= (divide_26ck==25);//3M
always@(posedge refer_clock)filter_uart <=  BuatRatex32?{filter_uart,TYPEC_STM32}:filter_uart;
always@(posedge refer_clock)broadcaster <=  broadcaster?(|filter_uart):(&filter_uart);

            reg [               15  : 0]linear_code;
            wire[               15  : 0]evenly_code;
            wire[               7   : 0]frame_value;
            wire[               63  : 0]evenly_data = ((frame_value<<(16+16))/frequencies);//3579;//((frame_rates<<(16+16))/frequencies);
            reg                         frame_x_16b;// 
always@(posedge refer_clock)linear_code <=  linear_code+1;//
    linear_transform#   (   .   range           (   16))
    linear_transform    (   .   linear_code     (   linear_code),   .   evenly_code (   evenly_code));
always@(posedge refer_clock)frame_x_16b <=|(evenly_code&evenly_data);//


/*
//  linear_transform = 16b
//  frame_rates=80                                  frame_rates=60
    plug_timers[3:0]                    hz=327,680  hz=245,760

                        0       1
    plug_timers[16]     12.5ms  12.5ms  hz=40       hz=30
    plug_timers[17]     25.0ms  25.0ms  hz=20       hz=15
    plug_timers[18]     50.0ms  50.0ms  hz=10       hz=7.5
    plug_timers[19]     0.1s    0.1s    hz=5        hz=3.75
    plug_timers[20]     0.2s    0.2s    hz=2.5      hz=1.875
    plug_timers[21]     0.4s    0.4s    hz=1.25     hz=0.9375
    plug_timers[22]     0.8s    0.8s    hz=0.625    hz=0.46875
    plug_timers[23]     1.6s    1.6s    hz=0.3125   hz=0.234375
    frame_x_16b
*/
            reg [               23  : 0]plug_timers;//[16] = 12.5ms,12.5ms    @frame_rates=80
            reg [               3   : 0]plug_filter;
            reg                         plug_enable;initial plug_enable =   0;
            wire                        image_vsync;
            wire                        image_hsync;
            wire                        image_esync;
            wire[               23  : 0]image_pixel;
            wire[    (expon_hight+0): 0]image_hight;
            wire[    (expon_width+0): 0]image_width;
            wire[               15  : 0]image_frame;
            reg [               3   : 0]shift_frame;
            reg [               3   : 0]shift_hsync;//30K~70K
            reg [               1   : 0]clear_frame;//~3        ~frame/256
            reg [               1   : 0]clear_hsync;//~320hz    ~hsync/256
            reg [               3   : 0]check_frame;
            reg [               3   : 0]check_hsync;
            reg                         image_state;//
assign  plug_detect = (&plug_timers[23:19])?(image_state?1'bz:1'b0):1'bz;//


always@(posedge refer_clock)plug_timers <= (frame_x_16b&&(&plug_timers[ 3: 0])&&(&plug_filter)&&(!plug_enable))?0:(plug_timers+frame_x_16b);//
always@(posedge refer_clock)plug_filter <= (frame_x_16b&&(&plug_timers[ 3: 0]))?{plug_filter,plug_detect}:plug_filter;
always@(posedge refer_clock)plug_enable <=  plug_enable?(|plug_filter):(&plug_filter);

always@(posedge refer_clock)shift_frame <= {shift_frame,image_frame[0]};//
always@(posedge refer_clock)shift_hsync <= {shift_hsync,image_hsync};//
always@(posedge refer_clock)clear_frame <= {clear_frame,plug_timers[23]};//~3hz
always@(posedge refer_clock)clear_hsync <= {clear_hsync,plug_timers[13]};//~320hz
always@(posedge refer_clock)check_frame <= (shift_frame[2]^shift_frame[1])?15:((^clear_frame)?(check_frame-(|check_frame)):check_frame);//
always@(posedge refer_clock)check_hsync <= (shift_hsync[2]^shift_hsync[1])?15:((^clear_hsync)?(check_hsync-(|check_hsync)):check_hsync);//
always@(posedge refer_clock)image_state <=(|check_frame)||(|check_hsync);



    EDID #(
      //.   edid_path               (   "./DDC_FHD.hex"))
        .   edid_path               (   "./DDC_640_480.hex"))
    EDID(
        .   DDC_SCL_PAD             (   display_scl),
        .   DDC_SDA_PAD             (   display_sda),
        .   refer_ready             (   plug_enable),
        .   refer_carry             (   BuatRatex32),
        .   refer_clock             (   refer_clock));

            wire                        image_clock;
    IBUFG   image_ibufg (.O (image_clock), .I (video_clock));

    VIDEO_TTL
    VIDEO_TTL (
        .   video_ready             (   plug_enable), 
        .   video_vsync             (   video_vsync), 
        .   video_hsync             (   video_hsync), 
        .   video_esync             (   video_esync), 
        .   video_pixel             (   video_pixel), 
        .   video_clock             (   image_clock), 
        .   image_vsync             (   image_vsync), 
        .   image_hsync             (   image_hsync), 
        .   image_esync             (   image_esync), 
        .   image_pixel             (   image_pixel), 
        .   image_width             (   image_width), 
        .   image_hight             (   image_hight), 
        .   image_frame             (   image_frame), 
        .   image_ready             (   ));


    
            wire[   mem_bit_ctl-1   : 0]memory_ctrl;//  ->memory
            wire[   mem_bit_bnk-1   : 0]memory_bank;//  ->memory
            wire[   mem_bit_row-1   : 0]memory_page;//  ->memory
            wire[   mem_bit_col-1   : 0]memory_addr;//  ->memory
            wire[   mem_bit_dat-1   : 0]memory_data;//  ->memory
            wire                        gamma_catch;//  ->color
            wire[   expon_gamma-1   : 0]gamma_curve;//  ->color
            wire[               32  : 0]gamma_slope;//  ->color
            wire                        gamma_ready;//  check exp10
            wire                        demux_bidir;//->
            wire                        demux_break;//->
            wire                        demux_latch;
            wire[  (expon_steps+7)  : 0]demux_cycle;//->

            wire[               7   : 0]column_code;//
            wire                        column_ctrl;//
            wire                        column_mark;//


            wire[               1   : 0]row_control;//


            wire                        inside_port;//
            wire[    (expon_ports-1): 0]place_ports;//  cascade_sel
            wire[               15  : 0]mazes_hight;        //  arsenal(maze_core.loop[1/2/3])
            wire[               15  : 0]mazes_width;        //  arsenal(maze_core.loop[1/2/3])
            wire[               17  : 0]mazes_chars;        //  maze_core   ->   
            wire[               2   : 0]mazes_reset;        //  maze_engine ->  
            wire[               2   : 0]mazes_syncs;        //  maze_engine -> 

            wire[               7   : 0]bright_lv10;//->memory_distr    spi.fw
            wire[               23  : 0]bright_data;//->memory_distr    spi.fw
            wire[               1   : 0]pattern_ena;//pattern
            wire[               7   : 0]pattern_dat[2:0];//pattern
            wire                        correct_ena;//->memory_distr    spi.fw
            wire[               7   : 0]identifiers;//->SERDES
            wire[               23  : 0]driver_gain;
            wire[               7   : 0]connect_wen;
            wire[               7   : 0]frame_tasks;//2,1,0  
            wire[               15  : 0]frame_count;

            wire[               3   : 0]panel_count[1:0];   //  <-  expon_ports,expon_chain
            wire[               1   : 0]link_status;        //  <-  SERDES.Data Stream status
            wire                        link_select;        //  <-  SERDES.Data Stream Redundancy 
            wire[               7   : 0]network_col;        //  <-  SERDES.ID: scan board
            wire[               5   : 0]network_row;        //  <-  SERDES.ID: fiber/coaxial 
            wire                        BuatRatex32;// 
            wire                        broadcaster;
            wire                        frame_x_16b;
            wire[               7   : 0]SPI_GET_MEM;
            
assign  frame_value =   
                      (|pattern_ena)?   frame_rates :
                      (!image_state)?   frame_rates :60;

    behavior#(
        .   mem_bit_ctl             (   mem_bit_ctl),//=   3,
        .   mem_bit_bnk             (   mem_bit_bnk),//=   3,
        .   mem_bit_row             (   mem_bit_row),//=   20,
        .   mem_bit_col             (   mem_bit_col),//=   20,
        .   mem_bit_dat             (   mem_bit_dat),//=   16,
        .   mem_cmd_nop             (   mem_cmd_nop),//=   7,// COMMAND_NOP
        .   mem_cmd_mrs             (   mem_cmd_mrs),//=   0,// COMMAND_MRS
        .   mem_cmd_pre             (   mem_cmd_pre),//=   2,// COMMAND_PRE
        .   mem_cmd_ref             (   mem_cmd_ref),//=   1,// COMMAND_REF
        .   mem_cmd_zqc             (   mem_cmd_zqc),//=   6,// ZQC =   3'b
        .   mem_cmd_act             (   mem_cmd_act),//=   3,// COMMAND_ACT
        .   mem_cmd_wex             (   mem_cmd_wex),//=   4,// COMMAND_WEx
        .   mem_cmd_rdx             (   mem_cmd_rdx),//=   5,// COMMAND_RDx
        .   setup_speed             (   setup_speed),  //{(reserve),engine.in ,engine.in ,engine.in }
        .   setup_shift             (   setup_shift),  //{(reserve),engine.out,engine.out,engine.out}  limit_angle
        .   timer_ports             (   timer_ports),
        .   loops_chain             (   loops_chain),
        .   expon_ports             (   expon_ports),
      //.   loops_lines             (   loops_lines),
        .   expon_burst             (   expon_burst),
        .   expon_width             (   expon_width),
        .   expon_hight             (   expon_hight),

        .   sizes_ascii             (   sizes_ascii),
        .   sizes_panel             (   sizes_panel),
        .   files_mzaes             (   files_mzaes),//=   "./P160522_MAZE.mem",
        .   files_loop1             (   files_loop1),//=   "./P160522_CHIP.mem",//files_loop1
        .   files_loop3             (   files_loop3),//=   "./P160522_PART.mem",//files_loop3   {port,cascade}
        .   files_loop2             (   files_loop2),//=   "./P160522_LINE.mem",//files_loop2
        .   files_pulse             (   files_pulse),//=   "./P160522_WAVE.mem",//
        .   files_setup             (   files_setup),//=   "./P160522_CONFIG.mem",//

        .   expon_cores             (   expon_cores),//
        .   expon_mazes             (   expon_mazes),//
        .   expon_index             (   expon_index),//
        .   expon_loops             (   expon_loops),//
        .   expon_setup             (   expon_setup),//
        .   expon_pulse             (   expon_pulse),//
        .   expon_gamma             (   expon_gamma),//
        .   expon_field             (   expon_field),//
        .   expon_steps             (   expon_steps),

        .   gray_syncer             (   gray_syncer),
        .   frequencies             (   frequencies),//=   125000000,
        .   frame_rates             (   frame_rates))//=   60
    behavior (
        .   memory_ctrl             (   memory_ctrl),
        .   memory_bank             (   memory_bank),
        .   memory_page             (   memory_page),
        .   memory_addr             (   memory_addr),
        .   memory_data             (   memory_data),
        .   gamma_catch             (   gamma_catch),        //  gamma_catch
        .   gamma_curve             (   gamma_curve),        //  gamma_curve
        .   gamma_slope             (   gamma_slope),        //  gamma_slope
        .   gamma_ready             (   gamma_ready),        //  check exp10
        .   demux_bidir             (   demux_bidir),//->
        .   demux_break             (   demux_break),//->
        .   demux_latch             (   demux_latch),//->
        .   demux_cycle             (   demux_cycle),//->

        .   column_code             (   column_code),   //
        .   column_ctrl             (   column_ctrl),   //
        .   column_mark             (   column_mark),   //
        .   row_trigger             (   row_trigger),   //
        .   row_control             (   row_control),   //
        .   inside_port             (   inside_port),
        .   place_ports             (   place_ports),//  cascade_sel
        .   mazes_hight             (   mazes_hight),   //  arsenal(maze_core.loop[1/2/3])
        .   mazes_width             (   mazes_width),   //  arsenal(maze_core.loop[1/2/3])
        .   mazes_chars             (   mazes_chars),   //  maze_core   ->   
        .   mazes_reset             (   mazes_reset),   //  maze_engine ->  
        .   mazes_syncs             (   mazes_syncs),   //  maze_engine -> 
        .   bright_lv10             (   bright_lv10),   //->memory_distr    spi.fw
        .   bright_data             (   bright_data),   //->memory_distr    spi.fw
        .   pattern_ena             (   pattern_ena),   //pattern
        .   pattern_dat             (   pattern_dat),   //pattern
        .   correct_ena             (   correct_ena),   //->memory_distr    spi.fw
        .   identifiers             (   identifiers),   //->SERDES
        .   driver_gain             (   driver_gain),
        .   connect_wen             (   connect_wen),
        .   frame_tasks             (   frame_tasks),//2,1,0  
        .   frame_count             (   frame_count),
        .   panel_count             (   panel_count),   //  <-  expon_ports,expon_chain
        .   image_clock             (   image_clock),   //  <-  image
        .   image_vsync             (   image_vsync),   //  <-  image
        .   image_hsync             (   image_hsync),   //  <-  image
        .   image_esync             (   image_esync),   //  <-  image
        .   image_pixel             (   image_pixel),   //  <-  image
        .   image_hight             (   image_hight),   //  <-  image
        .   image_width             (   image_width),   //  <-  image
        .   image_frame             (   image_frame),   //  <-  image
        .   link_status             (   link_status),   //  <-  SERDES.Data Stream status
        .   link_select             (   link_select),   //  <-  SERDES.Data Stream Redundancy 
        .   network_col             (   network_col),   //  <-  SERDES.ID: scan board
        .   network_row             (   network_row),   //  <-  SERDES.ID: fiber/coaxial 
        .   BuatRatex32             (   BuatRatex32),   // 
        .   broadcaster             (   broadcaster),   //
        .   frame_x_16b             (   frame_x_16b),   //
        .   SPI_GET_MEM             (   SPI_GET_MEM),
        .   SPI_ROM_PAD             (   SPI_ROM_PAD),   //  <-  CPU->Boot/FPGA    MCU_SPI\SEL\0_FPGABOOT
        .   SPI_INT_PAD             (   PIN_IO3_M15),   //  <-  CPU->Boot/FPGA    MCU_SPI\SEL\0_FPGA1
        .   SPI_CPU_PAD             (   PIN_IO2_L14),   //  <-  CPU->Boot/FPGA    MCU_SPI\SEL\0_FPGA0
        .   SPI_SCK_PAD             (   SPI_SCK_PAD),   //  <-  CPU->Boot/FPGA    
        .   SPI_CD0_PAD             (   SPI_CD0_PAD),   //  <-  CPU->Boot/FPGA    rom.SI.IO0    cpu.out
        .   SPI_D1C_PAD             (   SPI_D1C_PAD),   //  <-  CPU->Boot/FPGA    rom.SO.IO1    cpu.in
        .   refer_ready             (   refer_ready),
        .   refer_clock             (   refer_clock));


            wire                        ram_wen_set;
            wire                        ram_oen_set;
            wire[                19:  0]ram_adr_set;
            wire[                15:  0]ram_dat_set;

assign  ram_wen_set =  (memory_ctrl==mem_cmd_wex)?1'b0:1'b1;
assign  ram_oen_set =  (memory_ctrl==mem_cmd_rdx)?1'b0:1'b1;
assign  ram_adr_set =   memory_addr;
assign  ram_dat_set =   memory_data;
/*
            reg                         ram_wen_set;
            reg                         ram_oen_set;
            reg [                19:  0]ram_adr_set;
            reg [                15:  0]ram_dat_set;

always@(posedge asram_clock)ram_wen_set <= (memory_ctrl==mem_cmd_wex)?1'b0:1'b1;
always@(posedge asram_clock)ram_oen_set <= (memory_ctrl==mem_cmd_rdx)?1'b0:1'b1;
always@(posedge asram_clock)ram_adr_set <=  memory_addr;
always@(posedge asram_clock)ram_dat_set <=  memory_data;
*/
            wire[                15:  0]ram_dat_get;
            wire[                15:  0]ram_dat_net;
    PAD_CTRL#(
        .   iopad_width             (   20+1+1))//47
    ADDR_CTRL (
        .   rd_positive             (   0),
        .   rd_negative             (   0),
        .   refer_clock             (   refer_clock),/*duty*/
        .   di_positive             (  {ram_adr_set,       1'b1,ram_oen_set}),
        .   di_negative             (  {ram_adr_set,ram_wen_set,ram_oen_set}),
        .   DDR_PAD_OUT             (   ),
        .   DDR_BUS_PAD             (  {ram_adr_pad,ram_wen_pad,ram_oen_pad}));
    PAD_CTRL#(
        .   iopad_width             (   16))
    DATA_CTRL (
        .   refer_clock             (   refer_clock),
        .   rd_positive             ({16{ram_wen_set}}),
        .   rd_negative             ({16{ram_wen_set}}),
        .   di_positive             (   ram_dat_set),
        .   di_negative             (   ram_dat_set),
        .   DDR_PAD_OUT             (   ram_dat_net),
        .   DDR_BUS_PAD             (   ram_dat_pad));
    PAD_LATCH#(
        .   iopad_width             (   16))
    DATA_LATCH    (
        .   refer_clock             (   refer_clock),//refer_loads),//refer_write),//refer_loads),
        .   do_positive             (   ),
        .   do_negative             (   ram_dat_get),
        .   DDR_BUS_MDI             (   ram_dat_net));


            reg [               15  : 0]ram_dat_buf;
always@(posedge refer_clock)ram_dat_buf <=  ram_dat_get;//
//

            wire[               63  : 0]demux_catch[(1<<expon_ports)-1:0];//cache cage

    memory_cache#(
        .   expon_ports             (   expon_ports),
        .   delay_cycle             (   3))
    memory_cache    (
        .   catch_coefs             (   SPI_GET_MEM),
        .   demux_catch             (   demux_catch),//cache cage

        .   mazes_hight             (   mazes_hight),   //  arsenal(maze_core.loop[1/2/3])
        .   mazes_width             (   mazes_width),   //  arsenal(maze_core.loop[1/2/3])
        .   mazes_chars             (   mazes_chars),
        .   mazes_syncs             (   mazes_syncs),
        .   mazes_reset             (   mazes_reset),

        .   inside_port             (   inside_port),
        .   place_ports             (   place_ports),//  cascade_sel
        .   memory_ctrl             (   memory_ctrl),
        .   memory_bank             (   memory_bank),
        .   memory_page             (   memory_page),
        .   memory_addr             (   memory_addr),
        .   memory_data             (   ram_dat_buf),
        .   gamma_catch             (   gamma_catch),
        .   gamma_curve             (   gamma_curve),
        .   gamma_slope             (   gamma_slope),
        .   gamma_ready             (   gamma_ready),
      //.   config_chip             (   config_chip),
        .   bright_lv10             (   bright_lv10),
        .   bright_data             (   bright_data),
        .   pattern_ena             (   pattern_ena),
        .   pattern_dat             (   pattern_dat),
        .   correct_ena             (   correct_ena),
        .   driver_gain             (   driver_gain),
        .   frame_tasks             (   frame_tasks),//2,1,0  
        .   refer_ready             (   refer_ready),
        .   refer_clock             (   refer_clock));


            wire                        panel_clock;
            wire                        panel_latch;
            wire[ (1<<expon_ports)-1: 0]panel_runes;
    launchpad#(
        .   expon_steps             (   expon_steps),
      //.   expon_field             (   expon_field),
        .   expon_ports             (   expon_ports))
    launchpad(
        .   panel_clock             (   panel_clock),
        .   panel_latch             (   panel_latch),
        .   panel_runes             (   panel_runes),

        .   demux_catch             (   demux_catch),

        .   demux_bidir             (   demux_bidir),//->
        .   demux_break             (   demux_break),//->
        .   demux_latch             (   demux_latch),//->
        .   demux_cycle             (   demux_cycle),//->

        .   refer_ready             (   refer_ready),
        .   refer_clock             (   refer_clock));


            reg [   expon_pulse-1   : 0]label_pulse[1:0];
            reg [               1   : 0]gray_select;
            reg [               1   : 0]gray_strobe;
            reg [               1   : 0]gray_repeat;
            
(* KEEP="TRUE" *)reg [               15  : 0]panel_lines;
(* KEEP="TRUE" *)reg [               15  : 0]panel_sigma;
            reg                         panel_grays;
            reg                         frame_clock;
            reg                         frame_latch;
always@(posedge refer_clock)label_pulse[0]  <=(!column_ctrl&&column_mark)?(column_code>>0):label_pulse[0];
always@(posedge refer_clock)label_pulse[1]  <=(!column_ctrl&&column_mark)?(column_code>>8):label_pulse[1];
always@(posedge refer_clock)gray_select[0]  <=( label_pulse[0]==column_code[expon_pulse-1:0]);
always@(posedge refer_clock)gray_select[1]  <=( label_pulse[1]==column_code[expon_pulse-1:0]);
always@(posedge refer_clock)gray_strobe[0]  <=((label_pulse[0]==column_code[expon_pulse-1:0])&&column_ctrl);
always@(posedge refer_clock)gray_strobe[1]  <=((label_pulse[1]==column_code[expon_pulse-1:0])&&column_ctrl);
always@(posedge refer_clock)gray_repeat[0]  <=((label_pulse[0]==column_code[expon_pulse-1:0])&&column_mark)||(!column_ctrl&&column_mark);
always@(posedge refer_clock)gray_repeat[1]  <=((label_pulse[1]==column_code[expon_pulse-1:0])&&column_mark)||(!column_ctrl&&column_mark);

always@(posedge refer_clock)panel_lines     <=( gray_repeat[0])?0:(panel_lines+gray_strobe[0]);//
always@(posedge refer_clock)panel_sigma     <=( gray_repeat[1])?0:(panel_sigma+gray_strobe[1]);
always@(posedge refer_clock)panel_grays     <=  row_control[0]?(panel_grays^row_trigger):0;//

(* KEEP="TRUE" *)reg [               7   : 0]panel_delta;
            reg                         blank_grays;
always@(posedge refer_clock)
    if( gray_repeat[0]||gray_strobe[0])
    begin
        blank_grays <=  1;
        panel_delta <=  0;
    end
    else
    begin
        blank_grays <= (row_control[0]&&row_trigger)?0:blank_grays;
        panel_delta <=  panel_delta+(row_control[0]&&row_trigger&&(!blank_grays));//
    end

always@(posedge refer_clock)frame_latch     <=  row_control[1];
always@(posedge refer_clock)frame_clock     <=  row_control[1]?(frame_clock^row_trigger):0;

/*
    HUB75
        1   R[1]            2   G[1]
        3   B[1]            4   GND
        5   R[2]            6   G[2]
        7   B[2]            8   GND
        9   A               10  B
        11  C               12  D
        13  CK              14  Latch
        15  OE              16  GND


frame_count = frame_count + blank_carry
*/
/*
frame_count
    5b = 32+32
    64 /60fps ~1sec
*/
/*
            reg [               15  : 0]frame_distr;
            wire[               15  : 0]frame_carve;
always@(posedge refer_clock)frame_distr <=  frame_distr+frame_x_16b;//
    linear_transform#   (   .   range           (   16))
    frame_transform     (   .   evenly_code     (   frame_carve),   .   linear_code (  {image_frame,frame_distr}>>2)   );
*/
            wire[               15  : 0]frame_delta[2:0];
            reg [               1   : 0]frame_pulse;//
    frame_wave//0..31-31..0
    frame_wave_000      (   .   frame_delta     (   frame_delta[0]),    .   frame_count (  ( image_frame>>2)+0));
    frame_wave//31..0-0..31
    frame_wave_180      (   .   frame_delta     (   frame_delta[1]),    .   frame_count (  ( image_frame>>2)+32));
assign  frame_delta[2]  = ( plug_timers[3:1]==4)?(frame_delta[1]>>4):(frame_delta[1]>>5);//
always@(posedge refer_clock)frame_pulse[0]  <=|(evenly_code&(frame_delta[0]));//
always@(posedge refer_clock)frame_pulse[1]  <=|(evenly_code&(frame_delta[2]));//
    
//  LED.G
assign  PIN_LED_A02 = (|pattern_ena)?(frame_count[5]?frame_count[3]:1'bz):
                        frame_pulse[0]?image_state://image_state?(image_frame[5]?frame_count[3]:1'bz):
                        1'bz;

//  LED.R
assign  PIN_LED_A03 = (|pattern_ena)?(frame_count[5]?1'b1:1'bz):
                        frame_pulse[1]?image_state://image_state?(image_frame[5]?frame_count[3]:1'bz):
                        1'bz;
                     //(plug_timers[7:2]==0)?1'b1:1'bz;

            wire                        type_p02027;
            wire                        type_cr381s;
            wire                        cr381sundef;
            wire[               7   : 0]cr381srunes;
            wire[               7   : 0]cr381slines;
            wire                        cr381sclock;
            wire                        cr381sgrays;
            wire                        cr381slatch;
            wire                        p02027undef;
            wire[               7   : 0]p02027runes;
            wire[               7   : 0]p02027lines;
            wire                        p02027clock;
            wire                        p02027grays;
            wire                        p02027latch;
            wire[               20  : 0]connect_pin;
assign  type_p02027 =   1;
assign  p02027undef =   0;
assign  p02027runes =   panel_runes;
assign  p02027lines =   panel_lines;
assign  p02027clock =  (panel_clock||frame_clock);
assign  p02027grays =   panel_grays;
assign  p02027latch =  (panel_latch||frame_latch);

assign  connect_pin[ 2] =   type_p02027?p02027undef     :   cr381sundef   ;
assign  connect_pin[ 1] =   type_p02027?p02027undef     :   cr381sundef   ;
assign  connect_pin[ 4] =   type_p02027?p02027undef     :   cr381sundef   ;
assign  connect_pin[ 3] =   type_p02027?p02027undef     :   cr381sundef   ;
assign  connect_pin[ 6] =   type_p02027?p02027undef     :   cr381srunes[5];
assign  connect_pin[ 5] =   type_p02027?p02027undef     :   cr381srunes[6];
assign  connect_pin[ 8] =   type_p02027?p02027undef     :   cr381srunes[2];
assign  connect_pin[ 7] =   type_p02027?p02027runes[3]  :   cr381srunes[4];
assign  connect_pin[10] =   type_p02027?p02027runes[1]  :   cr381srunes[0];
assign  connect_pin[ 9] =   type_p02027?p02027runes[2]  :   cr381srunes[1];
assign  connect_pin[12] =   type_p02027?p02027grays     :   cr381sclock   ;
assign  connect_pin[14] =   type_p02027?p02027lines[3]  :   cr381sgrays   ;
assign  connect_pin[13] =   type_p02027?p02027runes[0]  :   cr381sundef   ;
assign  connect_pin[16] =   type_p02027?p02027latch     :   cr381slines[2];
assign  connect_pin[15] =   type_p02027?p02027clock     :   cr381slines[3];
assign  connect_pin[18] =   type_p02027?p02027lines[1]  :   cr381slines[0];
assign  connect_pin[17] =   type_p02027?p02027lines[0]  :   cr381slines[1];
assign  connect_pin[20] =   type_p02027?p02027lines[2]  :   cr381slatch   ;


//[ 2]--[A/C][17]  cr381sundef             // P02027undef
//[ 1]--[A/C][18]  cr381sundef             // P02027undef
//[ 4]--[A/C][19]  cr381sundef             // P02027undef
//[ 3]--[A/C][20]  cr381sundef             // P02027undef
//[ 6]--[A/C][21]  cr381srunes[5]; //G1    // P02027undef  
//[ 5]--[A/C][22]  cr381srunes[6]; //B1    // P02027undef  
//[ 8]--[A/C][23]  cr381srunes[2]; //B0    // P02027undef 
//[ 7]--[A/C][24]  cr381srunes[4]; //R1    // P02027runes[3]   DATA_4_IN
//[10]--[A/C][25]  cr381srunes[0]; //R0    // P02027runes[1]   DATA_2_IN
//[ 9]--[A/C][26]  cr381srunes[1]; //G0    // P02027runes[2]   DATA_3_IN
//[12]--[A/C][27]  cr381sclock             // P02027grays      GCLK_IN
//[14]--[A/C][29]  cr381sgrays             // P02027lines[3]   S3
//[13]--[A/C][30]  cr381sundef             // P02027runes[0]   DATA_1_IN
//[16]--[A/C][31]  cr381slines[2]          // P02027latch      LATCH_IN
//[15]--[A/C][32]  cr381slines[3]          // P02027clock      CLK_IN
//[18]--[A/C][33]  cr381slines[0]          // P02027lines[1]   S1
//[17]--[A/C][34]  cr381slines[1]          // P02027lines[0]   S0
//[20]--[A/C][35]  cr381slatch             // P02027lines[2]   S2



//  1 = SET ,0 = GET
assign  PIN_DIR_B01 =   pattern_ena||image_state;//
//
assign  PIN_MUL_L04 =   PIN_DIR_B01?connect_pin[ 2]:1'bz;//  PIN[A/C][  17]                          //  
assign  PIN_MDO_D02 =   PIN_DIR_B01?connect_pin[ 1]:1'bz;//  PIN[A/C][  18]                          // 
assign  PIN_LAT_C01 =   PIN_DIR_B01?connect_pin[ 4]:1'bz;//  PIN[A/C][  19]                          //
assign  PIN_ADO_H04 =   PIN_DIR_B01?connect_pin[ 3]:1'bz;//  PIN[A/C][  20]                          //
assign  PIN_NET_C18 =   PIN_DIR_B01?connect_pin[ 6]:1'bz;//  PIN[A/C][  21]  CR381B_BITS[1]; //G1    // TS[1]; //G1
assign  PIN_NET_C17 =   PIN_DIR_B01?connect_pin[ 5]:1'bz;//  PIN[A/C][  22]  CR381B_BITS[2]; //B1    // TS[2]; //B1
assign  PIN_NET_B18 =   PIN_DIR_B01?connect_pin[ 8]:1'bz;//  PIN[A/C][  23]  CR381A_BITS[2]; //B0    // GND TS[2]; //B0
assign  PIN_NET_B17 =   PIN_DIR_B01?connect_pin[ 7]:1'bz;//  PIN[A/C][  24]  CR381B_BITS[0]; //R1    // DATA_4_INTS[0]; //R1
assign  PIN_NET_A17 =   PIN_DIR_B01?connect_pin[10]:1'bz;//  PIN[A/C][  25]  CR381A_BITS[0]; //R0    // DATA_2_INTS[0]; //R0
assign  PIN_NET_B16 =   PIN_DIR_B01?connect_pin[ 9]:1'bz;//  PIN[A/C][  26]  CR381A_BITS[1]; //G0    // DATA_3_INTS[1]; //G0
assign  PIN_NET_A16 =   PIN_DIR_B01?connect_pin[12]:1'bz;//  PIN[A/C][  27]  DCK                     // GCLK_IN
assign  PIN_NET_J06 =   PIN_DIR_B01?connect_pin[14]:1'bz;//  PIN[A/C][  29]  GCK                     // S3
assign  PIN_NET_B15 =   PIN_DIR_B01?connect_pin[13]:1'bz;//  PIN[A/C][  30]  0                       // DATA_1_IN
assign  PIN_NET_M16 =   PIN_DIR_B01?connect_pin[16]:1'bz;//  PIN[A/C][  31]  line[2]                 // LATCH_IN
assign  PIN_NET_A15 =   PIN_DIR_B01?connect_pin[15]:1'bz;//  PIN[A/C][  32]  line[3]                 // CLK_IN
assign  PIN_NET_B14 =   PIN_DIR_B01?connect_pin[18]:1'bz;//  PIN[A/C][  33]  line[0]                 // S1
assign  PIN_NET_G13 =   PIN_DIR_B01?connect_pin[17]:1'bz;//  PIN[A/C][  34]  line[1]                 // S0
assign  PIN_NET_C14 =   PIN_DIR_B01?connect_pin[20]:1'bz;//  PIN[A/C][  35]  latch                   // S2
//
assign  PIN_NET_R04 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  21]  CR381D_BITS[1]; //G1
//
assign  PIN_NET_R03 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  22]  CR381D_BITS[2]; //B1
assign  PIN_NET_P05 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  23]  CR381C_BITS[2]; //B0
assign  PIN_NET_N04 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  24]  CR381D_BITS[0]; //R1
assign  PIN_NET_N03 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  25]  CR381C_BITS[0]; //R0
assign  PIN_NET_M04 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  26]  CR381C_BITS[1]; //G0
assign  PIN_NET_V12 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  27]  DCK
assign  PIN_NET_D10 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  29]  GCK
assign  PIN_NET_U11 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  30]  0
assign  PIN_NET_H13 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  31]  line[2]
assign  PIN_NET_V07 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  32]  line[3]
assign  PIN_NET_U07 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  33]  line[0]
assign  PIN_NET_H16 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  34]  line[1]
assign  PIN_NET_E14 =   PIN_DIR_B01?1'bz:1'bz;//  PIN[B/D][  35]  latch

endmodule