
module EDID
#(
    parameter   edid_path = "./4K2K60.hex",//"./DDC_FHD_60.hex",//"./4K2K60.hex",
    parameter   edid_type = "auto",/*auto block distributed*/
    
    parameter   timeout_bit = 8,


    parameter   device_id = 7'b1010000,
    parameter   phase = 6/*8*2*/

)
(
    inout   wire                        DDC_SCL_PAD,
    inout   wire                        DDC_SDA_PAD,
//
    output  wire                        sources_scl,
    output  wire                        sources_sda,
//
    input                               refer_ready,/*I2C ENA*/
    input                               refer_carry,/*I2C time out*/
    input                               refer_clock
);
            wire                        I2C_SCL_LOW = 0;
            wire[                   1:0]I2C_SCL_NET;
            reg [                   2:0]I2C_SDA_LOW;    initial I2C_SDA_LOW = 0;
            wire[                   1:0]I2C_SDA_NET;
            reg                         I2C_LNK_OFF;

assign DDC_SCL_PAD =  (!refer_ready||I2C_LNK_OFF)? 1'bz :(   I2C_SCL_LOW  ? 1'b0: 1'bz);
assign DDC_SDA_PAD =  (!refer_ready||I2C_LNK_OFF)? 1'bz :(( |I2C_SDA_LOW) ? 1'b0: 1'bz);



            reg                         DDC_SCL_NET;
            reg                         DDC_SDA_NET;
always@(posedge refer_clock)DDC_SCL_NET <=(!refer_ready||I2C_LNK_OFF)?1'b1:DDC_SCL_PAD;
always@(posedge refer_clock)DDC_SDA_NET <=(!refer_ready||I2C_LNK_OFF||(|I2C_SDA_LOW))?1'b1:DDC_SDA_PAD;
assign sources_scl  =   DDC_SCL_NET?1'bz:1'b0;
assign sources_sda  =   DDC_SDA_NET?1'bz:1'b0;

//filter_miso   filters_scl
//shifter_scl
/*  1M  : eav/sav 0.26us + tF 0.12us*/
/*0.4M  : eav/sav 0.60us + tF 0.3 us*/
/*156.25Mhz = 6.4ns*/
            reg [             phase-1:0]filters_scl[1:0];
            reg [             phase-1:0]filters_sda[1:0];
            reg [                   1:0]I2C_SCL_BUF;
            reg [                   1:0]I2C_SDA_BUF;
always@(posedge refer_clock)  { filters_scl[1],filters_scl[0]}  <= {filters_scl[1],filters_scl[0],DDC_SCL_PAD};
always@(posedge refer_clock)  { filters_sda[1],filters_sda[0]}  <= {filters_sda[1],filters_sda[0],DDC_SDA_PAD};
always@(posedge refer_clock)    I2C_SCL_BUF[0]                      <= (I2C_SCL_BUF[0] ?(|filters_scl[0]):(&filters_scl[0]));
always@(posedge refer_clock)    I2C_SCL_BUF[1]                      <= (I2C_SCL_BUF[1] ?(|filters_scl[1]):(&filters_scl[1]));
always@(posedge refer_clock)    I2C_SDA_BUF[0]                      <= (I2C_SDA_BUF[0] ?(|filters_sda[0]):(&filters_sda[0]));
always@(posedge refer_clock)    I2C_SDA_BUF[1]                      <= (I2C_SDA_BUF[1] ?(|filters_sda[1]):(&filters_sda[1]));
/*
    Start   SCL = 1,SDA =��
    Stop    SCL = 1,SDA =��
*/
            reg                         I2C_END_BIT;/*i2c basic-ctrl    */initial I2C_END_BIT = 0;//
            reg                         I2C_SET_BIT;/*i2c basic-ctrl    */initial I2C_SET_BIT = 0;  
            reg                         I2C_RST_BIT;/*i2c basic-ctrl    */initial I2C_RST_BIT = 1;
            reg                         I2C_SCL_NEG;/*ctl->bit-adr/rtn  */initial I2C_SCL_NEG = 0;
            reg                         I2C_SCL_POS;/*ctl->bit-sda      */initial I2C_SCL_POS = 0;
            reg                         I2C_SDA_BIT;
/*

    ----____----____----____----____----____----____----____----____

    --____[      ][      ][      ][      ][      ][      ][      ]

*/
always@(posedge refer_clock)    I2C_END_BIT     <=(&I2C_SCL_BUF   )&&( I2C_SDA_BUF==2) ? 1'b1 : ((I2C_SCL_BUF==0) ? 1'b0:I2C_END_BIT) ;
always@(posedge refer_clock)    I2C_SET_BIT     <=(&I2C_SCL_BUF   )&&( I2C_SDA_BUF==1) ? 1'b1 : ((I2C_SCL_BUF==0) ? 1'b0:I2C_SET_BIT) ;
always@(posedge refer_clock)    I2C_RST_BIT     <=(&I2C_SCL_BUF   )&&(^I2C_SDA_BUF   ) ? 1'b1 : ((I2C_SCL_BUF==0) ? 1'b0:I2C_RST_BIT) ;

always@(posedge refer_clock)    I2C_SCL_NEG     <=(&I2C_SCL_BUF   )&&( filters_scl[0]==0);
always@(posedge refer_clock)    I2C_SCL_POS     <=(!I2C_SCL_BUF[1])&&(&filters_scl[1]);
always@(posedge refer_clock)    I2C_SDA_BIT     <=  I2C_SDA_BIT ?(|I2C_SDA_BUF):(&I2C_SDA_BUF);


            reg [                  15:0]I2C_DAT_SDI;/*I2C_SCL_POS*/
            reg                         I2C_REF_RDx;/*I2C_SCL_POS@I2C_BIT_ACT*/
            reg                         I2C_REF_WEx;/*I2C_SCL_POS@I2C_BIT_ACT*/
            reg                         I2C_REF_NAK;
            reg [                   7:0]I2C_REF_ADR;/*I2C_SCL_POS@I2C_BIT_ACT*/

            reg                         I2C_DAT_SDO;/*I2C_SCL_NEG*/
            reg                         I2C_BIT_ACT;/*I2C_SCL_NEG*/
            reg [                   2:0]I2C_BIT_ADR;/*I2C_SCL_NEG*/
            reg                         I2C_CTL_ACT;/*I2C_SCL_NEG*/
            reg [                   2:0]I2C_CTL_ADR;/*I2C_SCL_NEG*/
always@(posedge refer_clock)    I2C_DAT_SDI[{I2C_BIT_ACT,I2C_BIT_ADR}]  <=((!I2C_SCL_BUF[1])&&(&filters_scl[1])) ? I2C_SDA_BIT : I2C_DAT_SDI[{I2C_BIT_ACT,I2C_BIT_ADR}];

always@(posedge refer_clock)    I2C_REF_NAK     <=( I2C_SDA_BIT&&I2C_BIT_ACT &&I2C_CTL_ACT);

always@(posedge refer_clock)    I2C_REF_RDx     <= (I2C_BIT_ACT&&I2C_SCL_POS&&(I2C_CTL_ADR==0))             ?( I2C_DAT_SDI[0]) :(I2C_RST_BIT ? 0 : I2C_REF_RDx);
always@(posedge refer_clock)    I2C_REF_WEx     <= (I2C_BIT_ACT&&I2C_SCL_POS&&(I2C_CTL_ADR==0))             ?(!I2C_DAT_SDI[0]) :(I2C_RST_BIT ? 0 : I2C_REF_WEx);
always@(posedge refer_clock)    I2C_REF_ADR     <= (I2C_BIT_ACT&&I2C_SCL_POS&&(I2C_CTL_ADR==1)&&I2C_REF_WEx)?( I2C_DAT_SDI   ) : I2C_REF_ADR + (I2C_BIT_ACT&&I2C_SCL_POS&&(I2C_CTL_ADR!=0));

always@(posedge refer_clock)    I2C_SDA_LOW[0]  <= (I2C_CTL_ADR==0)&&(  I2C_BIT_ACT &&I2C_CTL_ACT);
always@(posedge refer_clock)    I2C_SDA_LOW[1]  <= (I2C_CTL_ADR!=0)&&(  I2C_BIT_ACT &&I2C_CTL_ACT&&I2C_REF_WEx);
always@(posedge refer_clock)    I2C_SDA_LOW[2]  <= (I2C_CTL_ADR!=0)&&((!I2C_BIT_ACT)&&I2C_CTL_ACT&&I2C_REF_RDx&&(!I2C_DAT_SDO));

always@(posedge refer_clock)
if(I2C_RST_BIT)
    begin
    I2C_BIT_ACT             <=  0;
    I2C_BIT_ADR             <=  7;
    I2C_CTL_ACT             <=  1;
    I2C_CTL_ADR             <=  0;
    end
else
if((&I2C_SCL_BUF   )&&( filters_scl[0]==0))/*I2C_SCL_NEG*/
    begin
   {I2C_BIT_ACT,I2C_BIT_ADR}<=  I2C_BIT_ACT ? 7 :   I2C_BIT_ADR - I2C_CTL_ACT;
    I2C_CTL_ACT             <=((I2C_BIT_ADR==1)&&(I2C_CTL_ADR==0)) ? (I2C_DAT_SDI[7:1]==device_id) : I2C_CTL_ACT&&(!I2C_REF_NAK);
    I2C_CTL_ADR             <=  I2C_CTL_ADR + (I2C_BIT_ACT&&(!(&I2C_CTL_ADR)));
    end
    else
    begin
    I2C_BIT_ACT             <=  I2C_BIT_ACT;
    I2C_BIT_ADR             <=  I2C_BIT_ADR;
    I2C_CTL_ACT             <=  I2C_CTL_ACT;
    I2C_CTL_ADR             <=  I2C_CTL_ADR;
    end

            reg [        timeout_bit: 0]I2C_ERR_CNT;//
            reg                         I2C_ERR_DET;
always@(posedge refer_clock)    I2C_ERR_CNT <=(^I2C_SCL_BUF)?0:I2C_ERR_CNT + refer_carry;
always@(posedge refer_clock)    I2C_ERR_DET <= !I2C_RST_BIT&&( I2C_ERR_CNT[timeout_bit]);
always@(posedge refer_clock)    I2C_LNK_OFF <=  I2C_LNK_OFF ?(!I2C_RST_BIT): I2C_ERR_DET;

(* ram_style = edid_type *)reg [7:0] edid_rom[255 :0];
    initial begin  $readmemh(edid_path, edid_rom);end
always@(posedge refer_clock) I2C_DAT_SDO    <=  edid_rom[I2C_REF_ADR][I2C_BIT_ADR];





endmodule