module  pulse_core//MBI5353_distribution//
#(
    parameter   files_pulse     =   "./P02027_WAVE.mem",//
    parameter   expon_logic     =   8,

    parameter   chars_pixel     =   0,
    parameter   chars_initi     =   1,
    parameter   chars_latch     =   2,
    parameter   chars_pause     =   3,

    parameter   width_coefs     =   8,
    parameter   expon_pulse     =   4
)(
//
    input                               pulse_write,
    input       [               31  : 0]pulse_qbyte,//

//
    output  wire[               15  : 0]column_code,
    output  wire                        column_ctrl,//latch
    output  wire                        column_mark,//pause|latch.opcon_rst_d
    
    output  reg                         row_trigger,
    output  reg [               1   : 0]row_control,
  //output  reg [                  7: 0]scale_lines,
  //output  reg                         scale_waves,
  //output  reg                         scale_blank,
  //output  reg                         scale_pause,
  //input                               scale_evens,//
//
    output  reg                         pulse_frame,
    
    input                               refer_frame,//mazes_blank
//
    input                               refer_ready,//gamma_ready
    input                               refer_clock
);

            reg [   expon_pulse-1   : 0]pulse_index;initial pulse_index = 0;//pulse_write
            reg [               2   : 0]pulse_boots;initial pulse_boots = 0;//  
            reg                         pulse_reset;initial pulse_reset = 0;//  
always@(posedge refer_clock)pulse_index <=  pulse_write?pulse_index:pulse_qbyte;
always@(posedge refer_clock)pulse_boots <=  refer_ready?((pulse_write&&(&pulse_index))?{pulse_boots,1'b1}:pulse_boots):0;//
always@(posedge refer_clock)pulse_reset <= (pulse_write&&(&pulse_index))&&(pulse_boots==3);


            wire                        opcon_write;
            wire[   expon_pulse-0   : 0]opcon_coord;
            wire[               31  : 0]opcon_qbyte;

            wire[   expon_pulse-0   : 0]opcon_index[1:0];
            wire[               31  : 0]opcon_catch[1:0];
    lut_ram #(
        .   memory_file             (   files_pulse),
        .   expon_chars             (   32),//18),//9, //512
        .   expon_local             (  (expon_pulse+1)))//6+0+2
    cache_opcon (
        .   write_clock             (   refer_clock), 
        .   write_local             (   opcon_coord),//,
        .   write_syncs             (   opcon_write),//,
        .   write_chars             (   opcon_qbyte),

        .   carry_local             (   opcon_index),//(locate_maze>>1)),
        .   carry_chars             (   opcon_catch));
 //
            wire[               1   : 0]opcon_scrip;
            wire[               15  : 0]opcon_coefs[1:0];
 //
            reg [               1   : 0]opcon_reset;initial opcon_reset = 0;//
            reg [      expon_pulse-1: 0]opcon_now_a;initial opcon_now_a =(-2);//
            reg [      expon_pulse-1: 0]opcon_bak_a;initial opcon_bak_a =(-2);//opcon_bak_a
            wire[               15  : 0]opcon_new_d[4:0];
            wire[   expon_pulse-1   : 0]opcon_new_a[4:0];
            wire[               4   : 0]opcon_run_d;
            reg                         opcon_rst_d;initial opcon_rst_d =  0;// 
            wire[               3   : 0]opcon_while;
            wire[               4   : 0]opcon_frame;


            reg                         zone_enable;
            reg                         zone_detect;
            reg [               3   : 0]zone_target;
            reg [               7   : 0]zone_serial;
            reg [               15  : 0]zone_symbol;

assign  opcon_index[0]  =  {1'b0,opcon_now_a};
assign  opcon_index[1]  =  {1'b1,opcon_now_a};
assign  opcon_scrip     =  (opcon_catch[0]>>16);
assign  opcon_coefs[0]  =   opcon_catch[0];
assign  opcon_coefs[1]  =   opcon_catch[1];

assign  opcon_write     = (!pulse_boots[2]&&pulse_boots[0])?pulse_write:((|opcon_reset)? opcon_reset[0]     :(opcon_run_d[4]||opcon_rst_d));
assign  opcon_coord     = (!pulse_boots[2]&&pulse_boots[0])?pulse_index:((|opcon_reset)?{1'b1,opcon_now_a}  :{1'b1,opcon_now_a});
assign  opcon_qbyte     = (!pulse_boots[2]&&pulse_boots[0])?pulse_qbyte:((|opcon_reset)? opcon_coefs[0]     :(opcon_run_d[4]?opcon_new_d[4]:opcon_coefs[0]));

/*

*/
assign  opcon_frame[0]  =   0;//
assign  opcon_frame[1]  =   0;//
assign  opcon_frame[2]  =  (opcon_coefs[0][expon_logic-1:0]==0);//
assign  opcon_frame[3]  =   1;//
assign  opcon_frame[4]  =   opcon_frame[opcon_scrip];//

            reg                         frame_latch;initial frame_latch =   0;//
(* KEEP="TRUE" *)reg [               1   : 0]frame_blank;initial frame_blank =   0;//
            reg [   expon_pulse-0   : 0]frame_initi;initial frame_initi =   0;//
            wire[   expon_pulse-1   : 0]frame_index;
            reg                         frame_reset;initial frame_reset =   0;//
            reg [               2   : 0]frame_ready;initial frame_ready =   0;//
always@(posedge refer_clock)frame_latch <=  opcon_frame[4]?refer_frame:(frame_blank[0]?refer_frame:frame_latch);
always@(posedge refer_clock)frame_initi <= (pulse_reset||(opcon_frame[4]&&(refer_frame^frame_latch)))?0:(frame_initi+(!frame_initi[expon_pulse]));//
assign  frame_index =(frame_initi-1);//

always@(posedge refer_clock)frame_reset     <= (opcon_reset==2);
always@(posedge refer_clock)frame_blank[0]  <= (opcon_reset==2)?0:(frame_blank[0]||((opcon_scrip==chars_pause)&&(&opcon_coefs[0][expon_logic-1:0])&&(zone_detect)));
always@(posedge refer_clock)frame_blank[1]  <= (opcon_reset==2)?0:(frame_blank[1]||(pulse_reset||(opcon_frame[4]&&(refer_frame^frame_latch))));//
always@(posedge refer_clock)pulse_frame     <= (opcon_reset==2)?frame_latch:pulse_frame;
always@(posedge refer_clock)frame_ready     <=  refer_ready?((opcon_reset==2)?{frame_ready,1'b1}:frame_ready):0;//

/*

*/
always@(posedge refer_clock)opcon_reset <= {opcon_reset,(!frame_initi[expon_pulse])};//opcon_initi opcon_reset
always@(posedge refer_clock)opcon_now_a <=(!frame_initi[expon_pulse])?frame_index:
                                           (opcon_reset[0])?opcon_coefs[0]:
                                            opcon_new_a[4];//
/*
opcon_coefs[1].timer >1 : {(opcon_coefs[1].pulse-0),(opcon_coefs[1].timer-1)}   :
opcon_coefs[1].pulse >0 : {(opcon_coefs[1].pulse-1),(opcon_coefs[0].timer-0)}   :
                          {(opcon_coefs[0].pulse-0),(opcon_coefs[0].timer-0)};


    opcon_coefs[1][15: 8]==0
        opcon_coefs[1][ 7: 1]   ->  0

    opcon_coefs[1][15: 8]>=0
       {opcon_coefs[1][ 7: 1]   ->  0} * opcon_coefs[1][15: 8]


*/
            reg                         opcon_keeps;
            reg [               1   : 0]opcon_pulse;
            reg [               15  : 0]opcon_calcs;
always@(*)
    if( opcon_coefs[0][15: 8]==0)
    begin
        opcon_calcs[15: 8]  <=  opcon_coefs[0][15: 8];
        opcon_calcs[ 7: 0]  <=(|opcon_coefs[1][ 7: 1])?(opcon_coefs[1][ 7: 0]-1):opcon_coefs[0][ 7: 0];
        opcon_keeps         <=(|opcon_coefs[1][ 7: 1]);
        opcon_pulse         <=  0;
    end
    else
        if( opcon_coefs[1][ 7: 1]==0)
        begin
            opcon_calcs[15: 8]  <=(|opcon_coefs[1][15: 9])?(opcon_coefs[1][15: 8]-1):opcon_coefs[0][15: 8];
            opcon_calcs[ 7: 0]  <=  opcon_coefs[0][ 7: 0];
            opcon_keeps         <=(|opcon_coefs[1][15: 9]);
            opcon_pulse         <=  2;
        end
        else
        begin
            opcon_calcs[15: 8]  <=  opcon_coefs[1][15: 8];
            opcon_calcs[ 7: 0]  <=  opcon_coefs[1][ 7: 0]-1;
            opcon_keeps         <=  1;
            opcon_pulse         <=((opcon_scrip==chars_pixel)||(opcon_scrip==chars_initi))?1:0;
        end

assign  opcon_run_d[0]  =   opcon_keeps;//[expon_logic-1:0]
assign  opcon_run_d[1]  =   opcon_keeps;//[expon_logic-1:0]
assign  opcon_run_d[2]  =  (opcon_coefs[0][expon_logic-1:0]==0)?0:(|opcon_coefs[1][expon_logic-1:0]);//
assign  opcon_run_d[3]  =   0;//
assign  opcon_run_d[4]  =   refer_ready?(opcon_run_d[opcon_scrip]):0;//-->

assign  opcon_new_d[0]  =   opcon_calcs;
assign  opcon_new_d[1]  =   opcon_calcs;
assign  opcon_new_d[2]  = (|opcon_coefs[1][15: 1])?(opcon_coefs[1]-1):opcon_coefs[0];//
assign  opcon_new_d[3]  =   opcon_coefs[0];//
assign  opcon_new_d[4]  =   opcon_new_d[opcon_scrip];//--> 

assign  opcon_new_a[0]  =  (opcon_run_d[0]?opcon_now_a:(opcon_now_a+1));//
assign  opcon_new_a[1]  =  (opcon_run_d[1]?opcon_now_a:(opcon_now_a+1));//
assign  opcon_new_a[2]  =  (opcon_coefs[0][expon_logic-1:0]==0)?(opcon_now_a+1):((|opcon_coefs[1][expon_logic-1: 1])?opcon_bak_a:(opcon_now_a+1));//(opcon_run_d[2]?opcon_bak_a:(opcon_now_a+1));//
assign  opcon_new_a[3]  =  (opcon_now_a+1);//
assign  opcon_new_a[4]  =   refer_ready?(opcon_new_a[opcon_scrip]):(-2);//-->

always@(posedge refer_clock)opcon_rst_d <=  refer_ready?opcon_run_d[4]:0;//opcon_rst_d

always@(posedge refer_clock)opcon_bak_a <= (opcon_scrip==chars_pause)?(opcon_now_a+1):opcon_bak_a;//

assign  opcon_while[0]  = (|opcon_coefs[0][expon_logic-1: 0])?0:(opcon_scrip==chars_latch); //next adr+1            zone.+
assign  opcon_while[1]  = (|opcon_coefs[1][expon_logic-1: 1])?0:(opcon_scrip==chars_latch); //next adr+1    mark    zone.+
assign  opcon_while[2]  = (|opcon_coefs[1][expon_logic-1: 1])?(opcon_scrip==chars_latch):0; //back                  zone.0
assign  opcon_while[3]  =  (opcon_scrip==chars_pause);                                      //back          mark    zone.0


            reg                         gray_enable;
            reg [               1   : 0]pluse_shift;
            reg                         pluse_blank;
            reg [               1   : 0]pluse_scrip;
always@(posedge refer_clock)gray_enable     <= (frame_blank==0);
//
always@(posedge refer_clock)pluse_shift <= {pluse_shift,(opcon_pulse==1)};
always@(posedge refer_clock)pluse_blank <=(|frame_blank);
always@(posedge refer_clock)pluse_scrip <={(opcon_scrip==chars_initi),(opcon_scrip==chars_pixel)};
//
always@(posedge refer_clock)zone_enable     <= (opcon_scrip==chars_latch)?zone_enable:((opcon_scrip==chars_initi)||(opcon_scrip==chars_pixel));
always@(posedge refer_clock)zone_symbol     <= (opcon_scrip==chars_pause)?opcon_coefs[0]:zone_symbol;
always@(posedge refer_clock)zone_detect     <= (opcon_scrip==chars_latch)&&zone_enable;//target
always@(posedge refer_clock)zone_target     <=  opcon_while;
always@(posedge refer_clock)zone_serial     <=(|zone_target[3:2])?0:zone_serial+zone_detect;




assign  column_ctrl =   gray_enable&&zone_detect;
assign  column_mark =   gray_enable?(zone_target[3]||zone_target[1]):0;
assign  column_code =   zone_target[3]?zone_symbol:zone_serial;


always@(posedge refer_clock)row_trigger <=  gray_enable&&(pluse_shift==1);//;//
always@(posedge refer_clock)row_control <=  gray_enable?pluse_scrip:0;


endmodule