module  memory_control
#(
    parameter   [   7   :   0]panel_limit[1:0]= {8'H10,8'h10},//1<<expon_ports

    parameter   mem_bit_ctl     =   3,
    parameter   mem_bit_bnk     =   3,
    parameter   mem_bit_row     =   20,
    parameter   mem_bit_col     =   20,
    parameter   mem_bit_dat     =   16,
//
    parameter   mem_cmd_nop     =   7,// COMMAND_NOP
    parameter   mem_cmd_mrs     =   0,// COMMAND_MRS
    parameter   mem_cmd_pre     =   2,// COMMAND_PRE
    parameter   mem_cmd_ref     =   1,// COMMAND_REF
    parameter   mem_cmd_zqc     =   6,// ZQC =   3'b
    parameter   mem_cmd_act     =   3,// COMMAND_ACT
    parameter   mem_cmd_wex     =   4,// COMMAND_WEx
    parameter   mem_cmd_rdx     =   5,// COMMAND_RDx


    parameter   ImageSource     =   "SERDES",//"RGB888"
    parameter   memory_type     =   "SRAM", //dram = 0  "DRAM","sSRAM"
    parameter   bagua_syncs     =   0,
  //parameter   memory_byte     =   0,1,2,4
  //parameter   expon_bytes     =   0,1,2
/*
    DCK 6.25M   V   CLK>10M TTL
    GCK 4M

    144*16*48*"60"*2 = 13,271,040 (6,635,520)

    


     96Mhz  memory_type:SRAM    ,   ImageSource:"RGB888"
        mazes_timer[0]      68(4+64):0.7083us   72(8+64):0.75us
                            96/68*48            96/72*48
        mazes_timer[1]      5(13.55M)           4(16M)     -> Pixel/port
        mazes_timer[2]      1

    125Mhz  memory_type:SRAM    ,   ImageSource:"SERDES"
        mazes_timer[0]      8   phase000{4CK(W)+4CK(W)} ,   phase090{4CK(R)+4CK(R)}
        mazes_timer[1]      120
        mazes_timer[2]      1

            memory_type:DRAM    
        mazes_timer[0]      tRC
        mazes_timer[1]      task
        mazes_timer[2]      Pixel/port


*/
    

    parameter   expon_ports     =   2,
    parameter   expon_burst     =   6, //1920@148.5/((96*64/68)/2)
    
    parameter   expon_hight     =   9, //
    parameter   expon_width     =   9 //

)
(
/*


    64ns    DDR2
        mazes_timer[0]  8   ,   64ns=8*8ns
        mazes_timer[1]  8   ,   512ns
        mazes_timer[2]  n   ,   >ports
*/
    output  reg [   mem_bit_ctl-1   : 0]memory_ctrl,
    output  reg [   mem_bit_bnk-1   : 0]memory_bank,
    output  reg [   mem_bit_row-1   : 0]memory_page,
    output  reg [   mem_bit_col-1   : 0]memory_addr,
    output  reg [   mem_bit_dat-1   : 0]memory_data,

/*
    <-  Video/SERDES
*/
    input                               image_clock,//Video
    input                               image_vsync,//Video
    input                               image_hsync,//Video
    input                               image_esync,//Video SERDES(image_write)
    input       [               23  : 0]image_pixel,//Video SERDES
    input       [               15  : 0]image_hight,//Video SERDES
    input       [               15  : 0]image_width,//Video SERDES
    input                               image_frame,//Video SERDES
    input                               image_syncs,//      SERDES(125Mhz/4)

/*
    <-  CPU/SPI
                        byte[0]         byte[1]         byte[2]         byte[3]         byte[4]         byte[5]
            0x08/0x09   type_manage     group id        command         adr             dat,adr++
            0x07/0x06   type_memory     row[15: 8]      col[15: 8]      row[ 7: 0]      col[ 7: 0]      xyz         dat,col++
            0x05/0x04   type_linear     panel.row       panel.col       row[ 7: 0]      col[ 7: 0]      xyz         dat,xyz++
            0x03/0x02   type_module     command         adr             dat,adr++
        row.7b  col.9b  xyz.5b
                        xyz[4:0]
                        0 ..17  xyz
                        18..19  N/A 
                        20..21  Bagua.pattern[0]
                        22..23  Bagua.pattern[1]
                        24..27  image[0]    SERDES/Video
                        28..31  image[1]    SERDES/Video
*/
    input       [               1   : 0]coeffis_det,//type_memory , type_linear
    input                               coeffis_set,//cpu.w
    input                               coeffis_get,//cpu.r
    input                               coeffis_stb,
    input       [               15  : 0]coeffis_row,//
    input       [               15  : 0]coeffis_col,//
    input       [               7   : 0]coeffis_xyz,//
    input       [               7   : 0]coeffis_bit,//b[6],g[5],r[4],gray[3:0]

    input       [               15  : 0]panel_sizes[1:0],   //  <-  initial_config
/*
    <-  Maze/LED.display
*/
    input                               inside_port,
    input       [               15  : 0]mazes_hight,        //  arsenal(maze_core.loop[1/2/3])
    input       [               15  : 0]mazes_width,        //  arsenal(maze_core.loop[1/2/3])
    input                               mazes_blank,        //  maze_core   ->  
    input       [               7   : 0]mazes_timer[2:0],   //  maze_engine ->  
    input                               mazes_close,        //  maze_engine ->  
    input                               mazes_frame,        //  maze_engine ->  
    input       [               2   : 0]mazes_reset,        //  maze_engine ->  
    input       [               2   : 0]mazes_syncs,        //  maze_engine ->  
/*

*/
    input                               refer_ready,//refer_ready
    input                               refer_clock
);

/*
        Domain buffer  (Video sourse)
*/


            reg                         buffer_swap;
            reg [               3   : 0]buffer_slip;//
            reg                         buffer_sync;//

            reg                         buffer_link;
            reg                         buffer_stop;
            reg [  (expon_width+0)  : 0]buffer_addr;//{limit , expon_width , pixel/word}

            reg [               15  : 0]buffer_high;
            reg                         buffer_over;

            reg [               2   : 0]buffer_task;
always@(posedge refer_clock)buffer_swap <=(!image_frame);//image_esync?image_hight[0]:buffer_swap;
always@(posedge refer_clock)buffer_slip <= {buffer_slip,image_hight[0]};//
always@(posedge refer_clock)buffer_sync <=  buffer_slip[3]^buffer_slip[0];//

always@(posedge refer_clock)buffer_high <=  image_hight-1;

always@(posedge refer_clock)buffer_over <=(|buffer_high[15:expon_hight]);

always@(posedge refer_clock)
    if(!mazes_timer[0][7])
        buffer_task <=  0;
    else
        buffer_task <=(&buffer_task)?buffer_task:buffer_task+1;

always@(posedge refer_clock)
    if( buffer_sync)
    begin
        buffer_addr <=  0;
        buffer_link <=  0;
        buffer_stop <=  0;
    end
    else
    begin
      //buffer_addr <=  mazes_timer[0][expon_burst-1: 0] +((buffer_link&&mazes_syncs[0]&&(!buffer_addr[expon_width+1]))<<(expon_burst));
        buffer_addr[expon_width+0: expon_burst] <=  buffer_addr[expon_width+0: expon_burst]+(buffer_link&&(buffer_task==3));
        buffer_addr[expon_burst-1: 0]           <=  mazes_timer[0][expon_burst-1: 0];
        buffer_link                             <= (buffer_link||(buffer_task==3));
        buffer_stop                             <=((buffer_task==3)&(&buffer_addr[expon_width+0: expon_burst]))?1'b1:buffer_stop;
    end



            wire[               23  : 0]buffer_data;//[2:0];//

    xram#(
        .   expon_chars             (   24),
        .   expon_local             (  (expon_width+1)))
    image_buffer (
        .   write_local             (  {image_width,image_hight[0]}),
        .   write_syncs             (  (image_esync&&(image_width[15:expon_width]==0))),
        .   write_chars             (   image_pixel),
      //.   write_chars             (  {image_width[ 7: 0],image_hight[ 7: 0],image_width[ 7: 0]}),
        .   write_clock             (   image_clock),
        
        .   carry_local             (  {buffer_addr[expon_width+0: expon_burst],mazes_timer[0][expon_burst-1:1],buffer_high[0]}),
        .   carry_chars             (   buffer_data),//{buffer_byte[2],buffer_byte[1],buffer_byte[0]}),
        .   carry_clock             (   refer_clock));

/*
30Mhz/8 = 3.75M
96M/3.75M = 25.6
        16+6    burst.4
        32+6    burst.4
125M/3.75M = 33.3
        timer[0].4 , timer[1].8
        row.    col.    xyz[4:0] byte
                        0 ..17  xyz
                        18..19     
                        20      Bagua.pattern[0]    3bit+4bit   10100
                        21      
                        22      Bagua.pattern[1]    3bit+4bit   10110
                        23      
                        24..27  image[0]    SERDES/Video
                        28..31  image[1]    SERDES/Video

                        xyz[2:0] word
                        0       Bagua.pattern[0]    3bit+4bit
                        1       Bagua.pattern[1]    3bit+4bit
                        2       image[0]    SERDES/Video
                        3       image[1]    SERDES/Video
*/
            reg [               15  : 0]offsets_row[panel_limit[1]-1:0];
            reg [               15  : 0]offsets_col[panel_limit[0]-1:0];
integer v;
always@(*)
begin
    for (v=0;v<panel_limit[1];v=v+1)
    begin
        offsets_row[0]      =   panel_sizes[1];//
        offsets_row[v+1]    =   offsets_row[v+1]+panel_sizes[1];
    end
end
integer h;
always@(*)
begin
    for (h=0;h<panel_limit[0];h=h+1)
    begin
        offsets_col[0]      =   panel_sizes[0];//
        offsets_col[h+1]    =   offsets_col[h+1]+panel_sizes[0];
    end
end

            reg [               15  : 0]linear_addr[1:0];
assign  linear_addr[1]  =   coeffis_row[coeffis_row[8 +: 3]]+coeffis_row[ 7: 0];
assign  linear_addr[0]  =   offsets_col[coeffis_col[8 +: 3]]+coeffis_col[ 7: 0];

            reg                         bagua_frame;
            reg [               1   : 0]bagua_write;
            reg [               1   : 0]bagua_carry;
            reg [               7   : 0]bagua_runes;
            reg [   mem_bit_col-1   : 0]bagua_local;
always@(posedge refer_clock)bagua_frame <=((coeffis_xyz[4:2]==3'b101)&&(!coeffis_xyz[0]))?coeffis_xyz[1]:bagua_frame;//
always@(posedge refer_clock)bagua_write <= (coeffis_set&&coeffis_stb&&coeffis_det[1])?(coeffis_col[15:(expon_width+1)]==0):((mazes_syncs[bagua_syncs])?{bagua_write,1'b0}:bagua_write);
always@(posedge refer_clock)bagua_carry <= (coeffis_get&&coeffis_stb&&coeffis_det[1])?(coeffis_col[15:(expon_width+1)]==0):((mazes_syncs[bagua_syncs])?{bagua_carry,1'b0}:bagua_carry);

always@(posedge refer_clock)bagua_runes <=  coeffis_stb? coeffis_bit:bagua_runes;

always@(posedge refer_clock)bagua_local <=  coeffis_stb?
                                           {coeffis_row,coeffis_col[expon_width-1:0],1'b1,coeffis_col[expon_width],bagua_frame}:bagua_local;

            reg                         pattern_swp;
always@(posedge refer_clock)pattern_swp <= (mazes_syncs[2]&&(mazes_reset==2))?(!bagua_frame):pattern_swp;
/*

        row     swp     col     RGb
        
                row[expon_hight-1:0],[expon_width-1:0],swp,RGb  :9b+9b+1b+1b
                row[expon_hight-1:0],[expon_width-1:0],grp      :8b+9b+3b
*/

            wire[               2   : 0]rgb888_task;//
            wire[   mem_bit_ctl-1   : 0]rgb888_ctrl[7:0];
            wire[   mem_bit_col-1   : 0]rgb888_addr[7:0];
            wire[               15  : 0]rgb888_data[7:0];
/*          
            reg [               15  : 0]rgb888_data[1:0];
always@(posedge refer_clock)rgb888_data[0]  <=(!buffer_addr[0])?:{ buffer_byte[1] ,buffer_byte[0]}:rgb888_data[0];
always@(posedge refer_clock)rgb888_data[1]  <=(!buffer_addr[0])?:{(buffer_addr>>1),buffer_byte[2]}:rgb888_data[1];
*/
assign  rgb888_task     =   buffer_task;
//always@(posedge refer_clock)rgb888_side     <=  buffer_addr[0];
                          //0:  //image.w       64+6
                          //1:  //mazes.r
                          //2:  //mazes.r
                          //3:  //pattern.r
                          //4:  //bagua.r
                          //5:  //bagua.w

assign  rgb888_ctrl[0]  =(  buffer_link&&(!buffer_stop)&&(!buffer_over))?mem_cmd_wex:mem_cmd_nop;//(buffer_stop||buffer_over||(!buffer_link))?mem_cmd_nop:mem_cmd_wex;
assign  rgb888_ctrl[1]  =(  inside_port)?mem_cmd_rdx:mem_cmd_nop;//maze
assign  rgb888_ctrl[2]  =(  inside_port)?mem_cmd_rdx:mem_cmd_nop;//maze
assign  rgb888_ctrl[3]  =(  inside_port)?mem_cmd_rdx:mem_cmd_nop;//pattern
assign  rgb888_ctrl[4]  =( |bagua_carry)?mem_cmd_rdx:mem_cmd_nop;//
assign  rgb888_ctrl[5]  =( |bagua_write)?mem_cmd_wex:mem_cmd_nop;//
assign  rgb888_ctrl[6]  =   0;
assign  rgb888_ctrl[7]  =   0;
//8b,9b,3b
assign  rgb888_addr[0]  =  {buffer_high     ,buffer_addr[expon_width-0:1]   ,1'b0,buffer_addr[0]            ,buffer_swap};//
assign  rgb888_addr[1]  =  {mazes_hight     ,mazes_width[expon_width-1:0]   ,1'b0,1'b0                      ,mazes_frame};//
assign  rgb888_addr[2]  =  {mazes_hight     ,mazes_width[expon_width-1:0]   ,1'b0,1'b1                      ,mazes_frame};//
assign  rgb888_addr[3]  =  {mazes_hight     ,mazes_width[expon_width-1:0]   ,1'b0,mazes_width[expon_width]  ,pattern_swp};//
assign  rgb888_addr[4]  =   bagua_local;//
assign  rgb888_addr[5]  =   bagua_local;//
assign  rgb888_addr[6]  =   0;
assign  rgb888_addr[7]  =   0;

assign  rgb888_data[0]  = (!buffer_addr[0])? buffer_data :{(buffer_addr>>1),buffer_data[23:16]};
//assign  rgb888_data[0]  =  (buffer_link&&(!buffer_stop)&&(!buffer_over))?(buffer_addr[0]?{(buffer_addr>>1),8'h55}:{buffer_high,8'haa}):16'h5a5a;
assign  rgb888_data[1]  =   0;//
assign  rgb888_data[2]  =   0;//
assign  rgb888_data[3]  =   0;//
assign  rgb888_data[4]  =   0;
assign  rgb888_data[5]  =  {bagua_runes,bagua_runes};
assign  rgb888_data[6]  =   0;
assign  rgb888_data[7]  =   0;


always@(posedge refer_clock)memory_ctrl <=  rgb888_ctrl[rgb888_task];
always@(posedge refer_clock)memory_bank <=  0;
always@(posedge refer_clock)memory_page <=  0;
always@(posedge refer_clock)memory_addr <=  rgb888_addr[rgb888_task];
always@(posedge refer_clock)memory_data <=  rgb888_data[rgb888_task];

/*

    SERDES
    

    mazes_timer[0] 0..3
    mazes_timer[1] 0..task

    input                               image_esync,//Video SERDES(image_write)
    input       [               23  : 0]image_pixel,//Video SERDES
    input       [               15  : 0]image_hight,//Video SERDES
    input       [               15  : 0]image_width,//Video SERDES
    input                               image_frame,//Video SERDES
    input                               image_syncs,//      SERDES(125Mhz/4)

    input       [               15  : 0]image_hight,//Video SERDES
    input       [               15  : 0]image_width,//Video SERDES
    parameter   expon_hight     =   9, //
    parameter   expon_width     =   9 //


always@(posedge refer_clock)stream_edge <= {stream_edge,mazes_syncs[0]};//
            reg [               31  : 0]stream_data;//
            reg [   mem_bit_col-1   : 0]stream_addr;//
always@(posedge refer_clock)stream_data <=  mazes_syncs[0]? image_pixel:stream_data;
always@(posedge refer_clock)stream_addr <=  mazes_syncs[0]?{image_hight,image_width[expon_width-1:0],1'b0,1'b0,buffer_swap}://timer[0]

assign  serdes_side     =   
                       (mazes_timer[0]==0)?0:
                       (mazes_timer[0]==1)?1:
                       (mazes_timer[0]==2)?(mazes_timer[1]+2):7;//

assign  serdes_addr[0]  =   stream_addr;
assign  serdes_addr[1]  =   stream_addr|(1<<1);
assign  serdes_addr[2]  =  {mazes_hight ,mazes_width[expon_width-1:0]   ,1'b0,1'b0  ,mazes_frame}|(0<<1);//
assign  serdes_addr[3]  =  {mazes_hight ,mazes_width[expon_width-1:0]   ,1'b0,1'b0  ,mazes_frame}|(1<<1);//
assign  serdes_addr[4]  =   //pattern
assign  serdes_addr[5]  =
assign  serdes_addr[6]  =   0;
assign  serdes_addr[7]  =   0;

            reg [               3   : 0]serdes_task;//

always@(posedge refer_clock)serdes_task <=  serdes_task+image_syncs;
assign  rgb888_task     = (!buffer_edge[0])?0:
                           (buffer_edge==6'b000001)?1
                           (buffer_edge==6'b000011)?2
                           (buffer_edge==6'b000111)?3
                           (buffer_edge==6'b001111)?4
                           (buffer_edge==6'b011111)?5:7:

(image_syncs&&(image_hight[15:expon_hight]==0)&&(image_width[15:expon_width]==0))};//

*/
endmodule

