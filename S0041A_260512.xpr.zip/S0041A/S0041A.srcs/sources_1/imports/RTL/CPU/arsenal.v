//`define toplayer

/*
    CACHE.all
        uSRAM1K     4/22    parts,mazes,chips,lines
        LSRAM18K    1/21    gamma   fonts?


*/
  //`define DISABLE_CORE
  //`define DISABLE_GAMMA_CACHE
  //`define DISABLE_PORTS_CACHE
  //`define DISABLE_MAZES_CACHE
  //`define DISABLE_WAVES_CACHE

  //`define ENABLE_CONFIG_CACHE
module arsenal
 #(
    parameter   files_mzaes     =   "./P160522_MAZE.mem",
//
    parameter   files_loop1     =   "./P160522_CHIP.mem",//files_loop1
    parameter   files_loop2     =   "./P160522_LINE.mem",//files_loop2
    parameter   files_loop3     =   "./P160522_PART.mem",//files_loop3   {port,cascade}
//
    parameter   files_setup     =   "./P160522_BOOT.mem",//
//
    parameter   files_exp01     =   "./ZPOLog32b10a.mem",
//
    parameter   files_fonts     =   "./TXT128_H16x8b.mem",//
//
    parameter   [                4  : 0]gamma_table[15:0] = {5'd30,5'd29,5'd28,5'd27,5'd26,5'd25,5'd24,5'd23,5'd22,5'd21,5'd20,5'd19,5'd18,5'd17,5'd16,5'd10},
//
    parameter   cache_loop1     =   0,//
    parameter   cache_loop2     =   0,//
    parameter   cache_loop3     =   0,//
    
    parameter   cache_mazes     =   0,
    parameter   cache_gamma     =   1,
    parameter   cache_fonts     =   1,
    parameter   cache_setup     =   1,
//
    parameter   tasks_part3     =   0,//
    parameter   tasks_fonts     =   1,
    parameter   tasks_part1     =   2,//
    parameter   tasks_part2     =   3,//
    parameter   tasks_mazes     =   4,
    parameter   tasks_gamma     =   5,
    parameter   tasks_pulse     =   6,//
    parameter   tasks_setup     =   7,
//
    parameter   expon_cores     =   0,//maze.multitask      1<<expon_cores
    parameter   expon_mazes     =   6,//    maze_core       6b+0b   = 6b 
    parameter   expon_index     =   2,//maze_compass.loop
    parameter   [7:0]expon_loops[(1<<expon_index)-1:0]= {8'd4,8'd4,8'd6,8'd0},
    parameter   expon_setup     =   3,//pattern.font        1110,0000,0000,00--
    parameter   expon_pulse     =   4,  //
    parameter   expon_drive     =   6,  //undef
    parameter   expon_unuse     =  10,//
    parameter   expon_exp10     =  10,//gamma               6b+2b = 8b  
    parameter       expon_gamma =   8,//gamma               6b+2b = 8b  
    parameter   expon_fonts     =   9,//pattern.font        1110,0000,0000,00--
// 
    parameter   local_sram1     =   32'h20008000 ,
    parameter   local_sram0     =   32'h20000000 ,

    parameter   local_mazes     =   32'h60000000 ,// 64step x 8core                 0000,0000,0000,00-- 0xxx,xxxx,xxxx,xx-- 13bx4B
    parameter   local_loop1     =   32'h60038000 ,//38000..383FF    1024Byte =  256qByte   (256*chip)
    parameter   local_loop3     =   32'h60038400 ,//38400..387FF    1024Byte =  256qByte   (16*port 16*chain)
    parameter   local_loop2     =   32'h60038800 ,//38800..39BFF     512Byte =  128qByte   (128*line)
    parameter   local_setup     =   32'h60038A00 ,//38A00..38BFF     512Byte =  128qByte
    parameter       local_pulse =   32'h60038C00 ,//
    parameter   local_drive     =   32'h60039000 ,//undef
    
    parameter   local_unuse     =   32'h6003c000 ,//                                1100,0000,0000,00-- 1100,xxxx,xxxx,xx-- 10bx4B
    parameter   local_gamma     =   32'h6003d000 ,//256x32b                         1101,0000,0000,00-- 1101,xxxx,xxxx,xx-- 10bx4B
    parameter   local_fonts     =   32'h6003e000 ,//16384x1bit = 2048x8 = 512x32    1110,0000,0000,00-- 111x,xxxx,xxxx,xx-- 11bx4B
//
    parameter   local_reset     =   local_setup

)(

//rom   256k byte     (0..0x3FFFF)
//ram    64k byte     (0..0x0FFFF)
/*
    maze_core
*/
    input       [    (expon_mazes-1): 0]locate_maze,//[expon_cores-1:0]//
    output  wire[                 17: 0]target_maze,//[expon_cores-1:0]//   task

/*
    offset
    pattern.font
*/

    input                               ports_syncs,

/*
    offset
*/
    input       [               15  : 0]place_loops[3:0],


    output  wire[               15  : 0]warps_hight,
    output  wire[               15  : 0]warps_width,
/*

    pattern.font

*/
    input       [               13  : 0]w08h16_addr,//
    output  wire                        w08h16_font,//
    


/*

    gamma

*/
    input       [                  7: 0]gamma_index,//<-MCU 
    output  wire                        gamma_catch,//
    output  wire[   expon_gamma-1   : 0]gamma_curve,
    output  wire[               32  : 0]gamma_slope,
    output  wire                        gamma_ready,
/*

    opcode.pulse

*/
    output  reg                         pulse_write,
    output  reg [               31  : 0]pulse_qbyte,//behav_pulse
/*

    setup.timer

*/
    output  reg                         setup_write,
    output  reg [               31  : 0]setup_qbyte,//
    output  reg                         setup_ready,
/*

    eNVM

*/
    output  wire                        access_envm,

/*

    eSRAM/eNVM.share
        DISABLE_PORTS_CACHE.(0)
            gamma_ready.(1)                 task(0..1).eROM = off   task(0..1).eRAM = ena
            gamma_ready.(0)                 task(0..1).eROM = ena   task(0..1).eRAM = off
        DISABLE_PORTS_CACHE.(1)
                                            task(0..1).eROM = ena
*/
    input                               mem_ext_sel,//
    output  reg                         mem_ext_rdy,//
    input                               mem_ext_ctl,//
    input                               mem_ext_wex,//
    input       [                  31:0]mem_ext_adr,//
    output  wire[                   1:0]mem_bus_ack,//

    input       [                  31:0]mem_set_dat,
    output  wire[                  31:0]mem_get_dat,

/*

    system
        
*/
    input                               refer_ready,//
    input                               refer_clock
);

/*

    //rom   256k byte     (0..0x3FFFF)
    //ram    64k byte     (0..0x0FFFF)
        
*/
  /*input */wire                        mem_bus_ctl;
  /*input */wire                        mem_bus_wex;
  /*input */wire[                  31:0]mem_bus_adr;
          //wire                        access_envm;//

`ifdef DISABLE_CORE
assign  mem_get_dat =   0;//
assign  mem_bus_ack =   0;//
assign  access_envm =   0;

`else
/*
    SOP
        1.  EDA -> System builder   [M2GL]
        2.  System builder  ->  Device Features [V]eNVM,[V]eSRAM
        3.                      Memories        [mapping/local]
        4.                      Peripherals     [V]direct
        5.                      

*/
assign  access_envm =   1;
    M2GL_HPMS_NONSEQ_BUS32b
    M2GL_HPMS_NONSEQ_BUS32b(
        .   mem_bus_ctl             (   mem_bus_ctl),   //<-
        .   mem_bus_wex             (   mem_bus_wex),   //<-
        .   mem_bus_adr             (   mem_bus_adr),   //<-
        .   mem_bus_ack             (   mem_bus_ack),   //->

        .   mem_set_dat             (   mem_set_dat),   //<-
        .   mem_get_dat             (   mem_get_dat),   //->

        .   refer_ready             (   refer_ready),   //<-
        .   refer_clock             (   refer_clock));  //<-
`endif


            reg                         rom_bus_ctl;
            reg [                 1 : 0]rom_bus_det;
            reg                         rom_bus_stb;
            reg [                 31: 0]rom_bus_dat;
always@(posedge refer_clock)
    if( mem_bus_ack==0)
    begin
        rom_bus_ctl <=(!mem_ext_rdy);
        rom_bus_det <=  0;
    end
    else
    if(|mem_bus_ack)//save = 2t[1]
    begin
        rom_bus_ctl <=  0;
        rom_bus_det <= {rom_bus_det,(mem_bus_ack[1]&&(!mem_ext_rdy))};//
    end
    else
    begin
        rom_bus_ctl <=  rom_bus_ctl;
        rom_bus_det <=  0;//
    end

always@(posedge refer_clock)rom_bus_stb <=((rom_bus_det==2'b01)&&mem_bus_ack[1]);
always@(posedge refer_clock)rom_bus_dat <=((rom_bus_det==2'b00)&&mem_bus_ack[1])?mem_get_dat:rom_bus_dat;

/*

    Polling

*/
            reg [                 17: 0]rom_cnt_adr;//
            wire[                 17: 0]rom_inc_adr =(rom_cnt_adr+4);
            wire[                 17: 0]rom_rst_adr = 0;
            reg                         rom_end_adr;
always@(posedge refer_clock)rom_cnt_adr <=  refer_ready?((rom_bus_det==2'b11)?(rom_end_adr?rom_rst_adr:rom_inc_adr):rom_cnt_adr):local_reset;//
always@(posedge refer_clock)rom_end_adr <=( rom_bus_det==2'b11)&&(rom_cnt_adr[17]&&(!rom_inc_adr[17]));//

 
/*

    Multiple

*/


            reg [                  1: 0]mux_restart;
always@(posedge refer_clock)mux_restart <= (setup_ready&&ports_syncs)?1:(( rom_bus_det==2'b11)?{mux_restart,1'b0}:mux_restart);//




            reg [                  2: 0]mux_adr_sel;
            reg                         mux_adr_jmp;
            reg [                  2: 0]mux_adr_tag;
          //reg [                  2: 0]mux_adr_sel;
            reg [                 15: 0]mux_counter;//expon_gamma expon_setup
always@(posedge refer_clock)
    if( rom_bus_det==2'b11)
    begin
        mux_adr_sel <= (mux_restart==1)?0://(mux_adr_sel+1):
                      ( mux_adr_jmp&&(mux_adr_sel==1))?mux_adr_tag:(mux_adr_sel+1);//
        mux_counter <=  mux_counter+(mux_adr_sel==7);//
        mux_adr_jmp <= (mux_restart==1)?1:((mux_adr_sel==1)?0:mux_adr_jmp);
        mux_adr_tag <= (mux_restart==1)?(((mux_adr_sel==7)||(mux_adr_sel==0))?2:(mux_adr_sel+1)):mux_adr_tag;
                    //(!mux_adr_jmp&&(mux_adr_sel==0))?2:mux_adr_tag;
    end
    else
    begin
        mux_adr_sel <=  mux_adr_sel;//
        mux_counter <=  mux_counter;//
        mux_adr_jmp <=  mux_adr_jmp;//
        mux_adr_tag <=  mux_adr_tag;
    end
    
            wire[               7   : 0]cache_tasks;
assign  cache_tasks[tasks_part3]    =  (access_envm==0)?1:((cache_loop3==0)?0:1);//
assign  cache_tasks[tasks_fonts]    =  (access_envm==0)?1:((cache_fonts==0)?0:1);//   
assign  cache_tasks[tasks_part1]    =  (access_envm==0)?1:((cache_loop1==0)?0:1);//   
assign  cache_tasks[tasks_part2]    =  (access_envm==0)?1:((cache_loop2==0)?0:1);//   
assign  cache_tasks[tasks_mazes]    =  (access_envm==0)?1:((cache_mazes==0)?0:1);//
assign  cache_tasks[tasks_gamma]    =  (access_envm==0)?1:((cache_gamma==0)?0:1);//
assign  cache_tasks[tasks_pulse]    =   0;//
assign  cache_tasks[tasks_setup]    =  (access_envm==0)?1:((cache_setup==0)?0:1);//
    

    
    
            wire[               31  : 0]mux_address[7:0];
//port
assign  mux_address[tasks_part3]    =   cache_tasks[tasks_part3]?local_loop3|(mux_counter[expon_loops[3]-1:0]<<2):local_loop3|(place_loops[3][expon_loops[3]-1:0]<<2);//(place_loops[3]<<2);
assign  mux_address[tasks_fonts]    =   cache_tasks[tasks_fonts]?local_fonts|(mux_counter[expon_fonts   -1:0]<<2):local_fonts|(w08h16_addr  <<2);//(w08h16_addr<<2);
assign  mux_address[tasks_part1]    =   cache_tasks[tasks_part1]?local_loop1|(mux_counter[expon_loops[1]-1:0]<<2):local_loop1|(place_loops[1][expon_loops[1]-1:0]<<2);//(place_loops[1]<<2);
assign  mux_address[tasks_part2]    =   cache_tasks[tasks_part2]?local_loop2|(mux_counter[expon_loops[2]-1:0]<<2):local_loop2|(place_loops[2][expon_loops[2]-1:0]<<2);//(place_loops[2]<<2);
//maze
assign  mux_address[tasks_mazes]    =   cache_tasks[tasks_mazes]?local_mazes|(mux_counter[expon_mazes-1:0]<<2):local_mazes|(locate_maze<<2);//(locate_maze<<2);//

assign  mux_address[tasks_gamma]    =   local_gamma|(mux_counter[expon_gamma-1:0]<<(12-expon_gamma));//
assign  mux_address[tasks_pulse]    =   local_pulse|(mux_counter[expon_pulse-1:0]<<2);//(
assign  mux_address[tasks_setup]    =   local_setup|(mux_counter[expon_setup-1:0]<<2);//







            wire[                 31: 0]rom_bus_adr;
//assign  rom_bus_adr =  {12'h600,2'b00,rom_cnt_adr};//


assign  rom_bus_adr =   mux_address[mux_adr_sel];//

/*
    
    eSRAM/eNVM.share
        arbiter
        
*/
            reg                         envm_stable;
//always@(posedge refer_clock)mem_ext_rdy <=  refer_ready?(rom_end_adr?mem_ext_sel:mem_ext_rdy):0;
always@(posedge refer_clock)mem_ext_rdy <= (rom_bus_det==2'b11)?(refer_ready&&mem_ext_sel&&gamma_ready):(mem_ext_rdy&&mem_ext_sel);//(rom_end_adr?mem_ext_sel:mem_ext_rdy):0;


//assign  bus_set_ack =   mem_ext_rdy?mem_set_ack:0;//
//assign  bus_get_dat =   mem_get_dat;//
assign  mem_ext_ack =   mem_ext_rdy?mem_bus_ack:0;//

assign  mem_bus_ctl =   mem_ext_rdy?mem_ext_ctl:rom_bus_ctl;
assign  mem_bus_wex =   mem_ext_rdy?mem_ext_wex:0;
assign  mem_bus_adr =   mem_ext_rdy?mem_ext_adr:rom_bus_adr;
//assign  mem_set_dat =   bus_set_dat;

//assign  config_done =   access_envm?refer_ready setup_ready gamma_ready:0;//
//assign  config_ctrl =   rom_bus_stb mux_adr_sel 
//assign  config_data =   

  //output  reg                         config_done,
  //output  reg                         config_ctrl,
  //output  reg [               31  : 0]config_data,

/*
    
    eNVM.local
        demux
        
*/
            reg                         demux_mazes;//<-
          //reg                         demux_warps;//<-
            reg                         demux_loop1;//<-chips
            reg                         demux_loop3;//<-parts
            reg                         demux_loop2;//<-lines
          //reg                         demux_ports;//<-
            reg                         demux_pulse;//<-
//
            reg                         demux_unuse;//<-
            reg                         demux_gamma;//<-
            reg                         demux_fonts;//<-

            reg                         demux_setup;//<-

always@(posedge refer_clock)demux_mazes <= (rom_bus_adr>>(expon_mazes+expon_cores+2))==(local_mazes>>(expon_mazes+expon_cores+2));//

always@(posedge refer_clock)demux_loop1 <= (rom_bus_adr>>(expon_loops[1]+2))==(local_loop1>>(expon_loops[1]+2));//
always@(posedge refer_clock)demux_loop3 <= (rom_bus_adr>>(expon_loops[3]+2))==(local_loop3>>(expon_loops[3]+2));//
always@(posedge refer_clock)demux_loop2 <= (rom_bus_adr>>(expon_loops[2]+2))==(local_loop2>>(expon_loops[2]+2));//

always@(posedge refer_clock)demux_pulse <= (rom_bus_adr>>(expon_pulse+2))==(local_pulse>>(expon_pulse+2));//


always@(posedge refer_clock)demux_unuse <= (rom_bus_adr>>(expon_unuse+2))==(local_unuse>>(expon_unuse+2));//

always@(posedge refer_clock)demux_gamma <= (rom_bus_adr>>(expon_exp10+2))==(local_gamma>>(expon_exp10+2));//

always@(posedge refer_clock)demux_fonts <= (rom_bus_adr>>(expon_fonts+2))==(local_fonts>>(expon_fonts+2));//

always@(posedge refer_clock)demux_setup <= (rom_bus_adr>>(expon_setup+2))==(local_setup>>(expon_setup+2));//local_fonts(local_setup)

//suite
/*

*/

            reg [                 31: 0]latch_mazes;
            wire[                 31: 0]buffer_maze;
always@(posedge refer_clock)latch_mazes     <= (rom_bus_stb&&(demux_mazes))?rom_bus_dat:latch_mazes;
    xram #(
        .   memory_file             (   files_mzaes),//memory_file = "./P160522_18b.mem.mem",
        .   expon_chars             (   32),//18),//9, //512
        .   expon_local             (  (expon_mazes+expon_cores)))
    buffer_mazes (
        .   write_clock             (   refer_clock), 
        .   write_local             (  (rom_bus_adr>>2)),//,
        .   write_syncs             (   rom_bus_stb&&(demux_mazes)),//,
        .   write_chars             (   rom_bus_dat),
        .   carry_clock             (   refer_clock),
        .   carry_local             (   locate_maze),//(locate_maze>>1)),   locate_step
        .   carry_chars             (   buffer_maze));// target_maze));

assign  target_maze =   cache_tasks[tasks_mazes]?buffer_maze:latch_mazes;//



/*


*/

always@(posedge refer_clock)pulse_qbyte <= (rom_bus_stb&&(local_pulse))?rom_bus_dat:(rom_bus_adr>>2);//
always@(posedge refer_clock)pulse_write <= (rom_bus_stb&&(local_pulse));//&&config_done&&refer_ready;//?rom_bus_dat:setup_value;//


/*
    

*/



            wire[                 15: 0]redirection[1:0][3:0];

            reg [                 15: 0]latch_loops[3:0];//latch_loops

always@(posedge refer_clock)latch_loops[1]  <= (rom_bus_stb&&(demux_loop1))?rom_bus_dat:latch_loops[1];
always@(posedge refer_clock)latch_loops[3]  <= (rom_bus_stb&&(demux_loop3))?rom_bus_dat:latch_loops[3];
always@(posedge refer_clock)latch_loops[2]  <= (rom_bus_stb&&(demux_loop2))?rom_bus_dat:latch_loops[2];
assign  redirection[0][1] = latch_loops[1];//
assign  redirection[0][2] = latch_loops[3];//
assign  redirection[0][3] = latch_loops[2];//

    xram #(
        .   memory_file             (   files_loop1),//files_loop1),
        .   expon_chars             (   32),//16),//9, //512
        .   expon_local             (   expon_loops[1]))//6+0+2
    buffer_loop1 (
        .   write_clock             (   refer_clock), 
        .   write_local             (  (rom_bus_adr>>2)),//,
        .   write_syncs             (   rom_bus_stb&&(demux_loop1)),//,
        .   write_chars             (   rom_bus_dat),
        .   carry_clock             (   refer_clock),
        .   carry_local             (   place_loops[1][expon_loops[1]-1:0]),//(locate_maze>>1)),
        .   carry_chars             (   redirection[1][1]));

    xram #(
        .   memory_file             (   files_loop3),//files_loop2),
        .   expon_chars             (   32),//16),//9, //512
        .   expon_local             (   expon_loops[3]))//6+0+2
    buffer_loop3 (
        .   write_clock             (   refer_clock), 
        .   write_local             (  (rom_bus_adr>>2)),//,
        .   write_syncs             (   rom_bus_stb&&(demux_loop3)),//,
        .   write_chars             (   rom_bus_dat),
        .   carry_clock             (   refer_clock),
        .   carry_local             (   place_loops[3][expon_loops[3]-1:0]),//(locate_maze>>1)),
        .   carry_chars             (   redirection[1][2]));

    xram #(
        .   memory_file             (   files_loop2),//files_loop3),
        .   expon_chars             (   32),//16),//9, //512
        .   expon_local             (   expon_loops[2]))//6+0+2
    buffer_loop2 (
        .   write_clock             (   refer_clock), 
        .   write_local             (  (rom_bus_adr>>2)),//,
        .   write_syncs             (   rom_bus_stb&&(demux_loop2)),//,
        .   write_chars             (   rom_bus_dat),
        .   carry_clock             (   refer_clock),
        .   carry_local             (   place_loops[2][expon_loops[2]-1:0]),//(locate_maze>>1)),
        .   carry_chars             (   redirection[1][3]));

            wire[                 15: 0]coordinates[1:0];
assign  coordinates[1]  =  redirection[cache_tasks[tasks_part3]][3][15: 8]+redirection[cache_tasks[tasks_part2]][2][15: 8];//+redirection[0][ 7: 0];
assign  coordinates[0]  =  redirection[cache_tasks[tasks_part3]][3][ 7: 0]+redirection[cache_tasks[tasks_part2]][2][ 7: 0];//

assign  warps_hight     =  redirection[cache_tasks[tasks_part1]][1][15: 8]+coordinates[1];//
assign  warps_width     =  redirection[cache_tasks[tasks_part1]][1][ 7: 0]+coordinates[0];//




/*

    gamma
        125MHz/{ 8b,5b} = 8ns* 8192 = 65,536ns
        125MHz/{10b,5b} = 8ns*32768 =262,144ns
        
         96MHz/{ 8b,5b} =             85,333ns
*/
    log_log_plot#(  //
        .   gamma_table             (   gamma_table),
        .   files_exp01             (   files_exp01),
        .   expon_exp10             (   expon_exp10),
        .   expon_gamma             (   expon_gamma))
    log_log_plot(
        .   gamma_catch             (   gamma_catch),//gamma_catch
        .   gamma_curve             (   gamma_curve),//gamma_curve
        .   gamma_slope             (   gamma_slope),//gamma_slope  
        .   gamma_ready             (   gamma_ready),//gamma_ready
        .   gamma_index             (   gamma_index),
        .   cache_tasks             (   cache_tasks[tasks_gamma]),  //
        .   ahb_bus_ena             (   demux_gamma),               //envm
        .   ahb_bus_stb             (   rom_bus_stb),               //envm
        .   ahb_bus_adr             (   rom_bus_adr),               //envm
        .   ahb_bus_dat             (   rom_bus_dat),               //envm
        .   refer_clock             (   refer_clock));


/*

    pattern.font
        font.qByte
            {8W,8W,8W,8W}
            
assign  w08h16_addr[13:12]  =   texts_ascii[6:5];   //4word.h
assign  w08h16_addr[11: 8]  =   texts_hight;        //h16
assign  w08h16_addr[ 7: 3]  =   texts_ascii[4:0];   //32word.w
assign  w08h16_addr[ 2: 0]  = (~texts_width);       //w8
*/


            reg [                 31: 0]latch_fonts;
            wire[                 31: 0]table_fonts;
always@(posedge refer_clock)latch_fonts     <= (rom_bus_stb&&(demux_fonts))?rom_bus_dat:latch_fonts;
    xram #(//16384x1bit = 2048x8 = 1024x16 = 512x32
        .   memory_file             (   files_fonts),
        .   expon_chars             (   32),//9, //512
        .   expon_local             (   expon_fonts))//9, //512
    buffer_fonts (
        .   write_clock             (   refer_clock), 
        .   write_local             (  (rom_bus_adr>>2)),//,
        .   write_syncs             (   rom_bus_stb&&(demux_fonts)),//,
        .   write_chars             (   rom_bus_dat),
        .   carry_clock             (   refer_clock),
        .   carry_local             (   w08h16_addr[13:5]),//(w08h16_addr>>5)),//w08h16_addr[13:0],
        .   carry_chars             (   table_fonts));

assign  w08h16_font =   cache_tasks[tasks_fonts]?
                        latch_fonts[{w08h16_addr[4:3],(~w08h16_addr[2:0])}]://
                        table_fonts[{w08h16_addr[4:3],(~w08h16_addr[2:0])}];//





/*

    setup.timer


    output  reg                         timer_ready,
    output  reg                         timer_syncs,
    output  reg [               31  : 0]timer_value,
*/

          //reg                         timer_check;//
          //reg [                 31: 0]timer_value;
            reg [                 31: 0]timer_check;//
            reg                         timer_match;//
            reg                         timer_syncs;//
          //reg                         timer_ready;//expon_setup
//always@(posedge refer_clock)timer_value <= (rom_bus_stb&&(demux_setup)&&( rom_bus_adr[expon_setup-1:0]==0))?rom_bus_dat:timer_value;
always@(posedge refer_clock)timer_check <= (rom_bus_stb&&(demux_setup)&&( rom_bus_adr[2 +: expon_setup]==1))?rom_bus_dat:timer_check;//
always@(posedge refer_clock)timer_match <=((rom_bus_dat^(~timer_check))==0);//
always@(posedge refer_clock)timer_syncs <= (rom_bus_stb&&(demux_setup)&&( rom_bus_adr[2 +: expon_setup]==0));//





          //reg [   expon_setup+1   : 0]config_addr;//
          //wire[               31  : 0]config_code;

            reg [   expon_setup+1   : 0]setup_scans;//            
          //reg [               31  : 0]latch_setup;
            wire[               31  : 0]table_setup;
//always@(posedge refer_clock)latch_setup     <= (rom_bus_stb&&(demux_setup))?rom_bus_dat:latch_setup;
    xram #(//16384x1bit = 2048x8 = 1024x16 = 512x32
        .   memory_file             (   files_setup),
        .   expon_chars             (   32),//9, //512
        .   expon_local             (   expon_setup))//9, //512
    buffer_config (
        .   write_clock             (   refer_clock), 
        .   write_local             (  (rom_bus_adr>>2)),//,
        .   write_syncs             (   rom_bus_stb&&(demux_setup)),//,
        .   write_chars             (   rom_bus_dat),
        .   carry_clock             (   refer_clock),
        .   carry_local             (  (setup_scans>>2)),//(w08h16_addr>>5)),//w08h16_addr[13:0],
        .   carry_chars             (   table_setup));

always@(posedge refer_clock)setup_scans <=  setup_scans+1;//(
always@(posedge refer_clock)setup_qbyte <=  cache_tasks[tasks_setup]?((setup_scans[1:0]==2)?table_setup:(setup_scans>>2))   :((rom_bus_stb&&demux_setup)?rom_bus_dat:(rom_bus_adr>>2));//
always@(posedge refer_clock)setup_write <=  cache_tasks[tasks_setup]? (setup_scans[1:0]==2)                                 : (rom_bus_stb&&demux_setup&&setup_ready);

always@(posedge refer_clock)setup_ready <=  refer_ready?(timer_syncs?timer_match:setup_ready):0;//();

//always@(posedge refer_clock)config_addr <=  config_addr+1;//
//always@(posedge refer_clock)config_data <= (config_addr[1:0]==2)?config_code:(config_addr>>2);//
//always@(posedge refer_clock)config_ctrl <= (config_addr[1:0]==2);










//always@(posedge refer_clock)config_addr <=  rom_bus_adr;//
          //reg [                 15: 0]panel_hight;
          //reg [                 15: 0]panel_width;
          //reg [                  7: 0]ports_limit;
          //reg [                  7: 0]chain_limit;
          //reg [                 31: 0]parts_setup;
          //reg [                  7: 0]guide_chips;
          //reg [                  7: 0]guide_chain;
          //reg [                  7: 0]guide_lines;


endmodule