module M2GL_HPMS_NONSEQ_BUS32b
 #(
    parameter   local_sram1     =   32'h20008000 ,
    parameter   local_sram0     =   32'h20000000 ,
    parameter   local_mazes     =   32'h60000000 ,//mapping_bit
    parameter   local_gamma     =   32'h6003d000 ,//256x32
    parameter   local_fonts     =   32'h6003e000 ,//16384x1bit = 2048x8 = 512x32
//
    parameter   local_reset     =   local_gamma
)(

//rom   256k byte     (0..0x3FFFF)
//ram    64k byte     (0..0x0FFFF)


    input                               mem_bus_ctl,
    input                               mem_bus_wex,
    input       [                  31:0]mem_bus_adr,
    output  wire[                   1:0]mem_bus_ack,
//
    input       [                  31:0]mem_set_dat,
  //output  wire                        mem_set_ack,
    output  wire[                  31:0]mem_get_dat,

//
    input                               refer_ready,//
    input                               refer_clock
);
                                                  //initial power_ready = 0;////
            wire[                  31:0]AMBA_HADDR_;//AMBA<-
            wire                        AMBA_MSLOCK;//AMBA<-
            wire                        AMBAmHREADY;//AMBA<-
            wire                        AMBA_HSEL__;//AMBA<-
            wire[                   1:0]AMBA_HSIZE_;//AMBA<-//chars_expon;//指示当前传输的大小: 000(8bit),001(16bit),010(32bit),011(64bit)…
            wire[                   1:0]AMBA_HTRANS;//AMBA<-
            wire[                  63:0]AMBA_HWDATA;//AMBA<-//
            wire                        AMBA_HWRITE;//AMBA<-
            //
            wire[                  31:0]AMBA_HRDATA;//AMBA->
            wire                        AMBAsHREADY;//AMBA->
            wire                        AMBA_HRESP_;//AMBA->
            wire                        COMM_BLKINT;//AMBA->
            wire[                  15:0]MSS_INT_M2F;//AMBA->
            wire                        FPGA_RESETn;//AMBA->
    M2GL_HPMS
    AHB_MEM(
        // Inputs
        .   MCCC_CLK_BASE           (   refer_clock ),
        .   MCCC_CLK_BASE_PLL_LOCK  (   refer_ready),
        .   MSS_RESET_N_F2M         (   1'b1),
        .   M3_RESET_N              (   1'b0),

//  
        .   FIC_0_AHB_S_HREADY      (   AMBAmHREADY ),//AMBAmHREADY ),
        .   FIC_0_AHB_S_HWRITE      (   AMBA_HWRITE ),// 0
        .   FIC_0_AHB_S_HMASTLOCK   (   AMBA_MSLOCK ),// 0
        .   FIC_0_AHB_S_HSEL        (   AMBA_HSEL__ ),
        .   FIC_0_AHB_S_HADDR       (   AMBA_HADDR_ ),
        .   FIC_0_AHB_S_HWDATA      (   AMBA_HWDATA ),//0
        .   FIC_0_AHB_S_HSIZE       (   AMBA_HSIZE_ ),//2
        .   FIC_0_AHB_S_HTRANS      (   AMBA_HTRANS ),//2
//  
        .   FIC_2_APB_M_PREADY      (   1'b1 ), // tied to 1'b1 from definition
        .   FIC_2_APB_M_PSLVERR     (   1'b0 ), // tied to 1'b0 from definition
        .   FIC_2_APB_M_PRDATA      (   0 ), // tied to 32'h00000000 from definition
        // Outputs  
        .   FIC_0_AHB_S_HRESP       (   AMBA_HRESP_ ),
        .   FIC_0_AHB_S_HREADYOUT   (   AMBAsHREADY ),
        .   FIC_0_AHB_S_HRDATA      (   mem_get_dat),//AMBA_HRDATA ),
//  
      //.   FIC_2_APB_M_PRESET_N    (   APB_PRESETn ),
      //.   FIC_2_APB_M_PCLK        (  ),.   FIC_2_APB_M_PWRITE          (  ),
      //.   FIC_2_APB_M_PENABLE     (  ),.   FIC_2_APB_M_PSEL            (  ),
      //.   FIC_2_APB_M_PADDR       (  ),.   FIC_2_APB_M_PWDATA          (  ),
//  
        .   M3_NMI                  (  ),
        .   COMM_BLK_INT            (   COMM_BLKINT ), //->0
        .   MSS_RESET_N_M2F         (   FPGA_RESETn ), //->0
        .   MSS_INT_M2F             (   MSS_INT_M2F ));//->0

            reg                         AHB_MEM_RDY;//
always@(posedge refer_clock)AHB_MEM_RDY <=  refer_ready?FPGA_RESETn:0;

//assign  AMBAmHREADY =   AHB_MEM_RDY;//refer_ready
assign  AMBA_MSLOCK =   AHB_MEM_RDY;
//assign  AMBA_HSEL__ =   AHB_MEM_RDY;//AMBA_HRESP_
/*
          //reg                         mem_stb_seq;
          //reg                         mem_wex_seq;
          //reg                         mem_get_reg;
          //reg                         mem_set_reg;
          //reg [                  1: 0]mem_get_seq;
          //reg [                  1: 0]mem_set_seq;
always@(posedge refer_clock)
    if(!AHB_MEM_RDY)
    begin
      //mem_stb_seq <=  0;
      //mem_wex_seq <=  0;
      //mem_get_reg <=  0;
      //mem_set_reg <=  0;
      //mem_set_seq <=  0;
      //mem_set_ack <=  0;
        AMBA_HWDATA <=  AMBA_HWDATA;//
      //mem_get_seq <=  0;//
        mem_get_dat <=  mem_get_dat;
      //mem_bus_ack <=  0;
    end
    else
        if( AMBAsHREADY&&(!AMBA_HRESP_))
        begin
          //mem_stb_seq <=  mem_bus_ctl;
          //mem_wex_seq <=  mem_bus_wex;
          //mem_set_ack <=( mem_bus_wex&&mem_bus_ctl);//
            AMBA_HWDATA <=( mem_bus_wex&&mem_bus_ctl)?mem_set_dat:AMBA_HWDATA;
          //mem_bus_ack <=(!mem_bus_wex&&mem_bus_ctl); 
            mem_get_dat <=(!mem_bus_wex&&mem_bus_ctl)?AMBA_HRDATA:mem_get_dat;
          //mem_set_seq <= {mem_set_seq,( mem_bus_wex&&mem_bus_ctl)};
          //mem_set_ack <= (mem_set_seq==2);//
          //mem_get_seq <= {mem_get_seq,(!mem_bus_wex&&mem_bus_ctl)};//
          //mem_get_dat <= (mem_get_seq==2)?AMBA_HRDATA:mem_get_dat;
          //mem_bus_ack <= (mem_get_seq==2);//==1 ,testbench:glitch
        end
        else
        begin
          //mem_stb_seq <=  mem_stb_seq;
          //mem_wex_seq <=  mem_wex_seq;
          //mem_set_seq <=  mem_set_seq;
          //mem_set_ack <=  0;//
            AMBA_HWDATA <=  AMBA_HWDATA;//
          //mem_get_seq <=  mem_get_seq;//
            mem_get_dat <=  mem_get_dat;
          //mem_bus_ack <=  0;
        end
*/
//assign  mem_set_ack =  (AMBAsHREADY&&(!AMBA_HRESP_)&&(mem_set_seq==2));
//assign  mem_bus_ack =  (AMBAsHREADY&&(!AMBA_HRESP_)&&(mem_get_seq==2));
assign  AMBA_HSIZE_ =   2;//
assign  AMBA_HWRITE = ( AMBAsHREADY&&(!AMBA_HRESP_)&&mem_bus_ctl&&mem_bus_wex);
assign  AMBA_HTRANS = ( AMBAsHREADY&&(!AMBA_HRESP_)&&mem_bus_ctl)?2:0;//NONSEQ
assign  AMBA_HADDR_ =  {mem_bus_adr[31: 2],2'b00};

assign  AMBA_HWDATA =   mem_set_dat|0;//

//assign  mem_set_ack = ((AMBAsHREADY&&(!AMBA_HRESP_))&&( AMBA_HWRITE)&&mem_bus_ctl);//

            reg [                   1:0]mem_ack_buf;
always@(posedge refer_clock)
    if( AMBAsHREADY&&(!AMBA_HRESP_)&&mem_bus_ctl)
        mem_ack_buf <=  1;
    else
        if( AMBAsHREADY&&(!AMBA_HRESP_))
            mem_ack_buf <= {mem_ack_buf,1'b0};
        else
            mem_ack_buf <=  0;

assign  AMBAmHREADY =   AHB_MEM_RDY;//&&mem_bus_ctl;//refer_ready

assign  AMBA_HSEL__ =   AHB_MEM_RDY;//&&mem_bus_ctl;//AMBA_HRESP_

assign  mem_bus_ack     =  {(|mem_ack_buf),((AMBAsHREADY&&(!AMBA_HRESP_))&&mem_bus_ctl)};//

//always@(posedge refer_clock)mem_get_dat <=  mem_ack_buf?AMBA_HRDATA:mem_get_dat;

//always@(posedge refer_clock)mem_get_dat <=  AMBA_HRDATA;//mem_ack_buf?AMBA_HRDATA:mem_get_dat;

//always@(posedge refer_clock)AMBA_HWDATA <=( AMBAsHREADY&&(!AMBA_HRESP_)&&mem_bus_ctl&&mem_bus_wex)?mem_set_dat:AMBA_HWDATA;
//always@(posedge refer_clock)mem_get_dat <=( AMBAsHREADY&&(!AMBA_HRESP_)&&mem_bus_ctl&&mem_bus_wex)?mem_set_dat:mem_get_dat;



endmodule