  //`define DISABLE_CORE
  //`define DISABLE_GAMMA_CACHE
  //`define DISABLE_GAMMA_CACHE

module XPU//behavior//Firmware
 #(
//reset/initial_config 
    parameter   [               7   : 0]setup_speed[3:0]=  { 8'h01,8'h01,8'h49,8'h08},  //{(reserve),engine.in ,engine.in ,engine.in }
    parameter   [               7   : 0]setup_shift[3:0]=  { 8'h00,8'h00,8'h00,8'h00},  //{(reserve),engine.out,engine.out,engine.out}  limit_angle
    parameter   timer_ports     =   2,
    parameter   loops_chain     =   3,
    parameter   [               7   : 0]matrix_part[(1<<expon_index)-1:0]= {((loops_chain==3)?1:0),((loops_chain==2)?1:0),((loops_chain==1)?1:0),((loops_chain==0)?1:0)},
    parameter   expon_ports     =   3,
//
    parameter   [                4  : 0]gamma_table[15:0] = {5'd30,5'd29,5'd28,5'd27,5'd26,5'd25,5'd24,5'd23,5'd22,5'd21,5'd20,5'd19,5'd18,5'd17,5'd16,5'd10},
//
    parameter   chars_pixel     =   0,
    parameter   chars_initi     =   1,
    parameter   chars_latch     =   2,
    parameter   chars_pause     =   3,
//arsenal
    parameter   files_mzaes     =   "./P160522_MAZE.mem",
    parameter   files_loop1     =   "./P160522_CHIP.mem",//files_loop1
    parameter   files_loop3     =   "./P160522_PART.mem",//files_loop3   {port,cascade}
    parameter   files_loop2     =   "./P160522_LINE.mem",//files_loop2
    parameter   files_pulse     =   "./P160522_WAVE.mem",//
    parameter   files_setup     =   "./P160522_BOOT.mem",//
    parameter   files_exp01     =   "./ZPOLog32b10a.mem",
    parameter   files_fonts     =   "./TXT128_H16x8b.mem",//
//arsenal
    parameter   cache_loop3     =   0,//
    parameter   cache_loop1     =   0,//
    parameter   cache_loop2     =   0,//
    parameter   cache_mazes     =   0,
    parameter   cache_gamma     =   1,
    parameter   cache_fonts     =   1,
    parameter   cache_setup     =   1,
//arsenal
    parameter   tasks_part3     =   0,//
    parameter   tasks_fonts     =   1,
    parameter   tasks_part1     =   2,//
    parameter   tasks_part2     =   3,//
    parameter   tasks_mazes     =   4,
    parameter   tasks_gamma     =   5,
    parameter   tasks_pulse     =   6,//
    parameter   tasks_setup     =   7,
//arsenal
    parameter   expon_cores     =   0,//maze.multitask      1<<expon_cores
    parameter   expon_mazes     =   6,//    maze_core       6b+0b   = 6b 
    parameter   expon_index     =   2,//maze_compass.loop
    parameter   [7:0]expon_loops[(1<<expon_index)-1:0]= {8'd4,8'd4,8'd6,8'd9},
    parameter   expon_setup     =   3,//pattern.font        1110,0000,0000,00--
    parameter   expon_pulse     =   4,  //
    parameter   expon_exp10     =  10,//gamma               6b+2b = 8b  
    parameter   expon_gamma     =   8,//gamma               6b+2b = 8b  
    parameter   expon_fonts     =   9,//pattern.font        1110,0000,0000,00--
//demux
    parameter   demux_phase     =   1,
    parameter   [7:0]expon_field[1:0]=   { 8'h02, 8'h02},
    parameter   expon_steps     =   4,//demux,   expon_steps
//
    parameter   gray_syncer     =   0,
//
    parameter   frequencies     =   125000000,
    parameter   frame_rates     =   60

)(


  //input       [   expon_cores-1   : 0]core_select,        //
    input       [               7   : 0]frame_tasks,
//arsenal.setup
    output  wire                        access_envm,
    output  wire                        setup_ready,
    output  wire                        setup_write,
    output  wire[               31  : 0]setup_qbyte,
//arsenal.gamma
    input       [               7   : 0]gamma_index,        //  <-MCU
    output  reg                         gamma_catch,        //  ->color
    output  wire[   expon_gamma-1   : 0]gamma_curve,        //  ->color
    output  wire[               32  : 0]gamma_slope,        //  ->color
    output  wire                        gamma_ready,        //  check exp10
//arsenal.font
    input       [               13  : 0]w08h16_addr,        //  <-pattern(  texts_ascii[6:5],texts_hight[3:0],   texts_ascii[4:0],~texts_width[2:0])
    output  wire                        w08h16_font,        //  ->pattern(bit)
//
    output  wire                        inside_port,
    output  wire[    (expon_ports-1): 0]place_ports,
    output  wire[               15  : 0]place_loops[3:0],        //
//
    output  wire                        demux_bidir,
    output  wire                        demux_break,
    output  wire                        demux_latch,
    output  wire[    (expon_steps+7): 0]demux_cycle,//


//wave
    output  wire[               15  : 0]column_code,
    output  wire                        column_ctrl,
    output  wire                        column_mark,
    output  wire                        row_trigger,
    output  wire[               1   : 0]row_control,


//arsenal.warp + maze
    output  wire[               15  : 0]mazes_hight,        //  arsenal(maze_core.loop[1/2/3])
    output  wire[               15  : 0]mazes_width,        //  arsenal(maze_core.loop[1/2/3])
//
  //output  wire[                1  : 0]mazes_bound,
//maze
    output  wire[               17  : 0]mazes_chars,        //  maze_core   ->   
    output  wire                        mazes_blank,        //  maze_core   ->  
    output  wire[               7   : 0]mazes_timer[2:0],   //  maze_engine ->  
    output  wire                        mazes_close,        //  maze_engine ->  
    output  wire[               1   : 0]mazes_frame,        //  maze_engine ->  
    output  wire[               2   : 0]mazes_reset,        //  maze_engine ->  
    output  wire[               2   : 0]mazes_syncs,        //  maze_engine ->  
  //input       [                  7: 0]timer_range[2:0],   //  maze_engine <-  
    output  wire                        blank_carry, //
    //
    input                               self_enable,        //  maze_engine <-  
    input                               refer_frame,        //  maze_engine <-  
//
    input                               refer_ready,
    input                               refer_clock
);

//`ifndef ENABLE_CONFIG_CACHE
//`elsif  DISABLE_CORE
//`else
//`ifdef DISABLE_CORE//DISABLE_CORE=1 ENABLE_CONFIG_CACHE=0 ->hand
//    `ifndef ENABLE_CONFIG_CACHE
//    `else
//    `endif
//`endif
            wire[               7   : 0]timer_speed[3:0];   //->maze_engine
            wire[               7   : 0]timer_shift[3:0];   //timer_shift[][7] ? timer_shift[][6:0]-mazes_timer[] : mazes_timer[]+timer_shift[6:0]

            wire[               7   : 0]ascii_sizes[1:0];
            wire[               15  : 0]panel_bound[1:0];   //panel_sizes
          //wire[               7   : 0]ports_limit;
            wire[               7   : 0]chain_limit;
            wire[               15  : 0]part_layout;        //PortSetting
            wire[               15  : 0]block_bound[1:0];   //maximum

            wire[               23  : 0]steps_range;    
            wire[               23  : 0]frame_steps;    
            wire                        frame_ready;
    initial_config#(
        .   setup_speed             (   setup_speed),
        .   setup_shift             (   setup_shift),
        .   frequencies             (   frequencies),   //
        .   frame_rates             (   frame_rates),   //
        .   expon_setup             (   expon_setup))   //
    initial_config (
        .   timer_speed             (   timer_speed),   //->maze_engine
        .   timer_shift             (   timer_shift),   //  maze_engine->
        .   ascii_sizes             (   ascii_sizes),   //
        .   panel_bound             (   panel_bound),   //
      //.   ports_limit             (   ports_limit),   //
        .   chain_limit             (   chain_limit),   //
        .   part_layout             (   part_layout),   //
        .   block_bound             (   block_bound),   // maximum
        
        .   steps_range             (   steps_range),   //->maze_engine maze_transport
        .   frame_steps             (   frame_steps),   //->maze_engine
        .   frame_ready             (   frame_ready),   //

        .   access_envm             (   access_envm),   //<-arsenal
        .   setup_write             (   setup_write),   //<-arsenal
        .   setup_qbyte             (   setup_qbyte),   //<-arsenal
        .   setup_ready             (   setup_ready),   //<-arsenal

        .   refer_clock             (   refer_clock));
/*
    24*36*60 = 51840
    
    125000000/51840 = 2411 ~4x8x72
*/
//initial timer_mazes[0]  =   6;
//initial timer_mazes[1]  =   8;  
//initial timer_mazes[2]  =   8+(1<<expon_ports);
//initial timer_scale     =   30;
            wire[                  7: 0]timer_mazes[2:0];
            wire[                  7: 0]timer_scale;//[3]
assign  timer_mazes[0]  =   timer_speed[0];//
assign  timer_mazes[1]  =   timer_speed[1];//
assign  timer_mazes[2]  =   timer_speed[2];//
assign  timer_scale     =   timer_speed[3];//
//ports_syncs
/*


*/
            wire[                  7: 0]engine_gear[2:0];
assign  mazes_timer[0]  =   timer_shift[0][7]?(timer_shift[0][6:0]-engine_gear[0]):(engine_gear[0]-timer_shift[0][6:0]);//
assign  mazes_timer[1]  =   timer_shift[1][7]?(timer_shift[1][6:0]-engine_gear[1]):(engine_gear[1]-timer_shift[1][6:0]);//
assign  mazes_timer[2]  =   timer_shift[2][7]?(timer_shift[2][6:0]-engine_gear[2]):(engine_gear[2]-timer_shift[2][6:0]);//-(timer_mazes[2]-{expon_ports{1'b1}});//

/*
assign  mazes_bound[0]  =  (mazes_chars[15: 8]==panel_bound[1])||(mazes_chars[ 7: 0]==panel_bound[0])||(mazes_chars[15: 8]==0)||(mazes_chars[ 7: 0]==0);//
assign  mazes_bound[1]  =  (mazes_hight[15: 0]==block_bound[1])||(mazes_width[15: 0]==block_bound[0])||(mazes_hight[15: 0]==0)||(mazes_width[15: 0]==0);//
*/

/*


*/
            reg                         loss_signal;
initial loss_signal     =   1;
always@(posedge refer_clock)loss_signal     <=  self_enable;//



            wire[    (expon_mazes-1): 0]locate_maze;//  <-      maze_core       //[expon_cores-1:0]//
            wire[                 31: 0]target_maze;//  ->      maze_core       //[expon_cores-1:0]//   task

    maze_engine#(
        .   frequencies             (   frequencies),   //
        .   frame_rates             (   frame_rates))   //
    maze_engine (
        .   steps_range             (   steps_range),   //<-   
        .   frame_steps             (   frame_steps),   //<-   
      //.   mazes_steps             (   mazes_steps),
        .   mazes_timer             (   engine_gear),   //->
        .   mazes_close             (   mazes_close),   //->    PatternCtrl,mazes_black
        .   mazes_frame             (   mazes_frame[0]),   //->
        .   mazes_reset             (   mazes_reset),   //->    maze core
        .   mazes_syncs             (   mazes_syncs),   //->
        .   timer_mazes             (   timer_mazes),   //<-   [2:0], 
        .   self_enable             (   loss_signal),   //,
        .   refer_frame             (   refer_frame),   //,
        .   refer_clock             (   refer_clock));

    maze_core#(
        .   expon_mazes             (   expon_mazes))
    maze_processor (
        .   locate_maze             (   locate_maze),   //->
        .   target_maze             (   target_maze),   //<-

        .   mazes_blank             (   mazes_blank),   //->
        .   mazes_chars             (   mazes_chars),   //->

        .   refer_reset             (   mazes_reset),   //<-    maze_engine
        .   refer_syncs             (   mazes_syncs[2]),//<-    maze_engine
        .   refer_clock             (   refer_clock));


            wire[                 31: 0]phase_chars[3:0];
            reg [                 17: 0]demux_chars[1:0];
always@(posedge refer_clock)demux_chars[0] <=  mazes_syncs[2]?mazes_chars   :demux_chars[0];
always@(posedge refer_clock)demux_chars[1] <=  mazes_syncs[2]?demux_chars[0]:demux_chars[1];
assign  phase_chars[0]  =   target_maze;
assign  phase_chars[1]  =   mazes_chars;
assign  phase_chars[2]  =   demux_chars[0]|0;
assign  phase_chars[3]  =   demux_chars[1]|0;
    maze_transport#(
        .   expon_field             (   expon_field),
        .   expon_steps             (   expon_steps))
    maze_transport (
        .   demux_break             (   demux_break),   //->  
        .   demux_latch             (   demux_latch),
        .   demux_cycle             (   demux_cycle),   //->  
        .   demux_bidir             (   demux_bidir),   //->          

        .   steps_range             (   steps_range),   //<-

        .   mazes_chars             (   phase_chars[demux_phase]),   //<-

        .   mazes_reset             (   mazes_reset),   //<-
        .   mazes_syncs             (   mazes_syncs),
        .   refer_clock             (   refer_clock));

/*


*/
            reg [                  1: 0]blank_shift;//cache
            reg                         blank_frame;//
always@(posedge refer_clock)blank_shift     <=  mazes_syncs[2]?{blank_shift,mazes_blank}:blank_shift;
always@(posedge refer_clock)blank_frame     <= (mazes_syncs[2]&&(blank_shift==1))?mazes_frame[0]:blank_frame;
assign  mazes_frame[1]  =   blank_frame;//frame_phase
assign  blank_carry     =  (mazes_syncs[2]&&(blank_shift==1));//
/*


*/
            wire[                  1: 0]catch_scrip;
            wire[                  7: 0]catch_coefs[1:0];
            wire                        catch_pixel;//
            wire                        catch_initi;//
            wire                        catch_latch;//
            wire                        catch_pause;//
//assign  catch_scrip     =  {target_maze[17],target_maze[16]};
//assign  catch_coefs[1]  =   target_maze[15: 8];//ars[14: 8];
//assign  catch_coefs[0]  =   target_maze[ 7: 0];
assign  catch_scrip     =  {mazes_chars[17],mazes_chars[16]};
assign  catch_coefs[1]  =   mazes_chars[15: 8];//ars[14: 8];
assign  catch_coefs[0]  =   mazes_chars[ 7: 0];
assign  catch_pixel     =  (catch_scrip==chars_pixel);//chars_pixel
assign  catch_initi     =  (catch_scrip==chars_initi);//chars_initi//?(cross_hside[m]?1:(|mazes_coefs[1])):0;
assign  catch_latch     =  (catch_scrip==chars_latch);//chars_latch
assign  catch_pause     =  (catch_scrip==chars_pause);//chars_pause
/*
            reg [                  7: 0]config_loop[3:0];
always@(posedge refer_clock)
    if( mazes_syncs[2]&&(catch_scrip==chars_pause)&&(&catch_coefs[1][7:expon_index]))
        config_loop[(~catch_coefs[1][expon_index-1:0])] <=  catch_coefs[0];
    else
        config_loop[( catch_coefs[1][expon_index-1:0])] <=  config_loop[( catch_coefs[1][expon_index-1:0])];//


*/
            reg [               1   : 0]loop_access;//catch
            wire[               3   : 0]catch_flash;//catch_flash   warps_flash
            reg [               9   : 0]loop_select[3:0];
always@(posedge refer_clock)loop_access     <=  mazes_syncs[2]?(catch_latch?(loop_access+1):0):loop_access;
assign  catch_flash[0]  =  catch_pause;//
assign  catch_flash[1]  =  catch_pause||((loop_access==1)&&catch_latch);//
assign  catch_flash[2]  =  catch_pause||((loop_access==2)&&catch_latch);//
assign  catch_flash[3]  =  catch_pause||((loop_access==3)&&catch_latch);
always@(posedge refer_clock)loop_select[0]  <=  mazes_syncs[2]?(catch_flash[0]?0:loop_select[0]+(catch_latch&&(loop_access==0))):loop_select[0];//
always@(posedge refer_clock)loop_select[1]  <=  mazes_syncs[2]?(catch_flash[1]?0:loop_select[1]+(catch_latch&&(loop_access==0))):loop_select[1];//
always@(posedge refer_clock)loop_select[2]  <=  mazes_syncs[2]?(catch_flash[2]?0:loop_select[2]+(catch_latch&&(loop_access==1))):loop_select[2];//
always@(posedge refer_clock)loop_select[3]  <=  mazes_syncs[2]?(catch_flash[3]?0:loop_select[3]+(catch_latch&&(loop_access==2))):loop_select[3];//

            wire[                 15: 0]warps_hight;//
            wire[                 15: 0]warps_width;//
assign  mazes_hight     =  (warps_hight +  mazes_chars[15: 8]);// -   shift_hight ;//
assign  mazes_width     =  (warps_width +  mazes_chars[ 7: 0]);// -   shift_width ;//
        
            wire                        pulse_write;
            wire[               31  : 0]pulse_qbyte;//
    pulse_core#(
        .   files_pulse             (   files_pulse),
        .   expon_pulse             (   expon_pulse))
    gray_processor (

        .   column_code             (   column_code), //->
        .   column_ctrl             (   column_ctrl), //->
        .   column_mark             (   column_mark), //->
        .   row_trigger             (   row_trigger), //->
        .   row_control             (   row_control), //->

        .   pulse_write             (   pulse_write), 
        .   pulse_qbyte             (   pulse_qbyte), 
        
        .   pulse_frame             (   ),
        .   refer_frame             (   mazes_frame[gray_syncer]),
        .   refer_ready             (  (access_envm?setup_ready:refer_ready)),//refer_blank), 
        .   refer_clock             (   refer_clock));


            reg                         mem_ext_sel;//
            wire                        mem_ext_rdy;//
            reg                         mem_ext_ctl;//
            wire                        mem_ext_wex;//
            wire[                  31:0]mem_ext_adr;//
            wire[                   1:0]mem_bus_ack;//

            wire[                  31:0]mem_set_dat;
            wire[                  31:0]mem_get_dat;

assign  inside_port     = ((mazes_timer[timer_ports]>>expon_ports)==0);
assign  place_ports     =   mazes_timer[timer_ports];   //  mazes_timer ->loop_access,pattern
assign  place_loops[0]  =  (loop_select[0]&((1<<expon_loops[0])-1))+(place_ports<<expon_loops[0]);//{place_ports,loop_select[0][expon_loops[0]-1:0]};   //
assign  place_loops[1]  =  (loop_select[1]&((1<<expon_loops[1])-1))+(place_ports<<expon_loops[1]);//{place_ports,loop_select[1][expon_loops[1]-1:0]};   //
assign  place_loops[2]  =  (loop_select[2]&((1<<expon_loops[2])-1))+(place_ports<<expon_loops[2]);//{place_ports,loop_select[2][expon_loops[2]-1:0]};   //
assign  place_loops[3]  =  (loop_select[3]&((1<<expon_loops[3])-1))+(place_ports<<expon_loops[3]);//{place_ports,loop_select[3][expon_loops[3]-1:0]};   //

            wire                        gamma_carry;        //  ->color
            reg                         gamma_syncs;
always@(posedge refer_clock)gamma_syncs <= (gamma_carry&&(&gamma_curve))?(mazes_blank):gamma_syncs;
assign  gamma_catch =   gamma_syncs&&gamma_carry;//


    arsenal#(
        .   files_mzaes             (   files_mzaes),//=   "./P160522_MAZE.mem",
        .   files_loop1             (   files_loop1),//=   "./P160522_CHIP.mem",//files_loop1
        .   files_loop3             (   files_loop3),//=   "./P160522_PART.mem",//files_loop3   {port,cascade}
        .   files_loop2             (   files_loop2),//=   "./P160522_LINE.mem",//files_loop2
      //.   files_pulse             (   files_pulse),//=   "./P160522_WAVE.mem",//
        .   files_setup             (   files_setup),//=   "./P160522_CONFIG.mem",//
        .   files_fonts             (   files_fonts),//=   "./TXT128_H16x8b.mem",//
        .   files_exp01             (   files_exp01),//=   "./square32b10a.mem",//"./square32b10a.mem",//
        .   gamma_table             (   gamma_table),
//
        .   tasks_part3             (   tasks_part3),
        .   tasks_fonts             (   tasks_fonts),
        .   tasks_part1             (   tasks_part1),
        .   tasks_part2             (   tasks_part2),
        .   tasks_mazes             (   tasks_mazes),
        .   tasks_gamma             (   tasks_gamma),
        .   tasks_pulse             (   tasks_pulse),
        .   tasks_setup             (   tasks_setup),
//
        .   cache_loop3             (   cache_loop3),//=   0,//cache_loop1
        .   cache_loop1             (   cache_loop1),//=   0,//cache_loop2
        .   cache_loop2             (   cache_loop2),//=   0,//cache_loop3
        .   cache_mazes             (   cache_mazes),//=   0,
        .   cache_gamma             (   cache_gamma),//=   1,
        .   cache_fonts             (   cache_fonts),//=   1,
        .   cache_setup             (   cache_setup),//=   1,
//    
        .   expon_cores             (   expon_cores),
        .   expon_mazes             (   expon_cores+expon_mazes), 
        .   expon_index             (   expon_index),
        .   expon_loops             ( {(expon_loops[3]+(matrix_part[3]*expon_ports)),
                                       (expon_loops[2]+(matrix_part[2]*expon_ports)),
                                       (expon_loops[1]+(matrix_part[1]*expon_ports)),
                                       (expon_loops[0]+(matrix_part[0]*expon_ports))}),
        .   expon_setup             (   expon_setup),
        .   expon_pulse             (   expon_pulse),
        .   expon_drive             (   ),
        .   expon_unuse             (   ),
        .   expon_exp10             (   expon_exp10),  
        .   expon_gamma             (   expon_gamma),
        .   expon_fonts             (   expon_fonts))


    arsenal(
        .   locate_maze             (  {frame_tasks,locate_maze}),//maze_core     <-  //[expon_cores-1:0]//
        .   target_maze             (   target_maze),//maze_core     ->  //[expon_cores-1:0]//   task
        .   ports_syncs             (   mazes_syncs[gears_tasks]),//mazes_syncs[1]),
        .   place_loops             (   place_loops),
        .   warps_hight             (   warps_hight),//loop_access   ->
        .   warps_width             (   warps_width),//loop_access   ->
        .   pulse_write             (   pulse_write),//wave          <-   //pulse_write
        .   pulse_qbyte             (   pulse_qbyte),//wave          ->   //pulse_qbyte
        .   gamma_index             (   gamma_index),
        .   gamma_catch             (   gamma_carry),//gamma_catch),//   //<-MCU
        .   gamma_curve             (   gamma_curve),//   //
        .   gamma_slope             (   gamma_slope),//   //
        .   gamma_ready             (   gamma_ready),
        .   w08h16_addr             (   w08h16_addr),//pattenr       <-  //
        .   w08h16_font             (   w08h16_font),//pattenr       ->
        .   setup_ready             (   setup_ready),//setup_write
        .   setup_write             (   setup_write),//setup_qbyte
        .   setup_qbyte             (   setup_qbyte),//setup_ready
        .   access_envm             (   access_envm),
        .   mem_ext_sel             (   mem_ext_sel),//   
        .   mem_ext_rdy             (   mem_ext_rdy),//   
        .   mem_ext_ctl             (   mem_ext_ctl),//   
        .   mem_ext_wex             (   mem_ext_wex),//   
        .   mem_ext_adr             (   mem_ext_adr),//   
        .   mem_bus_ack             (   mem_bus_ack),//   
        .   mem_set_dat             (   mem_set_dat),//   
        .   mem_get_dat             (   mem_get_dat),//   
        .   refer_ready             (   refer_ready),//   //
        .   refer_clock             (   refer_clock));//   


always@(posedge refer_clock)mem_ext_sel <=  0;//(refer_ready&&gamma_ready&&mazes_syncs[2]) ? ((mazes_reset==1)? (1) : (mem_ext_sel)):0;


            reg [                 1 : 0]mem_ext_det;
            reg [                 15: 0]mem_wrx_adr;
            reg [                 1 : 0]mem_wrx_sel;
always@(posedge refer_clock)mem_ext_det <= {mem_ext_det,(mem_bus_ack[1]&&( mem_ext_rdy))};//
always@(posedge refer_clock)
    if(!mem_bus_ack[0])
    begin
        mem_ext_ctl <=  mem_ext_rdy;
       {mem_wrx_adr,mem_wrx_sel}<= {mem_wrx_adr,mem_wrx_sel}+((!mem_ext_ctl)&&mem_ext_rdy);//
    end
    else
    if( mem_bus_ack[0])//save = 2t[1]
    begin
        mem_ext_ctl <=  0;
       {mem_wrx_adr,mem_wrx_sel}<= {mem_wrx_adr,mem_wrx_sel};
    end
    else
    begin
        mem_ext_ctl <=  mem_ext_ctl;
       {mem_wrx_adr,mem_wrx_sel}<= {mem_wrx_adr,mem_wrx_sel};
    end
            reg [                 31: 0]rom_get_buf;//32'h60000000 | address<<2
always@(posedge refer_clock)rom_get_buf <=((mem_ext_det==2'b00)&&mem_bus_ack[1]&&(!mem_ext_wex))?mem_get_dat:rom_get_buf;

            reg                         ram_get_ack;
            reg [                 31: 0]ram_get_buf;//32'h20000000 | address<<2
always@(posedge refer_clock)ram_get_ack <= (mem_ext_ctl&&(!mem_ext_wex));
always@(posedge refer_clock)ram_get_buf <=  ram_get_ack?mem_get_dat:ram_get_buf;



assign  mem_ext_wex = (!mem_wrx_sel[0]);//  <- 
assign  mem_ext_adr =   32'h20000000|(mem_wrx_adr[13: 0]<<2);//  <- 
assign  mem_set_dat =   mem_wrx_sel[1]?(~ram_get_buf):{~mem_wrx_adr,mem_wrx_adr};//  <- 
endmodule
