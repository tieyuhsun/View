module  initial_config
#(
//setup_ready   =   0



    parameter   [   7   : 0]setup_speed[3:0]=  { 8'h01,8'h01,8'h49,8'h08},  //{(reserve),engine.in ,engine.in ,engine.in }
    parameter   [   7   : 0]setup_shift[3:0]=  { 8'h00,8'h00,8'h00,8'h00},  //{(reserve),engine.out,engine.out,engine.out}  limit_angle
  //parameter               setup_ports     =   2,  //PortForTime           time[  2]   11

  //parameter               gears_shaft     =   0,  //                      time[  0]   8
  //parameter               gears_tasks     =   1,  //                      time[  1]   8
  //parameter               setup_ports     =   2,  //PortForTime           time[  2]   11
  //parameter               gears_scale     =   3,  //                      time[  3]   n/a
    
  //parameter               loops_chips     =   1,  //guide_chips           loop[  1]
  //parameter               loops_chain     =   3,  //guide_chain           loop[3/2]
  //parameter               loops_lines     =   2,  //guide_lines           loop[2/3]
  //parameter               loops_strip     =   0,  //guide_strip(reserve)  loop[  0]
//
    parameter   [   7   : 0]sizes_ascii[1:0]=  { 8'h10, 8'h08},         //pattern.ascii(reserve)
    parameter   [   15  : 0]sizes_panel[1:0]=  {16'd30,16'd20},         //pattern.outline
    parameter               limit_chain     =   4,  //8b chain_limit
    parameter               limit_ports     =   8,  //8b ports_limit
    parameter               double_side     =   1,  //4b LR_SameSidecross staggered Odd_X_EvenSide     =   0,//4b      
    parameter               F_L_Forward     =   0,  //4b part_layout Reverse   ports_R0_L1 =   ,//part_layout
    parameter               F_R_Forward     =   1,  //4b part_layout
//
    parameter               local_speed     =   0,//timer.range<-
    parameter               local_shift     =   2,//timer.phase local_angle
    parameter               local_guide     =   3,//
    parameter               local_DotPx     =   4,//fonts.sizes
    parameter               local_bound     =   5,//pattern.panel.bound 
    parameter               local_build     =   6,//

//
    parameter   [   23  : 0]limit_steps[1:0]=  {24'd65536,24'd64},
    
    parameter   frequencies     =   125000000,
    parameter   frame_rates     =   60,
    parameter   expon_setup     =   3
)(
/*
    step.1  poewr on reset
    step.2  setup_ready =   0
    step.3  file_config =  {setup_write,setup_qbyte}
    step.4  setup_ready =   1

*/
    input                               access_envm,
    input                               setup_ready,
    input                               setup_write,
    input       [               31  : 0]setup_qbyte,

/*

    step.3  file_config =  {setup_write,setup_qbyte}

*/
    output  reg [               7   : 0]timer_speed[3:0],
    output  reg [               7   : 0]timer_shift[3:0],   //timer_shift[][7] ? timer_shift[][6:0]-mazes_timer[] : mazes_timer[]+timer_shift[6:0]
  //output  reg [               1   : 0]timer_ports,        //mazes_timer[]


    output  reg [               7   : 0]ascii_sizes[1:0],
    output  reg [               15  : 0]panel_bound[1:0],   //panel_sizes
    output  reg [               7   : 0]ports_limit,
    output  reg [               7   : 0]chain_limit,
    output  reg [               15  : 0]part_layout,        //PortSetting

/*
*/
    output  wire[                 15: 0]block_bound[1:0],   //block_sizes  ->
/*
*/
    output  reg [                 23: 0]steps_range,//clock per steps
    output  reg [                 23: 0]frame_steps,//steps per frame
    output  reg                         frame_ready,//
/*
*/
    input                               refer_clock         //  <-  XPU
);



            reg [   expon_setup-1   : 0]setup_loacl;//
always@(posedge refer_clock)setup_loacl <=  setup_write?setup_loacl:setup_qbyte;

//shaft 
//timer.engine<-
always@(posedge refer_clock)timer_speed[0]  <=  access_envm?(((setup_loacl==local_speed)&&setup_write)? setup_qbyte[ 7: 0]:timer_speed[0]): setup_speed[0];
always@(posedge refer_clock)timer_speed[1]  <=  access_envm?(((setup_loacl==local_speed)&&setup_write)? setup_qbyte[15: 8]:timer_speed[1]): setup_speed[1];
always@(posedge refer_clock)timer_speed[2]  <=  access_envm?(((setup_loacl==local_speed)&&setup_write)? setup_qbyte[23:16]:timer_speed[2]): setup_speed[2];
always@(posedge refer_clock)timer_speed[3]  <=  access_envm?(((setup_loacl==local_speed)&&setup_write)? setup_qbyte[31:24]:timer_speed[3]): setup_speed[3];
//timer.engine->
always@(posedge refer_clock)timer_shift[0]  <=  access_envm?(((setup_loacl==local_shift)&&setup_write)? setup_qbyte[ 7: 0]:timer_shift[0]): setup_shift[0];   //timer.engine
always@(posedge refer_clock)timer_shift[1]  <=  access_envm?(((setup_loacl==local_shift)&&setup_write)? setup_qbyte[15: 8]:timer_shift[1]): setup_shift[1];   //timer.engine
always@(posedge refer_clock)timer_shift[2]  <=  access_envm?(((setup_loacl==local_shift)&&setup_write)? setup_qbyte[23:16]:timer_shift[2]): setup_shift[2];   //timer.engine
always@(posedge refer_clock)timer_shift[3]  <=  access_envm?(((setup_loacl==local_shift)&&setup_write)? setup_qbyte[23:16]:timer_shift[3]): setup_shift[3];   //timer.engine

//
//always@(posedge refer_clock)timer_ports     <=  access_envm?(((setup_loacl==local_guide)&&setup_write)? setup_qbyte[ 3: 0]:timer_ports):    setup_ports;      //mazes_loops[1]

//
always@(posedge refer_clock)ascii_sizes[1]  <=  access_envm?(((setup_loacl==local_DotPx)&&setup_write)? setup_qbyte[15: 8]:ascii_sizes[1]): sizes_ascii[1];   //reserve(dot.h)
always@(posedge refer_clock)ascii_sizes[0]  <=  access_envm?(((setup_loacl==local_DotPx)&&setup_write)? setup_qbyte[ 7: 0]:ascii_sizes[0]): sizes_ascii[0];   //reserve(dot.w)

always@(posedge refer_clock)panel_bound[1]  <=  access_envm?(((setup_loacl==local_bound)&&setup_write)? setup_qbyte[31:16]:panel_bound[1]): sizes_panel[1];   //outline.h
always@(posedge refer_clock)panel_bound[0]  <=  access_envm?(((setup_loacl==local_bound)&&setup_write)? setup_qbyte[15: 0]:panel_bound[0]): sizes_panel[0];   //outline.v

always@(posedge refer_clock)chain_limit     <=  access_envm?(((setup_loacl==local_build)&&setup_write)? setup_qbyte[ 7: 0]:chain_limit):    limit_chain;      //cascade
always@(posedge refer_clock)ports_limit     <=  access_envm?(((setup_loacl==local_build)&&setup_write)? setup_qbyte[15: 8]:ports_limit):    limit_ports;      //port
always@(posedge refer_clock)part_layout     <=  access_envm?(((setup_loacl==local_build)&&setup_write)? setup_qbyte[31:16]:part_layout):   (F_R_Forward<<12)|
                                                                                                                                           (F_L_Forward<<8) | 
                                                                                                                                            double_side;//
//
            wire[                8  : 0]vertical___;//256
            wire[                8  : 0]horizontal_;

assign  vertical___     =   ports_limit>>part_layout[0];//
assign  horizontal_     =   chain_limit<<part_layout[0];//
assign  block_bound[1]  = //panel_bound[1]*vertical___
                           (vertical___[8]  ?  (panel_bound[1]<<8):0)   +
                           (vertical___[7]  ?  (panel_bound[1]<<7):0)   +
                           (vertical___[6]  ?  (panel_bound[1]<<6):0)   +
                           (vertical___[5]  ?  (panel_bound[1]<<5):0)   +
                           (vertical___[4]  ?  (panel_bound[1]<<4):0)   +
                           (vertical___[3]  ?  (panel_bound[1]<<3):0)   +
                           (vertical___[2]  ?  (panel_bound[1]<<2):0)   +
                           (vertical___[1]  ?  (panel_bound[1]<<1):0)   +
                           (vertical___[0]  ?  (panel_bound[1]<<0):0);

assign  block_bound[0]  = //panel_bound[0]*horizontal_
                           (horizontal_[8]  ?  (panel_bound[0]<<8):0)   +
                           (horizontal_[7]  ?  (panel_bound[0]<<7):0)   +
                           (horizontal_[6]  ?  (panel_bound[0]<<6):0)   +
                           (horizontal_[5]  ?  (panel_bound[0]<<5):0)   +
                           (horizontal_[4]  ?  (panel_bound[0]<<4):0)   +
                           (horizontal_[3]  ?  (panel_bound[0]<<3):0)   +
                           (horizontal_[2]  ?  (panel_bound[0]<<2):0)   +
                           (horizontal_[1]  ?  (panel_bound[0]<<1):0)   +
                           (horizontal_[0]  ?  (panel_bound[0]<<0):0);

/*

*/

            reg [                1  : 0]convolution;
always@(posedge refer_clock)convolution     <= {convolution,((setup_loacl==local_speed)&&setup_write)};//
always@(posedge refer_clock)//step_period   steps_cycle
    if( setup_ready&&(!access_envm))
        if( convolution[0])
                steps_range <= (timer_speed[1]*timer_speed[0]);//
        else
            if( convolution[1])
                steps_range <= (timer_speed[2]*steps_range);//
            else
                steps_range <=  steps_range;//
    else
                steps_range <= (setup_speed[2]*setup_speed[1]*setup_speed[0]);

/*

        4096/414    =   9.8937198067632850241545893719807
        65536/414   =   158.29951690821256038647342995169
        
        414*9       =   3726/4096
        414*158     =   65412/65536

*/






            wire                        quotient_ok;
            wire[               23  : 0]frame_ratio;//frame_steps   frame_steps
    DIVIDER#(
        .   Combination             (   0),
        .   exp_divider             (   24))
    frame_divider (
        .   dividend___             (  (frequencies/frame_rates)),//125M/15 = 0x7F2815
        .   divisor____             (   steps_range),//

        .   quotient___             (   frame_ratio),
        .   quotient_ok             (   quotient_ok),

        .   refer_clock             (   refer_clock));

            reg[                1   : 0]calc_stable;
always@(posedge refer_clock)
    if( quotient_ok)
        calc_stable <= {calc_stable,setup_ready};//
    else    
        calc_stable <=  calc_stable;

always@(posedge refer_clock)
    if (setup_ready)
        if( quotient_ok&&(&calc_stable))
        begin
            frame_steps <= (frame_ratio-1);//
            frame_ready <=((limit_steps[1]>frame_ratio)&&(frame_ratio>limit_steps[0]));//((frame_ratio<8192)||(frame_ratio>127));//
        end
        else
        begin
            frame_steps <=  frame_steps;//
            frame_ready <=(&calc_stable);//
        end
    else
        begin
            frame_steps <=( frequencies/(frame_rates*setup_speed[2]*setup_speed[1]*setup_speed[0]));//
            frame_ready <=  0;//
        end

endmodule