module  maze_core//
#(

    parameter   chars_pixel     =   0,
    parameter   chars_initi     =   1,
    parameter   chars_latch     =   2,
    parameter   chars_pause     =   3,

    parameter   expon_queue     =   4,//
    parameter   expon_loops     =   2,//124,125,126,127 

    parameter   width_coefs     =   8,//width_coefs

    parameter   expon_mazes     =   8//nvm_bitness

/**/
)(
    output  reg [   expon_mazes-1   : 0]locate_maze,
    input       [                 17: 0]target_maze,// coherence arbiter_amba_hrdata,AMBA_HRDATA.target_maze,
//
    output  wire                        mazes_blank,
    output  wire[                 17: 0]mazes_chars,
//


//
    input       [                  2: 0]refer_reset,
    input                               refer_syncs,
//
    input                               refer_clock
);


    parameter   script_bit1     =  (width_coefs==7)?15:17;
    parameter   script_bit0     =  (width_coefs==7)? 7:16;

            wire[                  1: 0]cache_scrip;//
            wire[    (width_coefs-1): 0]cache_coefs[1:0];//coefs
            wire                        cache_blank;//circle    round   ambit   guide   rules   reserclose
            wire                        cache_pixel;
            wire                        cache_initi;
            wire                        cache_latch;
            wire                        cache_pause;
//
            wire                        cache_break;
            wire                        cache_queue;
            wire                        cache_trade;
assign  cache_scrip         =  {target_maze[script_bit1],target_maze[script_bit0]};
assign  cache_coefs[1]      =   target_maze[((width_coefs+8)-1): 8];
assign  cache_coefs[0]      =   target_maze[((width_coefs+0)-1): 0];

assign  cache_blank         =  (cache_scrip==chars_pause)&&(&cache_coefs[1])&&(&cache_coefs[0]);//&&(&cache_coefs[0]);//&&(&target_maze[ 6: 0]);//
assign  cache_pixel         =  (cache_scrip==chars_pixel);//
assign  cache_initi         =  (cache_scrip==chars_initi);//
assign  cache_latch         =  (cache_scrip==chars_latch);//
assign  cache_pause         =  (cache_scrip==chars_pause);//
//
assign  cache_break         =   cache_pause&&(&cache_coefs[1][(width_coefs-1): expon_loops]);//&&(!(&cache_coefs[1][expon_loops-1:0]));
assign  cache_queue         =   cache_pause&&(&cache_coefs[1])&&(cache_coefs[0][(width_coefs-1):expon_queue]==0);
assign  cache_trade         =   cache_initi&&(&cache_coefs[1]);//( cache_coefs[1]==queue_coefs[1]);
//



/*
 
*/

            reg [((1<<expon_queue)-1):0]queue_phase;    initial queue_phase =   0;
            reg [  (expon_queue-0)  : 0]queue_count;    initial queue_count =   0;
            reg [  (expon_queue-0)  : 0]queue_coefs;
            reg                         queue_works;    initial queue_works =   0;
            reg                         queue_flags;    initial queue_flags =   0;
always@(posedge refer_clock)queue_coefs <=  refer_syncs?((cache_queue&&(queue_phase[queue_count]))?cache_coefs[0]:queue_coefs):queue_coefs;
always@(posedge refer_clock)
    if( refer_syncs)
        if( refer_reset==2)
            begin
                queue_works <=  0;
                queue_phase <=  queue_works?((queue_phase==0)?1:{queue_phase,1'b0}):1;
                queue_count <=  queue_count;
            end
        else
            begin
                queue_works <= (queue_works||(cache_queue&&queue_phase[queue_count]));
                queue_phase <=  queue_phase;
                queue_count <=  cache_queue?(queue_count+1):0;
            end
    else
            begin
                queue_works <=  queue_works;
                queue_phase <=  queue_phase;
                queue_count <=  queue_count;
            end

/*

  //behavior_ck[1]
  //    ECK 0..62   ->  DCK.ENA ,   ECK cache_latch? scale[1] :0;
  //    ECK 63      ->  DCK.OFF ,   ECK cache_latch? coefs[1] :0;
  //    
  //
  //behavior_ck[0]
  //    DCK 0..63   ->  cache_pixel                         ?   DCK.ENA :
  //                    cache_initi                         ?   DCK.ENA :
  //                    cache_latch&&(behavior_ck[1] <63 )  ?   DCK.ENA :
  //                    cache_latch&&(behavior_ck[1] =63 )  ?   DCK.OFF :
  //                                                            DCK.OFF;
//260204 del

            reg [    (width_coefs-1): 0]behavior_ck[1:0];
always@(posedge refer_clock)behavior_ck[1]  <=  cache_pause?cache_coefs[1]:behavior_ck[1];//0..63
always@(posedge refer_clock)behavior_ck[0]  <=  cache_pause?cache_coefs[0]:behavior_ck[0];//0..47
*/

//260204 add
            reg [               3   : 0]cycle_latch;//
            reg [               5   : 0]cycle_initi;//
            reg [               5   : 0]cycle_pixle;//
always@(posedge refer_clock)cycle_latch <={(cache_coefs[1]>>5),(cache_coefs[0]>>5)};//
always@(posedge refer_clock)cycle_initi <=  cache_coefs[1];//
always@(posedge refer_clock)cycle_pixle <=  cache_coefs[0];//
/*
*/
            reg [   expon_mazes-1   : 0]record_maze;//reg [                  6: 0]loops_point;

            reg [                  1: 0]guide_scrip;
            reg [    (width_coefs-1): 0]guide_coefs[1:0];//coefs
            reg                         guide_blank;//image_blank
            reg                         guide_reset;
            reg [  (expon_loops-1)  : 0]guide_class;//initial guide_class =   1;
            wire                        guide_pixel;
            wire                        guide_initi;
            wire                        guide_latch;
            wire                        guide_pause;
assign  guide_pixel     =  (guide_scrip==chars_pixel);//
assign  guide_initi     =  (guide_scrip==chars_initi);//
assign  guide_latch     =  (guide_scrip==chars_latch);//
assign  guide_pause     =  (guide_scrip==chars_pause);//

            reg                         guide_break;
always@(posedge refer_clock)guide_break <=  refer_syncs?cache_break:guide_break;

            reg [    (width_coefs-1): 0]class_cycle[(1<<expon_loops)-1:0];
            reg [    (width_coefs-1): 0]chain_cycle[(1<<expon_loops)-1:0];
            reg [(1<<expon_loops)-1 : 0]branch_loop;
            reg                         branch_ctrl;
          //reg [                  5: 0]branch_data;
always@(posedge refer_clock)class_cycle[guide_class]<= (guide_break&&refer_syncs)?(guide_coefs[0][(width_coefs-1):0]-1):class_cycle[guide_class];



always@(posedge refer_clock)branch_ctrl     <=  branch_loop[guide_class];//

genvar j;
    generate
        for (j=0; j<(1<<expon_loops); j=j+1)
        begin   //

always@(posedge refer_clock)branch_loop[j]  <= (chain_cycle[j]==class_cycle[j])?0:1;//

always@(posedge refer_clock)
    if( refer_syncs)
        if( cache_pause)
            chain_cycle[j]  <=  0;//branch_ctrl?0:chain_cycle[guide_class]+1;
        else
            if( cache_latch&&(guide_class==j))
                chain_cycle[j]  <=  branch_loop[j]?(chain_cycle[j]+1):0;
            else
                chain_cycle[j]  <=  chain_cycle[j];
        end     // block: u
    endgenerate
//always@(posedge refer_clock)
//    if(&refer_syncs[1:0])
//        if( cache_latch)
//                chain_cycle[guide_class]<=  branch_data;//branch_ctrl?0:chain_cycle[guide_class]+1;
//        else
//            if( cache_pause)
//                chain_cycle[guide_class]<=  0;
//            else
//                chain_cycle[guide_class]<=  chain_cycle[guide_class];
//    else
//                chain_cycle[guide_class]<=  chain_cycle[guide_class];

//always@(posedge refer_clock)branch_data <= (chain_cycle[guide_class]!=class_cycle[guide_class])?(chain_cycle[guide_class]+1):0;//


always@(posedge refer_clock)
    if( refer_syncs)
    begin
        guide_reset     <=( refer_reset==2);
        guide_blank     <=( refer_reset==2)?0:(guide_blank||(guide_latch&&cache_blank));//image_blank   cache_blank
//
        locate_maze     <=( refer_reset==1)?((1<<expon_mazes)-2)://0://(-2):
                          ( refer_reset==2)?{cache_coefs[1],cache_coefs[0]}:
                          ( cache_latch&&(branch_ctrl))?record_maze:(locate_maze+1);

      //record_maze     <=((guide_latch||guide_pause)&&(cache_initi||cache_pixel))?locate_maze:record_maze;//251121 del
        record_maze     <=((guide_pause)&&(cache_initi||cache_pixel))?locate_maze:record_maze;//251121 add

        guide_class     <=  cache_break?(~cache_coefs[1]):
                          ((guide_latch||guide_pause)&&(cache_initi||cache_pixel))?1:
                           (cache_initi||cache_pixel)?guide_class:((&guide_class)?1:(guide_class+1));
//
        guide_scrip     <=  cache_scrip;
/*
//260204 del
        guide_coefs[1]  <=  cache_trade ? queue_coefs : 
                           (cache_latch&&(branch_ctrl))?0:cache_coefs[1]; 
*/
//260204 add
        guide_coefs[1]  <=  cache_trade ? queue_coefs : cache_coefs[1]; 

        guide_coefs[0]  <=  cache_coefs[0];
    end
    else
    begin
        guide_reset     <=  guide_reset;
        guide_blank     <=  guide_blank;

        locate_maze     <=  locate_maze;
        record_maze     <=  record_maze;
        guide_class     <=  guide_class;

        guide_scrip     <=  guide_scrip;
        guide_coefs[1]  <=  guide_coefs[1];
        guide_coefs[0]  <=  guide_coefs[0];
    end

assign  mazes_chars[script_bit1]            =   guide_scrip[1];
assign  mazes_chars[script_bit0]            =   guide_scrip[0];
assign  mazes_chars[((width_coefs+8)-1): 8] =   guide_coefs[1]|0;
assign  mazes_chars[((width_coefs+0)-1): 0] =   guide_coefs[0]|0;
assign  mazes_blank                         =   guide_blank;

/*
            reg [  (expon_loops-1)  : 0]mazes_class;//
            reg [                  5: 0]mazes_chain;//
            reg                         mazes_nodes;//mazes_nodes ? mazes_chain(t+1)+1
always@(posedge refer_clock)mazes_class         <=  guide_class;//guide_class;
always@(posedge refer_clock)mazes_chain         <=  chain_cycle[guide_class];//+branch_ctrl;//guide_chain;
always@(posedge refer_clock)mazes_nodes         <=  branch_ctrl&&cache_latch;
*/
endmodule
