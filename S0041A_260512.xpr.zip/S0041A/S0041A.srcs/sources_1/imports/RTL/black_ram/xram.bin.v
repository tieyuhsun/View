//(* ram_style = "{auto|block|distributed|pipe_distributed|block_power1|block_power2}" *)
module xram#(
    parameter   memory_file = 0,//"./rom.rom",
    parameter   memory_type = "auto",/*auto block distributed*/
    parameter   expon_chars = 36,
    parameter   expon_local = 16
)( 
    input                           write_clock, 
    input       [  expon_local-1: 0]write_local, 
    input                           write_syncs,
    input       [  expon_chars-1: 0]write_chars, 
    input                           carry_clock,
    input       [  expon_local-1: 0]carry_local, 
    output  reg [  expon_chars-1: 0]carry_chars

);


            reg [  expon_chars-1: 0]chars_array[(1<<expon_local)-1 :0];
initial
begin
$readmemb(memory_file, chars_array);
end
always@(posedge write_clock)chars_array[write_local]<=  write_syncs ?   write_chars :   chars_array[write_local];

always@(posedge carry_clock)carry_chars             <=  chars_array[carry_local];



endmodule
