//(* ram_style = "{auto|block|distributed|pipe_distributed|block_power1|block_power2}" *)
module lut_ram#(
    parameter   memory_file = 0,//"./rom.rom",
    parameter   memory_type = "auto",/*auto block distributed*/
    parameter   expon_chars = 36,
    parameter   expon_local = 16
)( 
    input                           write_clock, 
    input       [  expon_local-1: 0]write_local, 
    input                           write_syncs,
    input       [  expon_chars-1: 0]write_chars, 
  //input                           carry_clock,
    input       [  expon_local-1: 0]carry_local[1:0], 
    output  wire[  expon_chars-1: 0]carry_chars[1:0]

);


            reg [  expon_chars-1: 0]chars_array[(1<<expon_local)-1 :0];
initial
begin
$readmemb(memory_file, chars_array);
end
always@(posedge write_clock)chars_array[write_local]<=  write_syncs ?   write_chars :   chars_array[write_local];

assign  carry_chars[0]  =   chars_array[carry_local[0]];
assign  carry_chars[1]  =   chars_array[carry_local[1]];



endmodule
