module launchpad
#(
    parameter   chars_pixel =   0,
    parameter   chars_initi =   1,
    parameter   chars_latch =   2,
    parameter   chars_pause =   3 ,


    parameter   Double_Data =   1 ,

    parameter   expon_steps =   6,
  //parameter   expon_field =   4,
    parameter   expon_ports =   3
)
(
    output  wire                        panel_clock,
    output  wire                        panel_latch,
    output  wire[ (1<<expon_ports)-1: 0]panel_runes,
//
    input       [               63  : 0]demux_catch[(1<<expon_ports)-1:0],
//
    input                               demux_bidir,//->
    input                               demux_break,//->
    input                               demux_latch,//{DDR,SDR}
    input       [  (expon_steps+7)  : 0]demux_cycle,//->
/**/
    input                               refer_ready,
    input                               refer_clock
);


/*



            wire[                  1: 0]mazes_scrip;
            wire[                  7: 0]mazes_coefs[1:0];
            wire                        mazes_pixel;//
            wire                        mazes_initi;//
            wire                        mazes_latch;//
            wire                        mazes_pause;//
assign  mazes_scrip     =  {mazes_chars[17],mazes_chars[16]};
assign  mazes_coefs[1]  =   mazes_chars[15: 8];//
assign  mazes_coefs[0]  =   mazes_chars[ 7: 0];
assign  mazes_pixel     =  (mazes_scrip==chars_pixel);//chars_pixel
assign  mazes_initi     =  (mazes_scrip==chars_initi);//chars_initi//?(cross_hside[m]?1:(|mazes_coefs[1])):0;
assign  mazes_latch     =  (mazes_scrip==chars_latch);//chars_latch
assign  mazes_pause     =  (mazes_scrip==chars_pause);//chars_pause
*/
            wire[               5   : 0]demux_steps;
            wire[   expon_steps-1   : 0]demux_phase[1:0];
assign {demux_steps,demux_phase[0]}=   demux_cycle;//
assign  demux_phase[1]=(demux_cycle>>1);//

assign  panel_latch     =   demux_break?0: demux_latch;//
assign  panel_clock     =   demux_break?0:(demux_phase[Double_Data][expon_steps-1]^demux_phase[Double_Data][expon_steps-2]);//

genvar i;
    generate
        for (i=0; i<(1<<expon_ports); i=i+1)
        begin
assign  panel_runes[i]  =   demux_catch[i][demux_steps];

        end // block: u
    endgenerate
endmodule

/*
		DRV_CMD(47 downto 32)	<=	
            '1' &                   CMD[   47]
            '0' &                   CMD[   46]
            '1' &                   CMD[   45]              detect_ctrl
            ERR_DECT_SEL_T &        CMD[   44]              check_short
            "01" &                  CMD[43:42]              threshold_r 1
            "0000" &                CMD[41:38]
            R_CMD(7 downto 2);      CMD[37:32]  currentse_r

		DRV_CMD(31 downto 16)	<=
            "00"    &               CMD[   31],CMD[   30]
            "01"    &               CMD[29:28]              detect_rank
            "10"    &               CMD[27:26]              threshold_g 2
            "0000"  &               CMD[25:22] 
            G_CMD(7 downto 2);      CMD[21:16]  currentse_g

		DRV_CMD(15 downto 0)    <=	
            "1001"  &               CMD[15:12]
            "10"    &               CMD[11:10]              threshold_b 2
            "0000"  &               CMD[ 9: 6]
            B_CMD(7 downto 2);      CMD[ 5: 0]  currentse_b


        wire                        ENABLE_CHIP = 1;//              CMD[   47]All 48 current outputs enable/disable 
        wire                        OHM_6K_OVER = 0;//              CMD[   46]//Rext range selection 
  //    wire                        DETECT_LEDs = 0;//              CMD[   45]
        wire                        detect_ctrl;    // = 0;//       CMD[   45]
        wire                        check_short;    // = 0;//       CMD[   44]Open detection / Short detection  LED Open or Short detection of all 48 current outputs 
        wire[                  1: 0]threshold_r;    // = 1;//       CMD[43:42]    1.5V+(threshold_b)*1.0V
        wire[                  3: 0]compenses_r = 0;//              CMD[41:38]
        wire[                  5: 0]currentse_r;    //3;//          CMD[37:32]
        wire                        uniformness = 0;//combine_pdm,//CMD[   31] uniformity  Combine 4 consecutive grayscale 
        wire                        det_current = 0;//error_check,//CMD[   30]
        wire[                  1: 0]detect_rank;    // = 1;//       CMD[29:28] //Error detection current of all 48 outputs (LED open detection: Vo=0) (LED short detection: Vo=voltage of current output) 
        wire[                  1: 0]threshold_g;    // = 2;//       CMD[27:26]    1.5V+(threshold_b)*1.0V
        wire[                  3: 0]compenses_g = 0;//              CMD[25:22] 
        wire[                  5: 0]currentse_g;    //0;//          CMD[21:16] 
        wire[                  3: 0]strobe_char = 4'b1001;//        CMD[15:12]    4'b1001,header_char,
        wire[                  1: 0]threshold_b;    //= 2;//        CMD[11:10]    1.5V+(threshold_b)*1.0V
        wire[                  3: 0]compenses_b = 0;//              CMD[ 9: 6]
        wire[                  5: 0]currentse_b;    //1;//          CMD[ 5: 0] 

*/





