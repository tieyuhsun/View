module  MY9758_register//
#(
//#1
    parameter   m1r15_15                                        =   0,
    parameter   m1r14_10_Scan_Number                            =   8,//0=1,8=9
    parameter   m1r_9__8_Steps_per_subseg                       =   2,
    parameter   m1r_7__6_Low_Grayscale_Uniformity_Enhancement   =   1,
    parameter   m1r_5__5                                        =   0,
    parameter   m1r_4__4_Grayscale_Selection                    =   1,
    parameter   m1r_3__3_Compensation_Time                      =   0,
    parameter   m1r_2__1                                        =   0,
    parameter   m1r_0__0_Double_Edge_GCK                        =   1,

    parameter   m1g15_12_Scan_mode                              =   0,
    parameter   m1g11__8_Scan_sequence                          =   0,
    parameter   m1g_7__6_B_adjust_coarse_compensation           =   0,
    parameter   m1g_5__4_R_adjust_fine_compensation             =   0,
    parameter   m1g_3__2_G_adjust_fine_compensation             =   0,
    parameter   m1g_1__0_B_adjust_fine_compensation             =   0,

    parameter   m1b15__8                                        =   0,
    parameter   m1b_7__6_R_adjust_coarse_compensation           =   0,
    parameter   m1b_5__4_G_adjust_coarse_compensation           =   0,
    parameter   m1b_3__0_GCK_watchdog                           =   0,

//#2    CMD2(R/G/B)：000000000000 -> 111000000000
    parameter   m2r15_12_Last_ghost                             =   1,
    parameter   m2r11__8_DeGhost_Time                           =   1,
    parameter   m2r_7__4_Compensation_Time                      =   1,// (LSB 4-bit) 
    parameter   m2r_3__2_Open_Fail_line                         =   0,
    parameter   m2r_1__0_R_Open_detection_level                 =   0,
    
    parameter   m2g15__2                                        =   0,
    parameter   m2g_1__0_G_Open_detection_level                 =   0,

    parameter   m2b15__2                                        =   0,
    parameter   m2b_1__0_B_Open_detection_level                 =   0,

//#3
    //16'h003F
    parameter   m3r15_14                                        =   0,
    parameter   m3r13_13_Sleep_mode                             =   0,
    parameter   m3r12_12_Dynamic_power_saving                   =   0,
    parameter   m3r11_11_Square_ghost                           =   0,
    parameter   m3r10_10_Current_Setting_1                      =   3,
    parameter   m3r_9__8_Current_Setting_2                      =   3,
    parameter   m3r_7__6_Fine_tune_3                            =   3,
    parameter   m3r_5__0_Current_Gain                           =   0,//63
    //16'h003F
    parameter   m3g15_14                                        =   0,
    parameter   m3g13_13_Sleep_mode                             =   0,
    parameter   m3g12_12_Dynamic_power_saving                   =   0,
    parameter   m3g11_11_Square_ghost                           =   0,
    parameter   m3g10_10_Current_Setting_1                      =   3,
    parameter   m3g_9__8_Current_Setting_2                      =   3,
    parameter   m3g_7__6_Fine_tune_3                            =   3,
    parameter   m3g_5__0_Current_Gain                           =   0,//63
    //16'h0024                                                  
    parameter   m3b15_14                                        =   0,
    parameter   m3b13_13_Sleep_mode                             =   0,
    parameter   m3b12_12_Dynamic_power_saving                   =   0,
    parameter   m3b11_11_Square_ghost                           =   0,
    parameter   m3b10_10_Current_Setting_1                      =   3,
    parameter   m3b_9__8_Current_Setting_2                      =   3,
    parameter   m3b_7__6_Fine_tune_3                            =   3,
    parameter   m3b_5__0_Current_Gain                           =   0,//36

//#4
    parameter   m4r15_14                                        =   1,
    parameter   m4r13_12_Current_Setting_3                      =   0,
    parameter   m4r11_11_Turn_on_mode                           =   0,
    parameter   m4r10__8_Low_Brightness_Compensation_coarse     =   0,
    parameter   m4r_7__0_Outputs_stagger_delay                  =   0,

    parameter   m4g15_14                                        =   1,
    parameter   m4g13_12_Current_Setting_3                      =   0,
    parameter   m4g11_11_Turn_on_mode                           =   0,
    parameter   m4g10__8_Low_Brightness_Compensation_coarse     =   0,
    parameter   m4g_7__0_Outputs_stagger_delay                  =   0,

    parameter   m4b15_14                                        =   1,
    parameter   m4b13_12_Current_Setting_3                      =   0,
    parameter   m4b11_11_Turn_on_mode                           =   0,
    parameter   m4b10__8_Low_Brightness_Compensation_coarse     =   0,
    parameter   m4b_7__0_Outputs_stagger_delay                  =   0,
//#5    CMD5(R/G/B)：8B01,A602,AD03
    //16'h8001
    parameter   m5r15_14                                        =   2'b10,
    parameter   m5r13__8_1st_Scan_Brightness_Compensation       =   6'b001011,
    parameter   m5r_7__4_Couple_Eliminate                       =   0,
    parameter   m5r_3__0_Next_ghost                             =   1,
    //16'h8001
    parameter   m5g15_14                                        =   2'b10,
    parameter   m5g13__8_1st_Scan_Brightness_Compensation       =   6'b100110,
    parameter   m5g_7__4_Couple_Eliminate                       =   0,
    parameter   m5g_3__0_Next_ghost                             =   2,
    //16'h8001
    parameter   m5b15_14                                        =   2'b10,
    parameter   m5b13__8_1st_Scan_Brightness_Compensation       =   6'b101101,
    parameter   m5b_7__4_Couple_Eliminate                       =   0,
    parameter   m5b_3__0_Next_ghost                             =   3,

//#6
    parameter   m6r15_14                                        =   3,
    parameter   m6r13_13_Compensation_mode                      =   0,
    parameter   m6r12_12_Couple_Eliminate_Enhancement           =   1,
    parameter   m6r11__8_Fine_tune_2                            =   0,
    parameter   m6r_7__6_Compensation_Capability                =   0,
    parameter   m6r_5__4_Fine_tune_1                            =   0,
    parameter   m6r_3__0_Low_Brightness_Compensation_fine       =   0,

    parameter   m6g15_14                                        =   3,
    parameter   m6g13_13_Compensation_mode                      =   0,
    parameter   m6g12_12_Couple_Eliminate_Enhancement           =   1,
    parameter   m6g11__8_Fine_tune_2                            =   0,
    parameter   m6g_7__6_Compensation_Capability                =   0,
    parameter   m6g_5__4_Fine_tune_1                            =   0,
    parameter   m6g_3__0_Low_Brightness_Compensation_fine       =   0,

    parameter   m6b15_14                                        =   3,
    parameter   m6b13_13_Compensation_mode                      =   0,
    parameter   m6b12_12_Couple_Eliminate_Enhancement           =   1,
    parameter   m6b11__8_Fine_tune_2                            =   0,
    parameter   m6b_7__6_Compensation_Capability                =   0,
    parameter   m6b_5__4_Fine_tune_1                            =   0,
    parameter   m6b_3__0_Low_Brightness_Compensation_fine       =   0,
//#7
    parameter   m7r15_15                                        =   m1r15_15                                        ,
    parameter   m7r14_10_Scan_Number                            =   m1r14_10_Scan_Number                            ,//0=1,8=9
    parameter   m7r_9__8_Steps_per_subseg                       =   m1r_9__8_Steps_per_subseg                       ,
    parameter   m7r_7__6_Low_Grayscale_Uniformity_Enhancement   =   m1r_7__6_Low_Grayscale_Uniformity_Enhancement   ,
    parameter   m7r_5__5                                        =   m1r_5__5                                        ,
    parameter   m7r_4__4_Grayscale_Selection                    =   m1r_4__4_Grayscale_Selection                    ,
    parameter   m7r_3__3_Compensation_Time                      =   m1r_3__3_Compensation_Time                      ,
    parameter   m7r_2__1                                        =   m1r_2__1                                        ,
    parameter   m7r_0__0_Double_Edge_GCK                        =   m1r_0__0_Double_Edge_GCK                        ,

    parameter   m7g15_12_Scan_mode                              =   m1g15_12_Scan_mode                    ,
    parameter   m7g11__8_Scan_sequence                          =   m1g11__8_Scan_sequence                ,
    parameter   m7g_7__6_B_adjust_coarse_compensation           =   m1g_7__6_B_adjust_coarse_compensation ,
    parameter   m7g_5__4_R_adjust_fine_compensation             =   m1g_5__4_R_adjust_fine_compensation   ,
    parameter   m7g_3__2_G_adjust_fine_compensation             =   m1g_3__2_G_adjust_fine_compensation   ,
    parameter   m7g_1__0_B_adjust_fine_compensation             =   m1g_1__0_B_adjust_fine_compensation   ,

    parameter   m7b15__8_Program_scan_sequence                  =   0,
    parameter   m7b_7__6_R_adjust_coarse_compensation           =   m1b_7__6_R_adjust_coarse_compensation ,
    parameter   m7b_5__4_G_adjust_coarse_compensation           =   m1b_5__4_G_adjust_coarse_compensation ,
    parameter   m7b_3__0_GCK_watchdog                           =   m1b_3__0_GCK_watchdog                 ,

//#8
    parameter   m8r15__0    =   0,
    parameter   m8g15__0    =   0,
    parameter   m8b15__0    =   0,

//#9
    parameter   m9r15__0    =   0,
    parameter   m9g15__0    =   0,
    parameter   m9b15__0    =   0
/**/

)(

/*
Iout(mA) =  (13*GAIN)/Rrext
GAIN = ( GCC[5:0]+1 ) / 64 (1.56%~100%)
*/
    input       [                 4:  0]scale_lines,//  16 ~ 1
    input       [                127: 0]gray_object,//<-mazes_chars
//
    input       [                 15: 0]shifter_bit,//<-mazes_chars
//
    input       [                  7: 0]currentse_r,//<-firmware
    input       [                  7: 0]currentse_g,//<-firmware
    input       [                  7: 0]currentse_b,//<-firmware
//
  //input                               scale_edges,//
  //input       [                  7: 0]scale_group,//
  //input       [                  7: 0]scale_lines,//
  //input       [                  7: 0]scale_front,//
  //input       [                  7: 0]scale_expon,//
  //input       [                  7: 0]scale_later,//
//
    output  wire[                 63: 0]config48bit
);
/*
CMD1(R/G/B)：225100000000
(scan 9 / 256 sub-seg / 16-bit / Double Edge GCK)
CMD2(R/G/B)：000000000000 -> 111100000000
CMD3(R/G/B)：003F003F003F
CMD5(R/G/B)：8B01A602AD03 (Default Value)
Tb約124.997ns /Tc約124.997ns

Steps per   step_subseg   +16+(8+4*RCMD2[11:8])+(6+2*(RCMD1[3],RCMD2[7:4]
            step_subseg
                64,512,256,128
            RCMD2[11:8] DeGhost Time
Steps_per_subseg 0  -> 64   (scale_expon==6)
Steps_per_subseg 1  -> 512  (scale_expon==9)
Steps_per_subseg 2  -> 256  (scale_expon==8)
Steps_per_subseg 3  -> 128  (scale_expon==7)
*/
            wire                        invert_step;
            wire                        scale_edges;
            wire[                 16: 0]scale_dimms;//
            wire[                  4: 0]scale_expon;//
assign  invert_step =  (gray_object[15: 0]>gray_object[31:16])||(gray_object[15: 0]==0);
assign  scale_edges =   gray_object[  119];//[127:120]frame
assign  scale_dimms =  (gray_object[15: 0]==0)?(1<<16):(invert_step?gray_object[15: 0]:gray_object[31:16]);
assign  scale_expon =   
       (scale_dimms==(1<<16) )  ?  16:
       (scale_dimms==(1<< 5) )  ?   5:
       (scale_dimms==(1<< 6) )  ?   6:
       (scale_dimms==(1<< 7) )  ?   7:
       (scale_dimms==(1<< 8) )  ?   8:
       (scale_dimms==(1<< 9) )  ?   9:
       (scale_dimms==(1<<10) )  ?  10:
       (scale_dimms==(1<<11) )  ?  11:
       (scale_dimms==(1<<12) )  ?  12:
       (scale_dimms==(1<<13) )  ?  13:
       (scale_dimms==(1<<14) )  ?  14:
       (scale_dimms==(1<<15) )  ?  15:0;


            wire[                  1: 0]step_subseg;
assign  step_subseg         =  (scale_expon==6)?0:
                       (scale_expon==9)?1:
                       (scale_expon==8)?2:
                       (scale_expon==7)?3:0;
            wire[                  2: 0]DeGhost_Time;
assign  DeGhost_Time        =   1;//8+4*DeGhostTime

            wire[                  4: 0]Compensation_Time;
assign  Compensation_Time   =   1;//6+2*Compensation_Time

            wire[                 63: 0]driver_data[15: 0];
            
//assign  config48bit =   driver_data[command_sel];//
assign  config48bit =   driver_data[shifter_bit[9:6]]>>shifter_bit[5:0];//


assign  driver_data[1][(48+15):(48+ 0)] =   0;

assign  driver_data[1][(32+15):(32+15)] =   m1r15_15                                        ;
assign  driver_data[1][(32+14):(32+10)] =  (scale_lines-1);//m1r14_10_Scan_Number                            ;//0=1,8=9
assign  driver_data[1][(32+ 9):(32+ 8)] =   step_subseg;//m1r_9__8_Steps_per_subseg                       ;
assign  driver_data[1][(32+ 7):(32+ 6)] =   m1r_7__6_Low_Grayscale_Uniformity_Enhancement   ;
assign  driver_data[1][(32+ 5):(32+ 5)] =   m1r_5__5                                        ;
assign  driver_data[1][(32+ 4):(32+ 4)] =   m1r_4__4_Grayscale_Selection                    ;
assign  driver_data[1][(32+ 3):(32+ 3)] =   Compensation_Time[4];//m1r_3__3_Compensation_Time                      ;
assign  driver_data[1][(32+ 2):(32+ 1)] =   m1r_2__1                                        ;
assign  driver_data[1][(32+ 0):(32+ 0)] =   scale_edges;//m1r_0__0_Double_Edge_GCK                        ;

assign  driver_data[1][(16+15):(16+12)] =   m1g15_12_Scan_mode                              ;
assign  driver_data[1][(16+11):(16+ 8)] =   m1g11__8_Scan_sequence                          ;
assign  driver_data[1][(16+ 7):(16+ 6)] =   m1g_7__6_B_adjust_coarse_compensation           ;
assign  driver_data[1][(16+ 5):(16+ 4)] =   m1g_5__4_R_adjust_fine_compensation             ;
assign  driver_data[1][(16+ 3):(16+ 2)] =   m1g_3__2_G_adjust_fine_compensation             ;
assign  driver_data[1][(16+ 1):(16+ 0)] =   m1g_1__0_B_adjust_fine_compensation             ;

assign  driver_data[1][( 0+15):( 0+ 8)] =   m1b15__8                                        ;
assign  driver_data[1][( 0+ 7):( 0+ 6)] =   m1b_7__6_R_adjust_coarse_compensation           ;
assign  driver_data[1][( 0+ 5):( 0+ 4)] =   m1b_5__4_G_adjust_coarse_compensation           ;
assign  driver_data[1][( 0+ 3):( 0+ 0)] =   m1b_3__0_GCK_watchdog                           ;

//
assign  driver_data[2][(48+15):(48+ 0)] =   0;

assign  driver_data[2][(32+15):(32+12)] =   m2r15_12_Last_ghost                             ;
assign  driver_data[2][(32+11):(32+ 8)] =   DeGhost_Time;//m2r11__8_DeGhost_Time                           ;
assign  driver_data[2][(32+ 7):(32+ 4)] =   Compensation_Time[3:0];//m2r_7__4_Compensation_Time                      ;
assign  driver_data[2][(32+ 3):(32+ 2)] =   m2r_3__2_Open_Fail_line                         ;
assign  driver_data[2][(32+ 1):(32+ 0)] =   m2r_1__0_R_Open_detection_level                 ;
    
assign  driver_data[2][(16+15):(16+ 2)] =   m2g15__2                                        ;
assign  driver_data[2][(16+ 1):(16+ 0)] =   m2g_1__0_G_Open_detection_level                 ;

assign  driver_data[2][( 0+15):( 0+ 2)] =   m2b15__2                                        ;
assign  driver_data[2][( 0+ 1):( 0+ 0)] =   m2b_1__0_B_Open_detection_level                 ;



//#3
assign  driver_data[3][(48+15):(48+ 0)] =   0;
    //16'h003F
assign  driver_data[3][(32+15):(32+14)] =   m3r15_14                     ;
assign  driver_data[3][(32+13):(32+13)] =   m3r13_13_Sleep_mode          ;
assign  driver_data[3][(32+12):(32+12)] =   m3r12_12_Dynamic_power_saving;
assign  driver_data[3][(32+11):(32+11)] =   m3r11_11_Square_ghost        ;
assign  driver_data[3][(32+10):(32+10)] =   m3r10_10_Current_Setting_1   ;
assign  driver_data[3][(32+ 9):(32+ 8)] =   m3r_9__8_Current_Setting_2   ;
assign  driver_data[3][(32+ 7):(32+ 6)] =   m3r_7__6_Fine_tune_3         ;
assign  driver_data[3][(32+ 5):(32+ 0)] =   currentse_r[7:2];//m3r_5__0_Current_Gain        ;
    //16'h003F
assign  driver_data[3][(16+15):(16+14)] =   m3g15_14                     ;
assign  driver_data[3][(16+13):(16+13)] =   m3g13_13_Sleep_mode          ;
assign  driver_data[3][(16+12):(16+12)] =   m3g12_12_Dynamic_power_saving;
assign  driver_data[3][(16+11):(16+11)] =   m3g11_11_Square_ghost        ;
assign  driver_data[3][(16+10):(16+10)] =   m3g10_10_Current_Setting_1   ;
assign  driver_data[3][(16+ 9):(16+ 8)] =   m3g_9__8_Current_Setting_2   ;
assign  driver_data[3][(16+ 7):(16+ 6)] =   m3g_7__6_Fine_tune_3         ;
assign  driver_data[3][(16+ 5):(16+ 0)] =   currentse_g[7:2];//m3g_5__0_Current_Gain        ;
    //16'h0024                                                  
assign  driver_data[3][( 0+15):( 0+14)] =   m3b15_14                     ;
assign  driver_data[3][( 0+13):( 0+13)] =   m3b13_13_Sleep_mode          ;
assign  driver_data[3][( 0+12):( 0+12)] =   m3b12_12_Dynamic_power_saving;
assign  driver_data[3][( 0+11):( 0+11)] =   m3b11_11_Square_ghost        ;
assign  driver_data[3][( 0+10):( 0+10)] =   m3b10_10_Current_Setting_1   ;
assign  driver_data[3][( 0+ 9):( 0+ 8)] =   m3b_9__8_Current_Setting_2   ;
assign  driver_data[3][( 0+ 7):( 0+ 6)] =   m3b_7__6_Fine_tune_3         ;
assign  driver_data[3][( 0+ 5):( 0+ 0)] =   currentse_b[7:2];//m3b_5__0_Current_Gain        ;

//#4
assign  driver_data[4][(48+15):(48+ 0)] =   0;

assign  driver_data[4][(32+15):(32+14)] =   m4r15_14                                        ;
assign  driver_data[4][(32+13):(32+12)] =   m4r13_12_Current_Setting_3                      ;
assign  driver_data[4][(32+11):(32+11)] =   m4r11_11_Turn_on_mode                           ;
assign  driver_data[4][(32+10):(32+ 8)] =   m4r10__8_Low_Brightness_Compensation_coarse     ;
assign  driver_data[4][(32+ 7):(32+ 0)] =   m4r_7__0_Outputs_stagger_delay                  ;

assign  driver_data[4][(16+15):(16+14)] =   m4g15_14                                        ;
assign  driver_data[4][(16+13):(16+12)] =   m4g13_12_Current_Setting_3                      ;
assign  driver_data[4][(16+11):(16+11)] =   m4g11_11_Turn_on_mode                           ;
assign  driver_data[4][(16+10):(16+ 8)] =   m4g10__8_Low_Brightness_Compensation_coarse     ;
assign  driver_data[4][(16+ 7):(16+ 0)] =   m4g_7__0_Outputs_stagger_delay                  ;

assign  driver_data[4][( 0+15):( 0+14)] =   m4b15_14                                        ;
assign  driver_data[4][( 0+13):( 0+12)] =   m4b13_12_Current_Setting_3                      ;
assign  driver_data[4][( 0+11):( 0+11)] =   m4b11_11_Turn_on_mode                           ;
assign  driver_data[4][( 0+10):( 0+ 8)] =   m4b10__8_Low_Brightness_Compensation_coarse     ;
assign  driver_data[4][( 0+ 7):( 0+ 0)] =   m4b_7__0_Outputs_stagger_delay                  ;
//#5
assign  driver_data[5][(48+15):(48+ 0)] =   0;
    //16'h8001
assign  driver_data[5][(32+15):(32+14)] =   m5r15_14                                        ;
assign  driver_data[5][(32+13):(32+ 8)] =   m5r13__8_1st_Scan_Brightness_Compensation       ;
assign  driver_data[5][(32+ 7):(32+ 4)] =   m5r_7__4_Couple_Eliminate                       ;
assign  driver_data[5][(32+ 3):(32+ 0)] =   m5r_3__0_Next_ghost                             ;
    //16'h8001
assign  driver_data[5][(16+15):(16+14)] =   m5g15_14                                        ;
assign  driver_data[5][(16+13):(16+ 8)] =   m5g13__8_1st_Scan_Brightness_Compensation       ;
assign  driver_data[5][(16+ 7):(16+ 4)] =   m5g_7__4_Couple_Eliminate                       ;
assign  driver_data[5][(16+ 3):(16+ 0)] =   m5g_3__0_Next_ghost                             ;
    //16'h8001
assign  driver_data[5][( 0+15):( 0+14)] =   m5b15_14                                        ;
assign  driver_data[5][( 0+13):( 0+ 8)] =   m5b13__8_1st_Scan_Brightness_Compensation       ;
assign  driver_data[5][( 0+ 7):( 0+ 4)] =   m5b_7__4_Couple_Eliminate                       ;
assign  driver_data[5][( 0+ 3):( 0+ 0)] =   m5b_3__0_Next_ghost                             ;

//#6
assign  driver_data[6][(48+15):(48+ 0)] =   0;
assign  driver_data[6][(32+15):(32+14)] =   m6r15_14                                        ;
assign  driver_data[6][(32+13):(32+13)] =   m6r13_13_Compensation_mode                      ;
assign  driver_data[6][(32+12):(32+12)] =   m6r12_12_Couple_Eliminate_Enhancement           ;
assign  driver_data[6][(32+11):(32+ 8)] =   m6r11__8_Fine_tune_2                            ;
assign  driver_data[6][(32+ 7):(32+ 6)] =   m6r_7__6_Compensation_Capability                ;
assign  driver_data[6][(32+ 5):(32+ 4)] =   m6r_5__4_Fine_tune_1                            ;
assign  driver_data[6][(32+ 3):(32+ 0)] =   m6r_3__0_Low_Brightness_Compensation_fine       ;

assign  driver_data[6][(16+15):(16+14)] =   m6g15_14                                        ;
assign  driver_data[6][(16+13):(16+13)] =   m6g13_13_Compensation_mode                      ;
assign  driver_data[6][(16+12):(16+12)] =   m6g12_12_Couple_Eliminate_Enhancement           ;
assign  driver_data[6][(16+11):(16+ 8)] =   m6g11__8_Fine_tune_2                            ;
assign  driver_data[6][(16+ 7):(16+ 6)] =   m6g_7__6_Compensation_Capability                ;
assign  driver_data[6][(16+ 5):(16+ 4)] =   m6g_5__4_Fine_tune_1                            ;
assign  driver_data[6][(16+ 3):(16+ 0)] =   m6g_3__0_Low_Brightness_Compensation_fine       ;

assign  driver_data[6][( 0+15):( 0+14)] =   m6b15_14                                        ;
assign  driver_data[6][( 0+13):( 0+13)] =   m6b13_13_Compensation_mode                      ;
assign  driver_data[6][( 0+12):( 0+12)] =   m6b12_12_Couple_Eliminate_Enhancement           ;
assign  driver_data[6][( 0+11):( 0+ 8)] =   m6b11__8_Fine_tune_2                            ;
assign  driver_data[6][( 0+ 7):( 0+ 6)] =   m6b_7__6_Compensation_Capability                ;
assign  driver_data[6][( 0+ 5):( 0+ 4)] =   m6b_5__4_Fine_tune_1                            ;
assign  driver_data[6][( 0+ 3):( 0+ 0)] =   m6b_3__0_Low_Brightness_Compensation_fine       ;
//#7
/*
assign  driver_data[7][(48+15):(48+ 0)] =   0;
assign  driver_data[7][(32+15):(32+15)] =   m7r15_15                                        ;
assign  driver_data[7][(32+14):(32+10)] =  (scale_lines-1);//m7r14_10_Scan_Number                            ;
assign  driver_data[7][(32+ 9):(32+ 8)] =   step_subseg;//m7r_9__8_Steps_per_subseg                       ;
assign  driver_data[7][(32+ 7):(32+ 6)] =   m7r_7__6_Low_Grayscale_Uniformity_Enhancement   ;
assign  driver_data[7][(32+ 5):(32+ 5)] =   m7r_5__5                                        ;
assign  driver_data[7][(32+ 4):(32+ 4)] =   m7r_4__4_Grayscale_Selection                    ;
assign  driver_data[7][(32+ 3):(32+ 3)] =   m7r_3__3_Compensation_Time                      ;
assign  driver_data[7][(32+ 2):(32+ 1)] =   m7r_2__1                                        ;
assign  driver_data[7][(32+ 0):(32+ 0)] =   scale_edges;//m7r_0__0_Double_Edge_GCK                        ;

assign  driver_data[7][(16+15):(16+12)] =   m7g15_12_Scan_mode                              ;
assign  driver_data[7][(16+11):(16+ 8)] =   m7g11__8_Scan_sequence                          ;
assign  driver_data[7][(16+ 7):(16+ 6)] =   m7g_7__6_B_adjust_coarse_compensation           ;
assign  driver_data[7][(16+ 5):(16+ 4)] =   m7g_5__4_R_adjust_fine_compensation             ;
assign  driver_data[7][(16+ 3):(16+ 2)] =   m7g_3__2_G_adjust_fine_compensation             ;
assign  driver_data[7][(16+ 1):(16+ 0)] =   m7g_1__0_B_adjust_fine_compensation             ;

assign  driver_data[7][( 0+15):( 0+ 8)] =   m7b15__8_Program_scan_sequence                  ;
assign  driver_data[7][( 0+ 7):( 0+ 6)] =   m7b_7__6_R_adjust_coarse_compensation           ;
assign  driver_data[7][( 0+ 5):( 0+ 4)] =   m7b_5__4_G_adjust_coarse_compensation           ;
assign  driver_data[7][( 0+ 3):( 0+ 0)] =   m7b_3__0_GCK_watchdog                           ;
*/
assign  driver_data[7]  =   driver_data[1];
//#8
assign  driver_data[8][(48+15):(48+ 0)] =   0;
assign  driver_data[8][(32+15):(32+ 0)] =   m8r15__0;
assign  driver_data[8][(16+15):(16+ 0)] =   m8g15__0;
assign  driver_data[8][( 0+15):( 0+ 0)] =   m8b15__0;

//#9
assign  driver_data[9][(48+15):(48+ 0)] =   0;
assign  driver_data[9][(32+15):(32+ 0)] =   m9r15__0;
assign  driver_data[9][(16+15):(16+ 0)] =   m9g15__0;
assign  driver_data[9][( 0+15):( 0+ 0)] =   m9b15__0;

assign  driver_data[10] =   0;
assign  driver_data[11] =   0;
assign  driver_data[12] =   0;
assign  driver_data[13] =   0;
assign  driver_data[14] =   0;
assign  driver_data[15] =   0;






endmodule