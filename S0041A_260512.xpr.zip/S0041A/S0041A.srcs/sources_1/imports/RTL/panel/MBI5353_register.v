module  MBI5353_register//
#(

    parameter   minimum_exp =   3

/**/

)(

//MBI5353

//Definition of Global Configuration Register 1 
    input       [               4   : 0]expon_sigma,//[D:C] Grayscale mode select 
    
    input       [               4   : 0]expon_delta,//[B:A] S-PWM mode

    input       [               4   : 0]line_number,//[9:5] Number of scan lines 

    input                               double_gclk,//[  4] GCLK multiplier 
//Definition of Global Configuration Register 2 
    input                               check_short,//[  B] R EXT  short detection enable 
    //Iout = ((0.6/Rext)*gain1*gain2)*[R/G/B]/128
    input       [               1   : 0]GlobalGain1,//[A:9] Global current gain (Constant gain ) 

    input       [               2   : 0]GlobalGain2,//[8:6] Global current gain (Adjustable gain ) 
//Definition of Global Configuration Register 3 
  //input                               blackcharge,//Black screen pre-charge 


//Definition of R/G/B Individual Configuration Register 1 
  //input       [               7   : 0]currentse_r,//[8:2] Current gain adjustment*
  //input       [               7   : 0]currentse_g,
  //input       [               7   : 0]currentse_b,
    input       [               23  : 0]driver_gain,//<-spi.fw
/**/
    input       [               15  : 0]shifter_bit,   

    output  wire[               63  : 0]driver_code
);







//MBI5353    
            wire[                 1:  0]reg_b15_b14[2:0];   //  Shift   GCLK
            wire                   [2:0]reg_b13_b13;        //  keep"0"
            wire[                 1:  0]reg_b12_b11[2:0];   //  Select pre-charge mode 
            wire                   [2:0]reg_b10_b10;        //  Color shift compensation [A] 
            wire[                 5:  0]reg_b09_b04[2:0];   //  Current gain adjustment 
            wire                  [ 2:0]reg_b03_b03;        //  GCLK rising/falling edge trigger 
/**/
            wire                  [ 1:0]reg_1_hf_he;        //  mark
            wire                  [ 1:0]reg_1_hd_hc;        //  pwm-gray
            wire                  [ 1:0]reg_1_hb_ha;        //  pwm-
            wire                  [ 4:0]reg_1_h9_h5;        //  duty
            wire                        reg_1_h4_h4;        //  GCLK multiplier
            wire                  [ 3:0]reg_1_h3_h0;        //  Reserved ??  keep"0"
/*
Stagger delay
    00: no stagger
    01: 
        Red color group lead Green color group 25ns 
        Green color group lead Blue color group 25ns 
    10: 
        Red color group lead Green color group 50ns 
        Green color group lead Blue color group 50ns 
    11: 
        Red color group lead Green color group 75ns 
        Green color group lead Blue color group 75ns 
*/
            wire                  [ 3:0]reg_2_hf_hc;        //  Reserved
            wire                        reg_2_hb_hb;        //  R EXT  short detection enable 
            wire                  [ 1:0]reg_2_ha_h9;        //  Global Current Gain1    16 | 48
            wire                  [ 2:0]reg_2_h8_h6;        //  Global Current Gain2    100~200%   (100%/7)
            wire                        reg_2_h5_h5;        //  Reserved
            wire                  [ 1:0]reg_2_h4_h3;        //  Stagger delay 
            wire                  [ 1:0]reg_2_h2_h1;        //  Reserved
            wire                        reg_2_h0_h0;        //  Power saving mode
/**/
            wire                  [ 4:0]reg_3_hf_hb;        //  Reserved ??  keep"0"
            wire                        reg_3_ha_ha;        //  Black screen pre-charge 
            wire                  [ 9:0]reg_3_h9_h0;        //  Reserved ??  keep"0"
/**/
            wire                  [ 1:0]rgb_1_hf_he[2:0];   //  mark
            wire                  [ 3:0]rgb_1_hd_ha[2:0];   //  Reserved ??
            wire                  [ 2:0]rgb_1_h9_h9;        //  Reserved
            wire                  [ 6:0]rgb_1_h8_h2[2:0];   //  Current gain adjustment*    
            wire                  [ 1:0]rgb_1_h1_h0[2:0];   //  Reserved
            wire                  [15:0]rgb_2_hf_h0[2:0];   //  ??
            wire                  [15:0]rgb_3_hf_h0[2:0];   //  ??  keep"0"


assign  reg_1_hf_he     =   2'b00;                  //  mark

                            //2'b11;    //  13b | 14b | 15b | 16b   {2'b11,2'b10,2'b01,2'b00}pwm-gray
assign  reg_1_hd_hc     =  (expon_sigma==16)?0:
                           (expon_sigma==15)?1:
                           (expon_sigma==14)?2:
                           (expon_sigma==13)?3:3;
                            //2'b01;    //  128 | 256 | 512 | 1024  {2'b11,2'b10,2'b01,2'b00}
assign  reg_1_hb_ha     =  (expon_delta==10)?0:
                           (expon_delta== 9)?1:
                           (expon_delta== 8)?2:
                           (expon_delta== 7)?3:3;
assign  reg_1_h9_h5     =   line_number;//5'b01111; //duty_limits;        //  duty
assign  reg_1_h4_h4     =   double_gclk;//1'b1;     //  ddr GCLK multiplier
assign  reg_1_h3_h0     =   4'b0100;                //  Reserved ??  keep"0"

assign  reg_2_hf_hc     =   3'b000;                 //  Reserved
assign  reg_2_hb_hb     =   check_short;//1'b0;     //  R EXT  short detection enable 
assign  reg_2_ha_h9     =   GlobalGain1;//2'b01;    //  Global Current Gain1 
assign  reg_2_h8_h6     =   GlobalGain2;//3'b111;   //  Global Current Gain2 
assign  reg_2_h5_h5     =   1'b1;                   //  Reserved
assign  reg_2_h4_h3     =   2'b00;                  //  Stagger delay 
assign  reg_2_h2_h1     =   2'b00;                  //  Reserved
assign  reg_2_h0_h0     =   1'b0;                   //  Power saving mode
            
assign  reg_3_hf_hb     =   0;
assign  reg_3_ha_ha     =   0;
assign  reg_3_h9_h0     =   0;

assign  rgb_1_hf_he[0]  = 2'b01;                assign  rgb_1_hf_he[1]  = 2'b10;                assign  rgb_1_hf_he[2]  = 2'b11;
assign  rgb_1_hd_ha[0]  = 4'b0010;              assign  rgb_1_hd_ha[1]  = 4'b0010;              assign  rgb_1_hd_ha[2]  = 4'b0010;
assign  rgb_1_h9_h9[0]  = 1'b1;                 assign  rgb_1_h9_h9[1]  = 1'b1;                 assign  rgb_1_h9_h9[2]  = 1'b1;
assign  rgb_1_h8_h2[0]  = driver_gain[ 7: 1];   assign  rgb_1_h8_h2[1]  = driver_gain[15: 9];   assign  rgb_1_h8_h2[2]  = driver_gain[23:17];
assign  rgb_1_h1_h0[0]  = 2'b11;                assign  rgb_1_h1_h0[1]  = 2'b11;                assign  rgb_1_h1_h0[2]  = 2'b11;

assign  rgb_2_hf_h0[0]  =16'b0000111000111000;  assign  rgb_2_hf_h0[1]  =16'b0000010100110111;  assign  rgb_2_hf_h0[2]  =16'b0000100100101000;
assign  rgb_3_hf_h0[0]  = 0;                    assign  rgb_3_hf_h0[1]  = 0;                    assign  rgb_3_hf_h0[2]  = 0;


/**/
            wire[                 63: 0]CONCATENATE[3:0];//15..0..-3

assign  CONCATENATE[0]  =   
                               {
                                reg_1_hf_he,        //  mark
                                reg_1_hd_hc,        //  pwm-gray
                                reg_1_hb_ha,        //  pwm-
                                reg_1_h9_h5,        //  duty
                                reg_1_h4_h4,        //  GCLK multiplier
                                reg_1_h3_h0,        //  Reserved ??  keep"0"

                                reg_2_hf_hc,        //  Reserved
                                reg_2_hb_hb,        //  R EXT  short detection enable 
                                reg_2_ha_h9,        //  Global Current Gain1    16 | 48
                                reg_2_h8_h6,        //  Global Current Gain2    100~200%   (100%/7)
                                reg_2_h5_h5,        //  Reserved
                                reg_2_h4_h3,        //  Stagger delay 
                                reg_2_h2_h1,        //  Reserved
                                reg_2_h0_h0,        //  Power saving mode

                                reg_3_hf_hb,        //  Reserved ??  keep"0"
                                reg_3_ha_ha,        //  Black screen pre-charge 
                                reg_3_h9_h0         //  Reserved ??  keep"0"
                                };
assign  CONCATENATE[1]  =   
                               {
                                rgb_1_hf_he[0],
                                rgb_1_hd_ha[0],
                                rgb_1_h9_h9[0],
                                rgb_1_h8_h2[0],
                                rgb_1_h1_h0[0],
                                rgb_2_hf_h0[0],
                                rgb_3_hf_h0[0]
                               };
assign  CONCATENATE[2]  =   
                               {
                                rgb_1_hf_he[1],
                                rgb_1_hd_ha[1],
                                rgb_1_h9_h9[1],
                                rgb_1_h8_h2[1],
                                rgb_1_h1_h0[1],
                                rgb_2_hf_h0[1],
                                rgb_3_hf_h0[1]
                               };
assign  CONCATENATE[3]  =   
                               {
                                rgb_1_hf_he[2],
                                rgb_1_hd_ha[2],
                                rgb_1_h9_h9[2],
                                rgb_1_h8_h2[2],
                                rgb_1_h1_h0[2],
                                rgb_2_hf_h0[2],
                                rgb_3_hf_h0[2]
                               };




assign  driver_code =  {CONCATENATE[3],CONCATENATE[2],CONCATENATE[1],CONCATENATE[0]}>>((shifter_bit>>minimum_exp)<<minimum_exp);
//assign  setup_led_a =   CONCATENATE[0];
//assign  setup_led_r =   CONCATENATE[1];//>>shifter_bit;//(shifter_bit==16)?CONCATENATE[0][31:16]:CONCATENATE[0][15: 0];//(CONCATENATE[0]>>shifter_bit);
//assign  setup_led_g =   CONCATENATE[2];//>>shifter_bit;//(shifter_bit==16)?CONCATENATE[1][31:16]:CONCATENATE[1][15: 0];//(CONCATENATE[1]>>shifter_bit);
//assign  setup_led_b =   CONCATENATE[3];//>>shifter_bit;//(shifter_bit==16)?CONCATENATE[2][31:16]:CONCATENATE[2][15: 0];//(CONCATENATE[2]>>shifter_bit);


endmodule