module  maze_transport
#(

    parameter   chars_pixel     =   0,
    parameter   chars_initi     =   1,
    parameter   chars_latch     =   2,
    parameter   chars_pause     =   3,

    parameter   [7:0]expon_field[1:0]=   { 8'h02, 8'h02},
    parameter   expon_steps     =   4//demux,   expon_steps

  //parameter   hight_expon     =   9, //512
  //parameter   width_expon     =   9  //512


)(


    output  reg                         demux_bidir,
    output  reg                         demux_break,
    output  reg                         demux_latch,//
    output  reg [    (expon_steps+7): 0]demux_cycle,//

//
    input       [               23  : 0]steps_range,
//
    input       [               17  : 0]mazes_chars,
  //input                               mazes_blank,
    input       [               2   : 0]mazes_syncs,
    input       [               2   : 0]mazes_reset,
//
    input                               refer_clock
);
/*
    
    1. delta        =   steps_range/coefs
    2. steps_range  =   delta*coefs
            delta.carry =  (delta.coont == coefs)
            sigma.count =   sigma.count+delta.carry;//->87

*/

            wire[               1   : 0]mazes_scrip;
            wire[               7   : 0]mazes_coefs[1:0];
          //wire                        mazes_pixel;//
          //wire                        mazes_initi;//
          //wire                        mazes_latch;//
          //wire                        mazes_pause;//

//
            reg [               17  : 0]slide_chars;
            wire[               1   : 0]slide_scrip;
assign  mazes_scrip     =  {mazes_chars[17],mazes_chars[16]};
assign  mazes_coefs[1]  =   mazes_chars[15: 8];//ars[14: 8];
assign  mazes_coefs[0]  =   mazes_chars[ 7: 0];
//assign  mazes_blank     =  (mazes_scrip==chars_pause)&&(&mazes_coefs[1])&&(&mazes_coefs[0])&&
//                           (slide_scrip==chars_latch);
always@(posedge refer_clock)slide_chars <=  mazes_syncs[2]?mazes_chars:slide_chars;
assign  slide_scrip     =  {slide_chars[17],slide_chars[16]};

    parameter   pad_dir_get =  {(expon_field[1]+expon_field[0]){1'b1}};
    parameter   pad_dir_set =   0;


            reg                         cycle_blank;//
always@(posedge refer_clock)
    if( mazes_syncs[0])
        if( mazes_reset==2)
            cycle_blank <=  0;
        else
            cycle_blank <=  cycle_blank||((&mazes_coefs[1])&&(&mazes_coefs[0])&&(mazes_scrip==chars_pause)&&(slide_scrip==chars_latch));
    else
            cycle_blank <=  cycle_blank;

            reg [               7   : 0]limit_latch;//limit_latch 
            reg [               7   : 0]limti_shift[1:0];//limti_shift
            reg [               7   : 0]cycle_latch;//cycle_latch
            reg [               7   : 0]cycle_shift;//
            reg                         close_latch;
            reg                         close_shift;
            wire                        cycle_bidir =((limit_latch==pad_dir_set)?0:(limit_latch==pad_dir_get));
always@(posedge refer_clock)
    if( mazes_syncs[0])
        if( mazes_scrip==chars_pause)
        begin
            limti_shift[0]  <=  mazes_coefs[0][(8-expon_field[0])-1:0];
            limti_shift[1]  <=  mazes_coefs[1][(8-expon_field[1])-1:0];
            limit_latch     <= (mazes_coefs[0]>>(8-expon_field[0]))+((mazes_coefs[1]>>(8-expon_field[1]))<<expon_field[0]);//{mazes_coefs[1]>>(7-(expon_field>>1)),(mazes_coefs[0]>>(7-(expon_field>>1)))};
            close_latch     <=  1;
            close_shift     <=  1;
            cycle_shift     <=  0;
            cycle_latch     <=  0;
        end
        else
        if( mazes_scrip==chars_initi)
        begin
            limti_shift[0]  <=  limti_shift[0];
            limti_shift[1]  <=  limti_shift[1];
            limit_latch     <=  limit_latch;
            close_latch     <=  1;
            close_shift     <=  0;
            cycle_shift     <=  limti_shift[1];
            cycle_latch     <=  0;
        end
        else
        if( mazes_scrip==chars_pixel)
        begin
            limti_shift[0]  <=  limti_shift[0];
            limti_shift[1]  <=  limti_shift[1];
            limit_latch     <=  limit_latch;
            close_latch     <=  1;
            close_shift     <=  0;
            cycle_shift     <=  limti_shift[0];
            cycle_latch     <=  0;
        end
        else
        if( mazes_scrip==chars_latch)
        begin
            limti_shift[0]  <=  limti_shift[0];
            limti_shift[1]  <=  limti_shift[1];
            limit_latch     <=  limit_latch;
            close_latch     <= (slide_scrip==chars_pause)?  0://
                               (slide_scrip==chars_latch)?  1:
                               (slide_scrip==chars_pixel)?  0:
                               (slide_scrip==chars_initi)?  0:
                                                            close_latch;

            close_shift     <= (slide_scrip==chars_pause)?  0://
                               (slide_scrip==chars_latch)?  1://
                               (slide_scrip==chars_pixel)?(((limit_latch==pad_dir_get)||(limit_latch==pad_dir_set))?1:0):
                               (slide_scrip==chars_initi)?(((limit_latch==pad_dir_get)||(limit_latch==pad_dir_set))?1:0):
                                                            close_shift;

            cycle_shift     <= (slide_scrip==chars_pause)?  limti_shift[1]:
                               (slide_scrip==chars_latch)?  0:
                               (slide_scrip==chars_pixel)?  limti_shift[0]:
                               (slide_scrip==chars_initi)?  limti_shift[1]:
                                                            cycle_shift;
                               
            cycle_latch     <= (slide_scrip==chars_latch)?  0:
                               (limit_latch==pad_dir_get)?  0:
                               (limit_latch==pad_dir_set)?  1:
                                                            limit_latch;
        end
        else
        begin
            limti_shift[0]  <=  limti_shift[0];
            limti_shift[1]  <=  limti_shift[1];
            limit_latch     <=  limit_latch;
            close_latch     <=  close_latch;
            close_shift     <=  close_shift;
            cycle_shift     <=  cycle_shift;
            cycle_latch     <=  cycle_latch;
        end
    else
        begin
            limti_shift[0]  <=  limti_shift[0];
            limti_shift[1]  <=  limti_shift[1];
            limit_latch     <=  limit_latch;
            close_latch     <=  close_latch;
            close_shift     <=  close_shift;
            cycle_shift     <=  cycle_shift;
            cycle_latch     <=  cycle_latch;
        end
/*
    Digital Differential Analyzer
        steps_range/cycle_shift
        
        
        steps_range.maximum
        125M/30/1024=4096 = 12b


*/

  //parameter   expon_sigam     =  (9+expon_steps);////6b

            
            reg [               24  : 0]delta_sigma;initial delta_sigma = 0;//
            reg [               7   : 0]delta_cycle;

            reg [               7   : 0]demux_label;

always@(posedge refer_clock)
    if( mazes_syncs[2])
    begin
        delta_sigma <= (steps_range-(cycle_shift<<(expon_steps+0)));
        delta_cycle <=  cycle_shift;//
//
        demux_bidir <=  cycle_bidir;
        demux_break <=  cycle_blank?1:close_shift;//
        demux_cycle <=((cycle_shift<<expon_steps)-1);//
        demux_label <=  close_latch?0:cycle_latch;//
        demux_latch <=  0;
    end
    else
    if( delta_sigma[(9+expon_steps)])
    begin
        delta_sigma <=((delta_sigma-(delta_cycle<<(expon_steps+0)))+steps_range);//
        delta_cycle <=  delta_cycle;//
//
        demux_bidir <=  demux_bidir;
        demux_break <= (demux_cycle==0)?1:demux_break;
        demux_cycle <= (demux_cycle-(!demux_break));//
        demux_label <=  demux_label;//
        demux_latch <=((demux_label<<expon_steps)>=(demux_cycle<<0));
    end
    else
    begin
        delta_sigma <= (delta_sigma-(delta_cycle<<(expon_steps+0)));//
        delta_cycle <=  delta_cycle;//
//
        demux_bidir <=  demux_bidir;
        demux_break <=  demux_break;//
        demux_cycle <=  demux_cycle;//
        demux_label <=  demux_label;//
        demux_latch <=  demux_latch;
    end



//assign  mazes_demux =   demux_cycle|(demux_bidir<<(expon_steps+7));//
/*
(cache_scrip==chars_pause)&&(&cache_coefs[1])&&(&cache_coefs[0]);//&&(&cache_coefs[0]);//&&(&target_maze[ 6: 0]);//

    scrip.pause + 16b
    
                    scrip.pause         scrip.latch         scrip.initi         scrip.pixel

        Latch CMD   [15: 8] 1~32        CK.CMD              N/A                 N/A

            DCK MUX [ 5: 0] 0~63        initi|pixel         CK.MUX              CK.MUX

        Latch       [15: 8] 0           Latch(length undef) N/A                 N/A

            DCK MUX [ 5: 0] 0~63        N/A                 CK.MUX              CK.MUX


                    6b = 64DCK
                    6b,6b,4b
                    6b,5b,5b
                    
                    MBI5353 : 14 Latch.CMD
                    
                    f   e   d   c   b   a   9   8   7   6   5   4   3   2   1   0
                  [ 3           0][ 3           0]         [ 5                   0]
                    CK/SWP          CMD
                    
*/


endmodule
