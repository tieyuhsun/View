module  chip_driver
#(
//
    parameter   decode_line     =   7'h7c


)(


    input       [               15  : 0]shifter_bit,
/*

    gray.13b    =   delta.9b  + sigma.4b    ,
    
    
*/
    input                               double_gclk,//[  4] GCLK multiplier 
    input       [               4   : 0]expon_delta,//
    input       [               7   : 0]space_delta,
    input       [               4   : 0]expon_sigma,//
    input       [               7   : 0]space_sigma,
    input       [               7   : 0]line_number,//Number of scan lines 
//
    input       [               7   : 0]frame_tasks,//error report
//
    input       [               1   : 0]GlobalGain1,//[A:9] Global current gain (Constant gain ) 
    input       [               2   : 0]GlobalGain2,//[8:6] Global current gain (Adjustable gain ) 
    input       [               23  : 0]driver_gain,//<-spi.fw
//
    input       [               15  : 0]driver_pick,
//
    output  wire[               63  : 0]driver_code //driver    DAC
);
/*


*/

            wire[               63  : 0]driver_data[9999:0];

/*
            reg [                  6: 0]scale_lines;//
            wire[                  7: 0]scale_expon;//
always@(posedge refer_clock)scale_lines <= (mazes_syncs[1]&&scale_pause&&(scale_chars[14: 8]==decode_line))?scale_chars[ 6: 0]:scale_lines;



            wire[                 63: 0]driver_data[10000:0];//
    MY9373_register 
    MY9373_register (
        .   scale_lines             (   scale_lines), 
        .   gray_object             (   gray_object), 
        .   shifter_bit             (  {mazes_coefs[1][6:0],4'b0000}), //16bit
        .   currentse_r             (   driver_gain[0]), 
        .   currentse_g             (   driver_gain[1]), 
        .   currentse_b             (   driver_gain[2]), 
        .   config48bit             (   driver_data[9373]));
    MY9758_register 
    MY9758_register (
        .   scale_lines             (   scale_lines), 
        .   gray_object             (   gray_object), 
        .   shifter_bit             (  {mazes_coefs[1][6:0],6'b000000}), //64bit
        .   currentse_r             (   driver_gain[0]), 
        .   currentse_g             (   driver_gain[1]), 
        .   currentse_b             (   driver_gain[2]), 
        .   config48bit             (   driver_data[9758]));
*/


    MBI5353_register 
    MBI5353_register (
        .   double_gclk             (   double_gclk),//[  4] GCLK multiplier 
        .   expon_sigma             (   expon_sigma),//[D:C] Grayscale mode select 
        .   expon_delta             (   expon_delta),//[B:A] S-PWM mode
        .   line_number             (   line_number),//[9:5] Number of scan lines 
      //.   check_short             (  (frame_tasks==1)),//frame_tasks[0]//[  B] R EXT  short detection enable 
        .   check_short             (   0),//frame_tasks[0]//[  B] R EXT  short detection enable 
        .   GlobalGain1             (   GlobalGain1),//[A:9] Global current gain (Constant gain ) 
        .   GlobalGain2             (   GlobalGain2),//[8:6] Global current gain (Adjustable gain ) 
        .   driver_gain             (   driver_gain),//[8:2] Current gain adjustment*
        .   shifter_bit             (   shifter_bit),
        .   driver_code             (   driver_data[5353]));




assign  driver_code =   driver_data[driver_pick];//


endmodule
