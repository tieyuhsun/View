module  momory_demux//mazes_multitask//memory_distribution//stay alone    momory_demux
#(
    parameter   chars_pixel     =   0,
    parameter   chars_initi     =   1,
    parameter   chars_latch     =   2,
    parameter   chars_pause     =   3,
//
    parameter   ports_expon     =   3
)(
    input       [                  7: 0]half_period,
//
    input       [                  7: 0]bright_lv10,//->memory_distr    spi.fw
    input       [                 23: 0]bright_data,//->memory_distr    spi.fw
    input       [                  7: 0]gamma_table,
    input                               correct_ena,//->memory_distr    spi.fw
    input                               pattern_ena,//->memory_distr    spi.fw
    input       [                  23:0]pattern_dat,//->memory_distr    spi.fw
//
    input       [                 1:  0]coeffis_det,//
    input                               coeffis_set,//cpu.w
    input                               coeffis_get,//cpu.r
    input                               coeffis_stb,
    input       [                15:  0]coeffis_row,//
    input       [                15:  0]coeffis_col,//
    input       [                 7:  0]coeffis_xyz,//
    input       [                 7:  0]coeffis_bit,//b[6],g[5],r[4],gray[3:0]
//
    input                               memory_sync,
    input       [                  1: 0]memory_load,
    input       [                  7: 0]memory_port,//s_expon
    input       [                 15: 0]mazes_catch,//
    input       [                 47: 0]mazes_setup,//
    input       [( 1<<ports_expon)-1: 0]mazes_blank,
    input       [(16<<ports_expon)-1: 0]mazes_chars,
    input       [                  1: 0]mazes_syncs,
    input                               mazes_reset,
//
    output  reg [( 1<<ports_expon)-1: 0]panel_blank,
    output  reg [( 4<<ports_expon)-1: 0]panel_knitr,
    output  reg [( 2<<ports_expon)-1: 0]panel_latch,
    output  reg [( 2<<ports_expon)-1: 0]panel_clock,
//
  //output  reg [( 4<<ports_expon)-1: 0]panel_dotx2,
//
    input                               refer_ready,
    input                               refer_clock
);

/*
    byte[0]         byte[1]         byte[2]         byte[3]         byte[4]         byte[5]

    0x07/0x06       row[15: 8]      row[ 7: 0]      col[15: 8]      col[ 7: 0]++
    0x05/0x04       row[15: 8]      col[15: 8]      row[ 7: 0]      col[ 7: 0]      xyz++
    0x03/0x02       CMD             addr++
*/

          //reg [                  4: 0]coeffis_tab;//
            reg [                  1: 0]coeffis_rgb;//
            reg                         coeffis_48b;//coeffis_det
            reg                         coeffis_use;
            reg [                 47: 0]coeffis_buf;//16*3
            wire[                 47: 0]coeffis_net;
            reg                         coeffis_wex;
always@(posedge refer_clock)coeffis_use <=(coeffis_row==16'h00ff)&&( coeffis_col[15:11]==0)&&(&coeffis_col[ 7: 0])&&(coeffis_det==1);//
always@(posedge refer_clock)
    if( coeffis_xyz[4:0]>=18)
    begin
        coeffis_48b <=  0;//
        coeffis_rgb <=  3;
    end
    else
    if( coeffis_xyz[4:0]>=12)
    begin
        coeffis_48b <=  coeffis_use&&coeffis_set&&(coeffis_xyz[4:0]==17);//12..17 -> 16..21
        coeffis_rgb <=  2;
    end
    else
    if( coeffis_xyz[4:0]>=6)
    begin
        coeffis_48b <=  coeffis_use&&coeffis_set&&(coeffis_xyz[4:0]==11);//6..11 -> 8..13
        coeffis_rgb <=  1;
    end
    else
    begin
        coeffis_48b <=  coeffis_use&&coeffis_set&&(coeffis_xyz[4:0]== 5);//0..5 -> 0..5
        coeffis_rgb <=  0;
    end
//

always@(posedge refer_clock)coeffis_buf     <=  coeffis_stb?{coeffis_buf,coeffis_bit}:coeffis_buf;
assign  coeffis_net[15: 0]  =   coeffis_buf[47:32];
assign  coeffis_net[31:16]  =   coeffis_buf[31:16];
assign  coeffis_net[47:32]  =   coeffis_buf[15: 0];
always@(posedge refer_clock)coeffis_wex     <= (coeffis_stb&&coeffis_48b);//            









            reg [                  7: 0]bright_code[3:0];
            reg                         pattern_run;
            reg                         correct_run;
//always@(posedge refer_clock)bright_code[0]  <=  bright_data[ 7: 0];//frame_blank ?   bright_data[ 7: 0]  :bright_code[0];
//always@(posedge refer_clock)bright_code[1]  <=  bright_data[15: 8];//frame_blank ?   bright_data[15: 8]  :bright_code[1];
//always@(posedge refer_clock)bright_code[2]  <=  bright_data[23:16];//frame_blank ?   bright_data[23:16]  :bright_code[2];

always@(posedge refer_clock)bright_code[0]  <=  mazes_reset?bright_data[ 7: 0]:bright_code[0];//frame_blank ?   bright_data[ 7: 0]  :bright_code[0];
always@(posedge refer_clock)bright_code[1]  <=  mazes_reset?bright_data[15: 8]:bright_code[1];//frame_blank ?   bright_data[15: 8]  :bright_code[1];
always@(posedge refer_clock)bright_code[2]  <=  mazes_reset?bright_data[23:16]:bright_code[2];//frame_blank ?   bright_data[23:16]  :bright_code[2];
always@(posedge refer_clock)bright_code[3]  <=  mazes_reset?bright_lv10       :bright_code[3];//frame_blank ?   bright_lv10         :bright_code[3];
always@(posedge refer_clock)pattern_run     <=  mazes_reset?pattern_ena       :pattern_run   ;
always@(posedge refer_clock)correct_run     <=  mazes_reset?correct_ena       :correct_run   ;



            reg [                 15: 0]mazes_word0;
always@(posedge refer_clock)mazes_word0 <=  mazes_catch;

            reg                         pixel_write;
            reg [   ports_expon-1   : 0]pixel_ports;
            reg [                 23: 0]pixel_value;
always@(posedge refer_clock)pixel_write <= (&memory_load)&&(memory_sync);//
always@(posedge refer_clock)pixel_ports <=  memory_port;//
always@(posedge refer_clock)
    if( pattern_run)
        pixel_value <=  pattern_dat;//
    else
        if(&memory_load)
            if( memory_sync)
                pixel_value <= {mazes_catch,pixel_value[15: 0]};//
            else
                pixel_value <= {pixel_value[23:16],mazes_catch};//
        else
                pixel_value <=  pixel_value;//


//            wire[                 31: 0]pixel_value;
//assign  pixel_value =  pattern_run?pattern_dat:{mazes_catch,mazes_word0};

            wire[                  6: 0]mazes_coefs[( 1<<ports_expon)-1: 0][1:0];//coefs
            wire[                  1: 0]mazes_scrip[( 1<<ports_expon)-1: 0];//
            wire[( 1<<ports_expon)-1: 0]mazes_latch;
            wire[( 1<<ports_expon)-1: 0]mazes_pause;
            wire[( 1<<ports_expon)-1: 0]mazes_pixel;
            wire[( 1<<ports_expon)-1: 0]mazes_initi;
            wire[                 15: 0]mazes_limit[( 1<<ports_expon)-1: 0];
            
          //reg [                 15: 0]mazes_limit[( 1<<ports_expon)-1: 0];
/*

    3 2
  h n 
  l n
*/

            reg [( 1<<ports_expon)-1: 0]cross_pixel;//cross_pixel   cross_range
            reg [( 1<<ports_expon)-1: 0]cross_initi;//cross_initi
            reg [( 1<<ports_expon)-1: 0]cross_hside;//cross_initi
            reg [( 1<<ports_expon)-1: 0]cross_lside;//cross_initi
            reg [                  1: 0]cross_scrip[( 1<<ports_expon)-1: 0];        //cross_scrip
            reg [                  1: 0]cross_label[( 1<<ports_expon)-1: 0];        //cross_label   stamp
            reg [                 15: 0]cross_limit[( 1<<ports_expon)-1: 0];        //cross_limit   cross_lines
            wire[                  1: 0]cross_range[( 1<<ports_expon)-1: 0];        //cross_range
          //wire[( 1<<ports_expon)-1: 0]mazes_start;
          //reg [( 1<<ports_expon)-1: 0]cross_start;
genvar m;
    generate
        for (m=0; m<(1<<ports_expon); m=m+1)
        begin//[(m*16)+15:(m*16)]
assign  mazes_scrip[m]      =  {mazes_chars[(m*16)+15],mazes_chars[(m*16)+ 7]};//{mazes_chars[   15],mazes_chars[    7]};
assign  mazes_coefs[m][1]   =   mazes_chars[(m*16)+14:(m*16)+ 8];//mazes_chars[14: 8];
assign  mazes_coefs[m][0]   =   mazes_chars[(m*16)+ 6:(m*16)+ 0];//[ 6: 0];
assign  mazes_pause[m]      =  (mazes_scrip[m]==chars_pause);//||mazes_blank[m];//
assign  mazes_latch[m]      =  (mazes_scrip[m]==chars_latch)?(cross_hside[m]?1:(|mazes_coefs[m][1])):0;//cross_label[m][1]?((mazes_scrip[m]==chars_latch)&&(|mazes_coefs[m][1])):(mazes_scrip[m]==chars_latch);//

assign  mazes_pixel[m]      =  (mazes_scrip[m]==chars_latch)?(cross_hside[m]&& cross_pixel[m]):(mazes_scrip[m]==chars_pixel);//
assign  mazes_initi[m]      =  (mazes_scrip[m]==chars_latch)?(cross_hside[m]&&(cross_initi[m]||(mazes_scrip[m]==chars_latch))):(mazes_scrip[m]==chars_initi);//
//assign  mazes_initi[m]      =  (mazes_scrip[m]==chars_latch)?(cross_hside[m]&& cross_initi[m]):(mazes_scrip[m]==chars_initi);//

assign  mazes_limit[m][14:8]=  (mazes_scrip[m]==chars_latch)?(cross_hside[m]?cross_limit[m][14:8]:mazes_coefs[m][1]):0;//(mazes_scrip[m]==chars_latch)?
assign  mazes_limit[m][ 6:0]=   cross_limit[m][ 6:0];


//
//assign  mazes_start[m]      =   mazes_blank[m]?0:mazes_pixel[m]?1:(!cross_blank[m]);//(cross_blank[m]&&mazes_pixel[m])
//always@(posedge refer_clock)cross_start[m]      <=  mazes_syncs[1]?(mazes_blank[m]?0:(mazes_pixel[m]?1:cross_start[m])):cross_start[m];
//
//assign  cross_pixel[m]      =  (cross_scrip[m]==chars_pixel)&&( cross_label[m][1]);
//assign  cross_initi[m]      =  (cross_scrip[m]==chars_initi)&&( cross_label[m][1]);
//always@(posedge refer_clock)cross_scrip[m]      <=  mazes_syncs[1]?((mazes_scrip[m]==chars_latch)?cross_scrip[m]:mazes_scrip[m]):cross_scrip[m];
//always@(posedge refer_clock)cross_limit[m][ 6:0]<= (mazes_syncs[1]&&mazes_pause[m])?    mazes_coefs[m][0]   :cross_limit[m][ 6:0];
always@(posedge refer_clock)cross_pixel[m]  <=  mazes_syncs[1]?((mazes_scrip[m]==chars_latch)?cross_pixel[m]:(mazes_scrip[m]==chars_pixel)):cross_pixel[m];
always@(posedge refer_clock)cross_initi[m]  <=  mazes_syncs[1]?((mazes_scrip[m]==chars_latch)?cross_initi[m]:(mazes_scrip[m]==chars_initi)):cross_initi[m];
always@(posedge refer_clock)
    if( mazes_syncs[1]&&mazes_pause[m])
      //if( mazes_pause[m])
    begin
        cross_hside[m]  <=(|mazes_chars[(m*16)+14:(m*16)+ 8]);//
        cross_lside[m]  <=(|mazes_chars[(m*16)+ 6:(m*16)+ 0]);//
        cross_limit[m]  <= {mazes_chars[(m*16)+14:(m*16)+ 8],1'b0,mazes_chars[(m*16)+ 6:(m*16)+ 0]};//
    end
    else
    begin
        cross_hside[m]  <=  cross_hside[m];//
        cross_lside[m]  <=  cross_lside[m];//
        cross_limit[m]  <=  cross_limit[m];//
    end

//assign  cross_range[m][1]   =   cross_limit[m][1]>mazes_layer[ 5: 0];//cross_label[m][1]?(cross_limit[m][1]>mazes_layer[ 5: 0]):(mazes_coefs[m][1]>mazes_layer[ 5: 0]);
//assign  cross_range[m][0]   =   cross_limit[m][0]>mazes_layer[ 5: 0];
        end // block: u
    endgenerate


            reg                         select_stop;
            reg [   ports_expon-1   : 0]select_port;
            reg [                  1: 0]select_side;
            reg [                  2: 0]select_calc;
            wire[                 15: 0]setup_catch[3:0];//setup_catch
            wire[                  7: 0]catch_coefs[3:0];//gamma_pixel

          //reg [              31   : 0]coefs_catch;
always@(posedge refer_clock)   {select_stop,select_port,select_side,select_calc}<=(|memory_load)?0:
                               {select_stop,select_port,select_side,select_calc}+(!select_stop);

    xram#(
        .   expon_chars             (   48),//= 36,
        .   expon_local             (   ports_expon))//= 16)
    memory_initi (
        .   write_clock             (   refer_clock), 
        .   write_local             (   memory_port), 
        .   write_syncs             ( (&memory_load)&&(memory_sync)),//&&(mazes_scrip[memory_port]==chars_initi)), 
        .   write_chars             (   mazes_setup), //B ,{G,R}
        .   carry_clock             (   refer_clock), 
        .   carry_local             (   select_port), 
        .   carry_chars             (  {setup_catch[3],setup_catch[2],setup_catch[1],setup_catch[0]}));
    xram#(
        .   memory_type             (   "block"),
        .   expon_chars             (   24),//= 36,
        .   expon_local             (   ports_expon))//= 16)
    memory_catch (
        .   write_clock             (   refer_clock), 
        .   write_local             (   pixel_ports), 
        .   write_syncs             (   pixel_write), 
        .   write_chars             (   pixel_value),//{mazes_catch,mazes_word0}), //B ,{G,R}
        .   carry_clock             (   refer_clock), 
        .   carry_local             (   select_port), 
      //.   carry_chars             (  {catch_coefs[3],catch_coefs[0],catch_coefs[1],catch_coefs[2]}));
        .   carry_chars             (  {catch_coefs[3],catch_coefs[2],catch_coefs[1],catch_coefs[0]}));


            wire[              15   : 0]gamma_catch;//[2:0];//
    xram#(
        .   memory_file             (   "./GAMMA24.hex"),//= 0,//"./rom.rom",
        .   expon_chars             (   16),//= 36,
        .   expon_local             (   8))//= 16)
    gamma (
        .   write_clock             (   0), 
        .   write_local             (   0), 
        .   write_syncs             (   0), 
        .   write_chars             (   0), 
        .   carry_clock             (   refer_clock), 
        .   carry_local             (   catch_coefs[select_side]), 
        .   carry_chars             (   gamma_catch));
/*
            reg [              15   : 0]bright_gain;
            reg [                 31: 0]value_catch;
always@(posedge refer_clock)bright_gain <= (bright_code[select_side]*bright_code[3])+bright_code[3];
always@(posedge refer_clock)value_catch <=((gamma_catch*bright_gain)+gamma_catch);
*/
            wire[              15   : 0]bright_gain;
            wire[              31   : 0]value_catch;
    AxB
    bright (
        .   CLK             (   refer_clock), 
        .   CE              (   1), 
        .   SCLR            (   0), 
        .   A               (   bright_code[3]), 
        .   B               (   bright_code[select_side]), 
        .   C               (   bright_code[3]), 
        .   SUBTRACT        (   0),
        .   P               (   bright_gain));

    AxB
    value (
        .   CLK             (   refer_clock), 
        .   CE              (   1), 
        .   SCLR            (   0), 
        .   A               (   gamma_catch), 
        .   B               (   bright_gain), 
        .   C               (   gamma_catch), 
        .   SUBTRACT        (   0),
        .   P               (   value_catch));


//always@(posedge refer_clock)value_catch <=((matrix_data*bright_gain)+matrix_data);

            reg [                 15: 0]coefs_catch;//coefs_catch   calcs_coefs
          //reg [                 15: 0]coefs_dummy;
            reg [                 15: 0]coefs_setup;//coefs_setup
            reg                         coefs_pixel;//coefs_pixel
            reg                         coefs_initi;//coefs_initi
            reg                         coefs_latch;//coefs_latch
            reg                         coefs_pause;//coefs_pause
            reg                         coefs_blank;//coefs_blank
            reg [                 15: 0]coefs_limit;//coefs_limit
            reg                         coefs_write;//coefs_write
            reg [   ports_expon-1   : 0]coefs_ports;//coefs_ports
            reg [                  1: 0]coefs_sides;//coefs_sides
  
//assign  coefs_start =   cross_start;
//always@(posedge refer_clock)coefs_start <=  
//always@(posedge refer_clock)cross_start[m]      <=  mazes_syncs[1]?(mazes_blank[m]?0:(mazes_pixel[m]?1:cross_start[m])):cross_start[m];
                                          //mazes_start[select_port]?((gamma_catch*bright_gain)+gamma_catch):0;
//always@(posedge refer_clock)coefs_setup <=  setup_catch[select_side];

always@(posedge refer_clock)coefs_catch <= (mazes_initi[select_port]&&(&select_calc))?setup_catch[select_side]://;//mazes_initi[select_port]?{setup_catch[select_side],setup_catch[select_side]}:
                                           (mazes_pixel[select_port]&&(&select_calc))?value_catch[31:16]:coefs_catch;

//always@(posedge refer_clock)   {coefs_catch,coefs_dummy}<=((gamma_catch*bright_gain)+gamma_catch);

always@(posedge refer_clock)coefs_pixel <=  mazes_pixel[select_port];
always@(posedge refer_clock)coefs_initi <=  mazes_initi[select_port];
always@(posedge refer_clock)coefs_latch <=  mazes_latch[select_port];
always@(posedge refer_clock)coefs_pause <=  mazes_pause[select_port];
always@(posedge refer_clock)coefs_blank <=  mazes_blank[select_port];
always@(posedge refer_clock)coefs_limit <= {mazes_limit[select_port][14:8],1'b0,mazes_limit[select_port][6:0]};
always@(posedge refer_clock)coefs_write <=(&select_calc)&&(!select_stop);//&&mazes_pixel[select_port];
always@(posedge refer_clock)coefs_ports <=  select_port;
always@(posedge refer_clock)coefs_sides <=  select_side;
/*
10*2 =20
8*4*8=256


*/

/*
            reg [( 1<<ports_expon)-1: 0]start_initi;//coefs_start
            reg [( 1<<ports_expon)-1: 0]start_pixel;
always@(posedge refer_clock)start_initi <=(|memory_load)?start_initi:(~mazes_blank)&(start_initi|mazes_initi);
always@(posedge refer_clock)start_pixel <=(|memory_load)?start_pixel:(~mazes_blank)&(start_pixel|mazes_pixel);
*/
//always@(posedge refer_clock)coefs_start[select_port]<=(!select_stop&&(select_calc==0))?(mazes_blank[select_port]?1'b0:(coefs_start[select_port]||mazes_pixel[select_port])):coefs_start[select_port];

//



//
            reg [( 1<<ports_expon)-1: 0]demux_blank;
            reg [( 1<<ports_expon)-1: 0]demux_pixel;//coefs_pixel
            reg [( 1<<ports_expon)-1: 0]demux_initi;//coefs_initi
            reg [( 1<<ports_expon)-1: 0]demux_latch;//coefs_latch
            reg [( 1<<ports_expon)-1: 0]demux_pause;//coefs_pause
            reg [                 15: 0]demux_limit[( 1<<ports_expon)-1: 0];
            reg [                 63: 0]demux_coefs[( 1<<ports_expon)-1: 0];
always@(posedge refer_clock)demux_blank[coefs_ports]<= (coefs_write&&(coefs_sides==0))? coefs_blank    :demux_blank[coefs_ports];
always@(posedge refer_clock)demux_pixel[coefs_ports]<= (coefs_write&&(coefs_sides==0))? coefs_pixel    :demux_pixel[coefs_ports];
always@(posedge refer_clock)demux_initi[coefs_ports]<= (coefs_write&&(coefs_sides==0))? coefs_initi    :demux_initi[coefs_ports];
always@(posedge refer_clock)demux_latch[coefs_ports]<= (coefs_write&&(coefs_sides==0))? coefs_latch    :demux_latch[coefs_ports];
always@(posedge refer_clock)demux_pause[coefs_ports]<= (coefs_write&&(coefs_sides==0))? coefs_pause    :demux_pause[coefs_ports];
always@(posedge refer_clock)demux_limit[coefs_ports]<= (coefs_write&&(coefs_sides==0))? coefs_limit    :demux_limit[coefs_ports];
//MSB = Blue
//always@(posedge refer_clock)demux_coefs[coefs_ports][15: 0]  <= (coefs_write&&(coefs_sides==0))? coefs_catch:demux_coefs[coefs_ports][15: 0];
//always@(posedge refer_clock)demux_coefs[coefs_ports][31:16]  <= (coefs_write&&(coefs_sides==1))? coefs_catch:demux_coefs[coefs_ports][31:16];
//always@(posedge refer_clock)demux_coefs[coefs_ports][47:32]  <= (coefs_write&&(coefs_sides==2))? coefs_catch:demux_coefs[coefs_ports][47:32];
//MSB = Red
always@(posedge refer_clock)demux_coefs[coefs_ports][15: 0]  <= (coefs_write&&(coefs_sides==2))? coefs_catch:demux_coefs[coefs_ports][15: 0];
always@(posedge refer_clock)demux_coefs[coefs_ports][31:16]  <= (coefs_write&&(coefs_sides==1))? coefs_catch:demux_coefs[coefs_ports][31:16];
always@(posedge refer_clock)demux_coefs[coefs_ports][47:32]  <= (coefs_write&&(coefs_sides==0))? coefs_catch:demux_coefs[coefs_ports][47:32];


//
/*
    00101111    00101110    00101101    00101100
        1111                            1110
    0   1
    0               1
*/

            reg [                  8: 0]half_counts;//half_counts
            reg                         bus_syncing;
            reg [                  1: 0]divide_3_ck;
            reg [                  5: 0]x48_counter;
            reg                         x48_posedge;//syncing  double   /96
            reg                         x48_negedge;
            reg [                  3: 0]x16_counter;
            reg                         x16_posedge;
            reg                         x16_negedge;
always@(posedge refer_clock)
    if( mazes_syncs[0])//48
    begin
        half_counts <= (half_period-1);//10/2
        bus_syncing <=  mazes_syncs[1];
        divide_3_ck <=  mazes_syncs[1]?0:((divide_3_ck==2)?0:(divide_3_ck+1));
        x48_counter <=  mazes_syncs[1]?47:(x48_counter-(|x48_counter));
        x48_negedge <=  1;
        x48_posedge <=  0;
        x16_counter <=  mazes_syncs[1]?15:((divide_3_ck==2)?(x16_counter-(|x16_counter)):x16_counter);
        x16_negedge <=  mazes_syncs[1]||(divide_3_ck==2);
        x16_posedge <=  0;
    end
    else
    begin
        half_counts <=  half_counts-(!half_counts[8]);
        bus_syncing <=  0;
        divide_3_ck <=  divide_3_ck;
        x48_counter <=  x48_counter;
        x48_negedge <=  0;
        x48_posedge <= (half_counts==0);
        x16_counter <=  x16_counter;
        x16_negedge <=  0;
        x16_posedge <= (half_counts==0)&&(divide_3_ck==1);
    end


            reg [( 1<<ports_expon)-1: 0]distr_blank;
          //reg [( 1<<ports_expon)-1: 0]distr_pixel;//coefs_pixel
          //reg [( 1<<ports_expon)-1: 0]distr_initi;//coefs_initi
          //reg [( 1<<ports_expon)-1: 0]distr_write;//coefs_latch
            reg [( 1<<ports_expon)-1: 0]distr_pause;//coefs_pause
          //reg [( 1<<ports_expon)-1: 0]distr_write;//coefs_latch
            reg [                  5: 0]distr_pixel[( 1<<ports_expon)-1: 0];
            reg [                  5: 0]distr_initi[( 1<<ports_expon)-1: 0];
            reg [                  5: 0]distr_latch[( 1<<ports_expon)-1: 0];
            reg [                  5: 0]distr_write[( 1<<ports_expon)-1: 0];//distr_latch
            reg [                 63: 0]distr_coefs[( 1<<ports_expon)-1: 0];
            wire[                 15: 0]distr_words[( 1<<ports_expon)-0: 0][2:0];
            
          //wire[                 31: 0]distr_dword[( 1<<ports_expon)-1: 0][2:0];


            reg [( 1<<ports_expon)-1: 0]shift_blank;
            reg [( 1<<ports_expon)-1: 0]shift_pause;//coefs_pause
            reg [                  1: 0]shift_pixel[( 1<<ports_expon)-1: 0];//coefs_pixel
            reg [                  1: 0]shift_initi[( 1<<ports_expon)-1: 0];//coefs_initi
            reg [                  1: 0]shift_latch[( 1<<ports_expon)-1: 0];//coefs_latch
            reg [                  1: 0]shift_write[( 1<<ports_expon)-1: 0];//coefs_latch
            wire[                  3: 0]shift_carry[( 1<<ports_expon)-1: 0];//coefs_latch
            reg [                  1: 0]shift_set_1;
            reg [                  1: 0]shift_set_0;
always@(posedge refer_clock)shift_set_0[0]  <=  x16_negedge;
always@(posedge refer_clock)shift_set_0[1]  <=  x48_negedge;
always@(posedge refer_clock)shift_set_1[0]  <=  x16_posedge;
always@(posedge refer_clock)shift_set_1[1]  <=  x48_posedge;

            reg [                  3: 0]shift_knitr[( 1<<ports_expon)-1: 0];
            reg [                  1: 0]shift_hside[( 1<<ports_expon)-1: 0];
            reg [                  1: 0]shift_lside[( 1<<ports_expon)-1: 0];
            reg [                  1: 0]shift_clock[( 1<<ports_expon)-1: 0];

            reg [                  3: 0]shift_dotx2[( 1<<ports_expon)-1: 0];
genvar n;
    generate
        for (n=0; n<(1<<ports_expon); n=n+1)
        begin//[(m*16)+15:(m*16)]
always@(posedge refer_clock)distr_blank[n]  <=  mazes_syncs[1]? demux_blank[n]:distr_blank[n];
always@(posedge refer_clock)distr_pixel[n]  <=  mazes_syncs[1]?(demux_pixel[n]?demux_limit[n][ 5: 0]:0):distr_pixel[n];
always@(posedge refer_clock)distr_initi[n]  <=  mazes_syncs[1]?(demux_initi[n]?demux_limit[n][ 5: 0]:0):distr_initi[n];
always@(posedge refer_clock)distr_latch[n]  <=  mazes_syncs[1]?(demux_latch[n]?demux_limit[n][ 5: 0]:0):distr_latch[n];

always@(posedge refer_clock)distr_write[n]  <=  mazes_syncs[1]?(demux_latch[n]?demux_limit[n][13: 8]:0):distr_write[n];
always@(posedge refer_clock)distr_pause[n]  <=  mazes_syncs[1]? demux_pause[n]:distr_pause[n];
//always@(posedge refer_clock)distr_limit[n]  <=  mazes_syncs[1]?demux_limit[n]:distr_limit[n];
always@(posedge refer_clock)distr_coefs[n]  <=  mazes_syncs[1]?demux_coefs[n]:distr_coefs[n];
assign  distr_words[n][0]   =   distr_coefs[n][47:32];//MSB = Red
assign  distr_words[n][1]   =   distr_coefs[n][31:16];
assign  distr_words[n][2]   =   distr_coefs[n][15: 0];

//assign  distr_dword[n][0]   =  {distr_words[(n+1)][0],distr_words[n][0]};
//assign  distr_dword[n][1]   =  {distr_words[(n+1)][1],distr_words[n][1]};
//assign  distr_dword[n][2]   =  {distr_words[(n+1)][2],distr_words[n][2]};


//
//always@(posedge refer_clock)distr_start[n]   <= (edge_strobe&&(coefs_comma==1))?(~demux_blank[n]&(distr_start[n]|demux_pixel[n])):distr_start[n];
//


always@(posedge refer_clock)shift_blank[n]      <=  distr_blank[n];
always@(posedge refer_clock)shift_pause[n]      <=  distr_pause[n];

always@(posedge refer_clock)shift_pixel[n][0]   <= (distr_blank[n]||distr_pause[n])?0:(distr_pixel[n]>x16_counter);
always@(posedge refer_clock)shift_pixel[n][1]   <= (distr_blank[n]||distr_pause[n])?0:(distr_pixel[n]>x48_counter);

always@(posedge refer_clock)shift_initi[n][0]   <= (distr_blank[n]||distr_pause[n])?0:(distr_initi[n]>x16_counter);
always@(posedge refer_clock)shift_initi[n][1]   <= (distr_blank[n]||distr_pause[n])?0:(distr_initi[n]>x48_counter);

always@(posedge refer_clock)shift_latch[n][0]   <= (distr_blank[n]||distr_pause[n])?0:(distr_latch[n]>x16_counter);
always@(posedge refer_clock)shift_latch[n][1]   <= (distr_blank[n]||distr_pause[n])?0:(distr_latch[n]>x48_counter);

always@(posedge refer_clock)shift_write[n][0]   <= (distr_blank[n]||distr_pause[n])?0:(distr_write[n]>x16_counter);
always@(posedge refer_clock)shift_write[n][1]   <= (distr_blank[n]||distr_pause[n])?0:(distr_write[n]>x48_counter);
//shift_break
assign  shift_carry[n][0]   =  (shift_pixel[n][0]||shift_initi[n][0]);
assign  shift_carry[n][1]   =  (shift_pixel[n][0]||shift_initi[n][0]);
assign  shift_carry[n][2]   =  (shift_pixel[n][0]||shift_initi[n][0]);
assign  shift_carry[n][3]   =  (shift_pixel[n][1]||shift_initi[n][1]);
always@(posedge refer_clock)shift_knitr[n][0]   <=  distr_words[n][0][x16_counter];
always@(posedge refer_clock)shift_knitr[n][1]   <=  distr_words[n][1][x16_counter];
always@(posedge refer_clock)shift_knitr[n][2]   <=  distr_words[n][2][x16_counter];
always@(posedge refer_clock)shift_knitr[n][3]   <=  distr_coefs[n][x48_counter+ 0];

//always@(posedge refer_clock)shift_dotx2[n][0]   <=  distr_dword[n][0][x48_counter];
//always@(posedge refer_clock)shift_dotx2[n][1]   <=  distr_dword[n][1][x48_counter];
//always@(posedge refer_clock)shift_dotx2[n][2]   <=  distr_dword[n][2][x48_counter];
//always@(posedge refer_clock)shift_dotx2[n][3]   <=  distr_coefs[n][x48_counter+ 0];


//
always@(posedge refer_clock)panel_blank[n]              <=  shift_blank[n];
always@(posedge refer_clock)panel_knitr[(n*4)+3:(n*4)]  <=  shift_pause[n]?0:shift_knitr[n];//&shift_carry[n];//(shift_blank[n]||(!shift_initi[n])||(!shift_pixel[n]))?0: shift_knitr[n];
always@(posedge refer_clock)panel_latch[(n*2)+1:(n*2)]  <=  shift_write[n];//?0: shift_hside[n];
always@(posedge refer_clock)panel_clock[(n*2)+0]        <=  shift_set_0[0]?0:(shift_set_1[0]?(shift_pixel[n][0]|shift_initi[n][0]):panel_clock[(n*2)+0]);//?0:(shift_lside[n]&shift_clock[n]);
always@(posedge refer_clock)panel_clock[(n*2)+1]        <=  shift_set_0[1]?0:(shift_set_1[1]?(shift_pixel[n][1]|shift_initi[n][1]):panel_clock[(n*2)+1]);
//
//always@(posedge refer_clock)panel_dotx2[(n*4)+3:(n*4)]  <=  shift_pause[n]?0:shift_dotx2[n];//
        end // block: u
    endgenerate


endmodule