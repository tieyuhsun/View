module  MY9373_register//
#(
    parameter   filter_pole =   4
/**/

)(

    input       [                 4:  0]scale_lines,//  16 ~ 1
  //input                               gray_double,
    input       [               127:  0]gray_object,//<-mazes_chars
/**/
    input       [                 7:  0]shifter_bit,
/**/
    input       [                 7:  0]currentse_r,
    input       [                 7:  0]currentse_g,
    input       [                 7:  0]currentse_b,
//
  //output  wire                        serial_type,
    output  wire[                47:  0]config48bit,
    output  wire[                15:  0]config16b_r,
    output  wire[                15:  0]config16b_g,
    output  wire[                15:  0]config16b_b
);

/*
R CMD：003ABD5116 / G CMD：0039BD5116 / B CMD：0028BD5116 
GCK Toff(us)：0.36 / GCK Duty(us)：30.72
Period(ms)：15.914 / DCK：4.545MHz / GCK：8.333MHz
*/
            wire                        invert_step;
            wire                        scale_edges;
            wire[                 16: 0]scale_dimms;//
            wire[                  4: 0]scale_expon;//
assign  invert_step =  (gray_object[15: 0]>gray_object[31:16])||(gray_object[15: 0]==0);
assign  scale_edges =   gray_object[  119];//[127:120]frame
assign  scale_dimms =  (gray_object[15: 0]==0)?(1<<16):(invert_step?gray_object[15: 0]:gray_object[31:16]);
assign  scale_expon =   
       (scale_dimms==(1<<16) )  ?  16:
       (scale_dimms==(1<< 5) )  ?   5:
       (scale_dimms==(1<< 6) )  ?   6:
       (scale_dimms==(1<< 7) )  ?   7:
       (scale_dimms==(1<< 8) )  ?   8:
       (scale_dimms==(1<< 9) )  ?   9:
       (scale_dimms==(1<<10) )  ?  10:
       (scale_dimms==(1<<11) )  ?  11:
       (scale_dimms==(1<<12) )  ?  12:
       (scale_dimms==(1<<13) )  ?  13:
       (scale_dimms==(1<<14) )  ?  14:
       (scale_dimms==(1<<15) )  ?  15:0;
/**/
            wire[                 4:  0]my9373_line;
            wire                        my9373_edge;
            wire[                 1:  0]my9373_gray;
assign  my9373_line =  (scale_lines==0)?0:(scale_lines-1);
assign  my9373_edge =   scale_edges;
assign  my9373_gray =   //2'b00;//2'b01;//
                     ( !scale_edges&&scale_expon == 9)?2'b00://512t+blank
                     ( !scale_edges&&scale_expon == 8)?2'b01://256t+blank
                     ( !scale_edges&&scale_expon == 7)?2'b10://128t+blank
                     ( !scale_edges&&scale_expon == 6)?2'b11:// 64t+blank
                     (  scale_edges&&scale_expon == 8)?2'b00://256t+blank   256(+),256(-)
                     (  scale_edges&&scale_expon == 7)?2'b01://128t+blank   128(+),128(-)
                     (  scale_edges&&scale_expon == 6)?2'b10:// 64t+blank    64(+), 64(-)
                     (  scale_edges&&scale_expon == 5)?2'b11:// 32t+blank    32(+), 32(-)
                        2'b00;//64t+blank


/*
*/
            //MY9373
            wire[                 2:  0]reg_b31_b31;        //0
            wire[                 2:  0]reg_b30_b28[2:0];   //Low Brightness Compensation
            wire[                 3:  0]reg_b27_b24[2:0];   //1st  Scan Brightness Compensation 
            wire[                 2:  0]reg_b23_b23;        //0
            wire[                 2:  0]reg_b22_b22;        //Higher refresh rate at low brightness selection or 1-bit grayscale enhancement   
            wire[                 1:  0]reg_b21_b20[2:0];   //Output ports pull close to a high voltage when they are turned off for ghost image abatement. 
            wire[                 2:  0]reg_b19_b19;        //Double Edge GCK Selection
            wire[                 2:  0]reg_b18_b18;        //0
            wire[                 1:  0]reg_b17_b16[2:0];   //Stagger Output Mode Selection (Set 10/01/00 for R/G/B LED)

            wire[                 2:  0]reg_b14_b14;        //0
            wire[                 3:  0]reg_b13_b10[2:0];   //Set the scanning mode supports static and any dynamic applications from 1/2 scan to 1/32 scan
            wire[                 1:  0]reg_b09_b08[2:0];   //0: 512 GCKs   1: 256 GCKs     2: 128 GCKs     3: 64 GCKs
            wire[                 1:  0]reg_b15ib07[2:0];   //0:0.37KΩ ≦ Rext ≦ 0.65KΩ    1:0.65KΩ ≦ Rext ≦ 4.3KΩ   2:4.3KΩ ≦ Rext ≦ 13KΩ 
            wire[                 2:  0]reg_b06_b06;        //Ghost2 elimination 
            wire[                 4:  0]reg_b05_b01[2:0];   //3.125/(1<<5bit)   0=3.125%
            wire[                 2:  0]reg_b00_b00;        //LED open detection and   fail line abatement Selection    1:Disable 

//
//      [31:24] [23:16] [15: 8] [15: 0]
//R     00      3A      BD      51
//G     00      39      BD      51
//B     00      28      BD      51
//       C      70      3D      49
//      0C      70      1D      49  edge[19]=0  ,[9:8]==2'b01
//  GCK Toff(us)：0.36 / GCK Duty(us)：30.72
//  Period(ms)：15.914 / DCK：4.545MHz / GCK：8.333MHz

//調整CMD[21:20] / CMD[6] / Toff(消影時間)，已有改善，
//                    10111101
//00000001  01100011  00111101  00001101
//00001100  01110000  00111101  01001001
//00001100  01010000  00111101  00000101
//                          01
//                      0111  
//              1
//              1010 2
//              1001 1
//              1000 0
//                    00011101
//LA:0163 1C0D
//        13,12_11,10
//                   , 9, 8
assign  reg_b31_b31     = 0;
assign  reg_b30_b28[0]  = 0;            assign  reg_b30_b28[1]  = 0;            assign  reg_b30_b28[2]  = 0;            //Low Brightness Compensation
assign  reg_b27_b24[0]  = 4'b0001;      assign  reg_b27_b24[1]  = 4'b1100;      assign  reg_b27_b24[2]  = 4'b1100;      //1st  Scan Brightness Compensation 
assign  reg_b23_b23     = 0;
assign  reg_b22_b22[0]  = 1;            assign  reg_b22_b22[1]  = 1;            assign  reg_b22_b22[2]  = 1;            //? Higher refresh rate at low brightness selection or 1-bit grayscale enhancement 
assign  reg_b21_b20[0]  = 2'b10;        assign  reg_b21_b20[1]  = 2'b11;        assign  reg_b21_b20[2]  = 2'b01;        //? Output ports pull close to a high voltage when they are turned off for ghost image abatement. 
assign  reg_b19_b19[0]  =my9373_edge;   assign  reg_b19_b19[1]  =my9373_edge;   assign  reg_b19_b19[2]  =my9373_edge;   // GCK.DDR
assign  reg_b18_b18     = 0;
assign  reg_b17_b16[0]  = 2'b11;        assign  reg_b17_b16[1]  = 2'b00;        assign  reg_b17_b16[2]  = 2'b00;        //? Stagger Output Mode Selection (Set 10/01/00 for R/G/B LED)

assign  reg_b14_b14     = 0;
assign  reg_b13_b10[0]  =my9373_line;   assign  reg_b13_b10[1]  =my9373_line;   assign  reg_b13_b10[2]  =my9373_line;   //Set the scanning mode supports static and any dynamic applications from 1/2 scan to 1/32 scan
assign  reg_b09_b08[0]  =my9373_gray;   assign  reg_b09_b08[1]  =my9373_gray;   assign  reg_b09_b08[2]  =my9373_gray;   //0: 512 GCKs   1: 256 GCKs     2: 128 GCKs     3: 64 GCKs
assign  reg_b15ib07[0]  = 0;            assign  reg_b15ib07[1]  = 0;            assign  reg_b15ib07[2]  = 0;            //0:0.37KΩ ≦ Rext ≦ 0.65KΩ    1:0.65KΩ ≦ Rext ≦ 4.3KΩ   2:4.3KΩ ≦ Rext ≦ 13KΩ 
assign  reg_b06_b06[0]  = 0;            assign  reg_b06_b06[1]  = 1;            assign  reg_b06_b06[2]  = 0;            //? Ghost2 elimination 
assign  reg_b05_b01[0]=currentse_r[7:3];assign  reg_b05_b01[1]=currentse_g[7:3];assign  reg_b05_b01[2]=currentse_b[7:3];//3.125/(1<<5bit)   0=3.125%
assign  reg_b00_b00[0]  = 1;            assign  reg_b00_b00[1]  = 1;            assign  reg_b00_b00[2]  = 1;            //LED open detection and   fail line abatement Selection    1:Disable

/**/
//R     00      3A      BD      51
//G     00      39      BD      51
//B     00      28      BD      51
            wire[                 31: 0]CONCATENATE[2:0];//15..0..-3
//assign  CONCATENATE[0]  =   32'h00321C51;//1010
//assign  CONCATENATE[1]  =   32'h00311C51;//1001
//assign  CONCATENATE[2]  =   32'h00201C51;//1000

//assign  CONCATENATE[1]  =   32'h0C601E6D;//1001
//assign  CONCATENATE[2]  =   32'h0C601E6D;//1000

assign  CONCATENATE[0]  =   //32'h00321C51;
                               {reg_b31_b31[0],
                                reg_b30_b28[0],
                                reg_b27_b24[0],
                                reg_b23_b23[0],
                                reg_b22_b22[0],
                                reg_b21_b20[0],
                                reg_b19_b19[0],
                                reg_b18_b18[0],
                                reg_b17_b16[0],
                                reg_b15ib07[0][1],
                                reg_b14_b14[0],
                                reg_b13_b10[0],
                                reg_b09_b08[0],
                                reg_b15ib07[0][0],
                                reg_b06_b06[0],
                                reg_b05_b01[0],
                                reg_b00_b00[0]};
assign  CONCATENATE[1]  =     //32'h00311D51;
                               {reg_b31_b31[1],
                                reg_b30_b28[1],
                                reg_b27_b24[1],
                                reg_b23_b23[1],
                                reg_b22_b22[1],
                                reg_b21_b20[1],
                                reg_b19_b19[1],
                                reg_b18_b18[1],
                                reg_b17_b16[1],
                                reg_b15ib07[1][1],
                                reg_b14_b14[1],
                                reg_b13_b10[1],
                                reg_b09_b08[1],
                                reg_b15ib07[1][0],
                                reg_b06_b06[1],
                                reg_b05_b01[1],
                                reg_b00_b00[1]};
assign  CONCATENATE[2]  = //32'h00201E51;
                               {reg_b31_b31[2],
                                reg_b30_b28[2],
                                reg_b27_b24[2],
                                reg_b23_b23[2],
                                reg_b22_b22[2],
                                reg_b21_b20[2],
                                reg_b19_b19[2],
                                reg_b18_b18[2],
                                reg_b17_b16[2],
                                reg_b15ib07[2][1],
                                reg_b14_b14[2],
                                reg_b13_b10[2],
                                reg_b09_b08[2],
                                reg_b15ib07[2][0],
                                reg_b06_b06[2],
                                reg_b05_b01[2],
                                reg_b00_b00[2]};

assign  config16b_r =   CONCATENATE[0]>>shifter_bit;//(shifter_bit==16)?CONCATENATE[0][31:16]:CONCATENATE[0][15: 0];//(CONCATENATE[0]>>shifter_bit);
assign  config16b_g =   CONCATENATE[1]>>shifter_bit;//(shifter_bit==16)?CONCATENATE[1][31:16]:CONCATENATE[1][15: 0];//(CONCATENATE[1]>>shifter_bit);
assign  config16b_b =   CONCATENATE[2]>>shifter_bit;//(shifter_bit==16)?CONCATENATE[2][31:16]:CONCATENATE[2][15: 0];//(CONCATENATE[2]>>shifter_bit);

assign  config48bit =  {config16b_b,config16b_g,config16b_r};


endmodule