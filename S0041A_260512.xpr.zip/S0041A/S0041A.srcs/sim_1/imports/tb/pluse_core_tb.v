`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   19:15:22 10/26/2023
// Design Name:   char_timing
// Module Name:   D:/project/M2GL/char_timing_tb.v
// Project Name:  M2GL
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: char_timing
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module pluse_core_tb;


            wire                        pulse_write;
            wire[               31  : 0]pulse_qbyte;//
            wire[               15  : 0]column_code;
            wire                        column_ctrl;
            wire                        column_mark;
            wire                        row_trigger;
            wire[               1   : 0]row_control;
            wire                        pulse_frame;
            reg                         refer_frame;//mazes_blank
            reg                         refer_ready;//gamma_ready
            reg                         refer_clock;

            reg [               5   : 0]locate_wave;
            wire[               31  : 0]target_wave;
    xram #(
        .   memory_file             (   "./P02027_WAVE.mem"),//memory_file = "./P160522_18b.mem.mem",
        .   expon_chars             (   32),//18),//9, //512
        .   expon_local             (   4))
    initial_envm (
        .   write_clock             (   refer_clock), 
        .   write_local             (   0),//,
        .   write_syncs             (   0),//,
        .   write_chars             (   0),
        .   carry_clock             (   refer_clock),
        .   carry_local             (  (locate_wave>>2)),//(locate_maze>>1)),   locate_step
        .   carry_chars             (   target_wave));// target_maze));

    pulse_core
    pulse_core(
        .   pulse_write             (   pulse_write),
        .   pulse_qbyte             (   pulse_qbyte), 
        .   column_code             (   column_code), 
        .   column_ctrl             (   column_ctrl), 
        .   column_mark             (   column_mark), 
        .   row_trigger             (   row_trigger), 
        .   row_control             (   row_control), 
        .   pulse_frame             (   pulse_frame), 
        .   refer_frame             (   refer_frame), 
        .   refer_ready             (   refer_ready), 
        .   refer_clock             (   refer_clock));



	initial begin

		refer_ready =   0;
		refer_clock =   0;
        refer_frame =   0;
        locate_wave =   0;


		#100;
		refer_ready =   1;        
		// Add stimulus here

	end


always#4 refer_clock = !refer_clock;//8ns
always#6250000 refer_frame = !refer_frame;//80
//always#6250000 refer_frame = !refer_frame;//80
//always#8333333 refer_frame = !refer_frame;//60
//always#16666666 refer_frame = !refer_frame;//30


always@(posedge refer_clock)locate_wave <=  locate_wave+1;
assign  pulse_write = (&locate_wave[1:0]);
assign  pulse_qbyte = (&locate_wave[1:0])?target_wave:(locate_wave>>2);



endmodule

