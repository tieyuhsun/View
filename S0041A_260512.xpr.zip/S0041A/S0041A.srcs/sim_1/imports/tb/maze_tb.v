`timescale 1ns / 1ps

////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer:
//
// Create Date:   19:15:22 10/26/2023
// Design Name:   char_timing
// Module Name:   D:/project/M2GL/char_timing_tb.v
// Project Name:  M2GL
// Target Device:  
// Tool versions:  
// Description: 
//
// Verilog Test Fixture created by ISE for module: char_timing
//
// Dependencies:
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////

module maze_tb;

    parameter   [7:0]setup_speed[2:0]=  {8'd01,8'd06,8'd69};
    parameter   [7:0]setup_shift[2:0]=  {8'h00,8'h00,8'h00};
    parameter   [7:0]expon_field[1:0]=  {8'h02,8'h02};
    parameter   expon_steps     =   2;//demux,   expon_steps
    parameter   expon_mazes     =   6;//    maze_core       6b+0b   = 6b 
    parameter   frequencies     =   96000000;
    parameter   frame_rates     =   80;

            wire                        demux_bidir;
            wire                        demux_break;
            wire                        demux_latch;
            wire[    (expon_steps+7): 0]demux_cycle;//

            wire[                  7: 0]mazes_timer[2:0];
            wire[                  7: 0]engine_gear[2:0];
assign  mazes_timer[0]  =   setup_shift[0][7]?(setup_shift[0][6:0]-engine_gear[0]):(engine_gear[0]-setup_shift[0][6:0]);//
assign  mazes_timer[1]  =   setup_shift[1][7]?(setup_shift[1][6:0]-engine_gear[1]):(engine_gear[1]-setup_shift[1][6:0]);//
assign  mazes_timer[2]  =   setup_shift[2][7]?(setup_shift[2][6:0]-engine_gear[2]):(engine_gear[2]-setup_shift[2][6:0]);//
            wire                        mazes_close;//   PatternCtrl,mazes_black
            wire                        mazes_frame;//
            wire[                  2: 0]mazes_reset;//->maze core
            wire[                  2: 0]mazes_syncs;//

            reg                         refer_frame;//mazes_blank
            reg                         refer_ready;//gamma_ready
            reg                         refer_clock;

            wire[    (expon_mazes-1): 0]locate_maze;//  <-      maze_core       //[expon_cores-1:0]//
            wire[                 31: 0]target_maze;//  ->      maze_core       //[expon_cores-1:0]//   task
    xram #(
        .   memory_file             (   "./P02027_MAZE.mem"),//memory_file = "./P160522_18b.mem.mem",
        .   expon_chars             (   32),//18),//9, //512
        .   expon_local             (   expon_mazes))
    maze_envm (
        .   write_clock             (   refer_clock), 
        .   write_local             (   0),//,
        .   write_syncs             (   0),//,
        .   write_chars             (   0),
        .   carry_clock             (   refer_clock),
        .   carry_local             (   locate_maze),//(locate_maze>>1)),   locate_step
        .   carry_chars             (   target_maze));// target_maze));

    maze_engine#(
        .   frequencies             (   frequencies),   //
        .   frame_rates             (   frame_rates))   //
    maze_engine (
        .   steps_range             (  (setup_speed[2]*setup_speed[1]*setup_speed[0])+0),   //<-   
        .   frame_steps             (  (frequencies/(frame_rates*setup_speed[2]*setup_speed[1]*setup_speed[0]))),   //<-   
      //.   mazes_steps             (   mazes_steps),
        .   mazes_timer             (   engine_gear),   //->
        .   mazes_close             (   mazes_close),   //->    PatternCtrl,mazes_black
        .   mazes_frame             (   mazes_frame),   //->
        .   mazes_reset             (   mazes_reset),   //->    maze core
        .   mazes_syncs             (   mazes_syncs),   //->
        .   timer_mazes             (   setup_speed),   //<-   [2:0], 
        .   self_enable             (   0),   //,
        .   refer_frame             (   refer_frame),   //,
        .   refer_clock             (   refer_clock));

            wire[               17  : 0]mazes_chars;        //  maze_core   ->   
            wire                        mazes_blank;        //  maze_core   ->  
    maze_core#(
        .   expon_mazes             (   expon_mazes))
    maze_processor (
        .   locate_maze             (   locate_maze),   //->
        .   target_maze             (   target_maze),   //<-

        .   mazes_blank             (   mazes_blank),   //->
        .   mazes_chars             (   mazes_chars),   //->

        .   refer_reset             (   mazes_reset),   //<-    maze_engine
        .   refer_syncs             (   mazes_syncs[2]),//<-    maze_engine
        .   refer_clock             (   refer_clock));

/**/
    maze_transport#(
        .   expon_field             (   expon_field),
        .   expon_steps             (   expon_steps))
    maze_transport (
        .   demux_break             (   demux_break),   //->  
        .   demux_latch             (   demux_latch),
        .   demux_cycle             (   demux_cycle),   //->  
        .   demux_bidir             (   demux_bidir),   //->          

        .   steps_range             (  (setup_speed[2]*setup_speed[1]*setup_speed[0])+0),   //<-

        .   mazes_chars             (   target_maze),   //<-

        .   mazes_reset             (   mazes_reset),   //<-
        .   mazes_syncs             (   mazes_syncs),
        .   refer_clock             (   refer_clock));

	initial begin

		refer_ready =   0;
		refer_clock =   0;
        refer_frame =   0;

		#100;
		refer_ready =   1;        
		// Add stimulus here

	end


always#5.208 refer_clock = !refer_clock;//96Mhz
always#12500000 refer_frame = !refer_frame;//80
//always#6250000 refer_frame = !refer_frame;//80
//always#8333333 refer_frame = !refer_frame;//60
//always#16666666 refer_frame = !refer_frame;//30






endmodule

