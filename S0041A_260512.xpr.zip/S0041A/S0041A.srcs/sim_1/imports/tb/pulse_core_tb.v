`timescale 1ns/100ps

module pulse_core_tb;

parameter clock_period = 8;// 125MHZ
parameter frame_period = 12500000;//80


//parameter frame_period = 33333333;//30
//parameter frame_period = 16666666;//60
//parameter frame_period = 12500000;//80
//parameter frame_period =  8333333;//120
            reg [               7   : 0]opcon_index;//
            wire[               31  : 0]opcon_qbyte;//
            wire                        pulse_write;
            wire[               31  : 0]pulse_qbyte;//
            wire[               7   : 0]column_zone;
            wire[               7   : 0]column_line;
            wire                        column_ctrl;
            wire                        column_sync;
            wire                        row_trigger;
            wire[               1   : 0]row_control;
            wire                        pulse_frame;
            reg                         refer_frame;//mazes_blank
            reg                         refer_ready;//gamma_ready
            reg                         refer_clock;

initial
begin
    opcon_index =   0;

    refer_frame =   0;//
    refer_clock =   0;
    refer_ready =   0;
    #(clock_period * 10 )
    refer_ready = 1'b1;
end

always#(clock_period/2) refer_clock = !refer_clock;

always#(frame_period/2) refer_frame = !refer_frame;

always@(posedge refer_clock)opcon_index <=  opcon_index+1;

    xram#(
        .   memory_file             (   "./P02027_WAVE.mem"),//= 0,//"./rom.rom",
        .   expon_chars             (   32),//= 36,
        .   expon_local             (   4)) //= 16)
    initial_envm (
        .   write_clock             (   refer_clock), 
        .   write_local             (   0), 
        .   write_syncs             (   0), 
        .   write_chars             (   0), 
        .   carry_clock             (   refer_clock), 
        .   carry_local             (   opcon_index>>4), 
        .   carry_chars             (   opcon_qbyte));

assign  pulse_write = (&opcon_index[3:0]);
assign  pulse_qbyte = (&opcon_index[3:0])?opcon_qbyte:(opcon_index>>4);//

    pulse_core#(
        .   files_pulse             (   "./P02027_WAVE.mem"),//= 0,//"./rom.rom",
        .   expon_pulse             (   4)) //= 16)
    pulse_core (
        .   pulse_write             (   pulse_write),
        .   pulse_qbyte             (   pulse_qbyte),//
        .   column_zone             (   column_zone),
        .   column_line             (   column_line),
        .   column_ctrl             (   column_ctrl),
        .   column_sync             (   column_sync),
        .   row_trigger             (   row_trigger),
        .   row_control             (   row_control),
        .   pulse_frame             (   pulse_frame),
        .   refer_frame             (   refer_frame),//mazes_blank
        .   refer_ready             (   refer_ready),//gamma_ready
        .   refer_clock             (   refer_clock));

            reg [               7   : 0]pulse_lines[3:0];//
always@(posedge refer_clock)pulse_lines[column_zone]<=  column_ctrl?(column_sync?0:(pulse_lines[column_zone]+1)):pulse_lines[column_zone];

endmodule

