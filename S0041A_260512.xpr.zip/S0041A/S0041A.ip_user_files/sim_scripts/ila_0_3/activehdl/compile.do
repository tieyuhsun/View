transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vmap -link {C:/Design/project/S0034A2/S0034A2.cache/compile_simlib/activehdl}
vlib activehdl/xpm
vlib activehdl/xil_defaultlib

vlog -work xpm  -sv2k12 "+incdir+../../../../S0034A2.gen/sources_1/ip/ila_0_3/hdl/verilog" -l xpm -l xil_defaultlib \
"C:/Xilinx/Vivado/2023.1/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \

vcom -work xpm -93  \
"C:/Xilinx/Vivado/2023.1/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../S0034A2.gen/sources_1/ip/ila_0_3/hdl/verilog" -l xpm -l xil_defaultlib \
"../../../../S0034A2.gen/sources_1/ip/ila_0_3/sim/ila_0.v" \


vlog -work xil_defaultlib \
"glbl.v"

