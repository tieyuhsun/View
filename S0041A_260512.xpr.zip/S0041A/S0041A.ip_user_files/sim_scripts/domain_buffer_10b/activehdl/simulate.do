transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

asim +access +r +m+domain_buffer_10b  -L xil_defaultlib -L xpm -L blk_mem_gen_v8_4_12 -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.domain_buffer_10b xil_defaultlib.glbl

do {domain_buffer_10b.udo}

run 1000ns

endsim

quit -force
