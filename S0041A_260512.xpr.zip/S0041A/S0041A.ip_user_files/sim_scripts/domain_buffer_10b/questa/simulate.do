onbreak {quit -f}
onerror {quit -f}

vsim  -lib xil_defaultlib domain_buffer_10b_opt

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure
view signals

do {domain_buffer_10b.udo}

run 1000ns

quit -force
